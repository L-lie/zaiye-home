# Prompt Vault Official Release Provenance

Product: Prompt Vault

Release ID: PV-ZY-2026-07-03-0001

Version: 0.9.1

Official channel: official website

Official site placeholder: https://zaiye.studio

Owner: 田田田野里 / 再野文化工作室（个人独资）

Copyright: Copyright (c) 2026 田田田野里 / 再野文化工作室（个人独资）

Redistribution, resale, rebranding, or derivative commercial distribution without written permission is prohibited.

## Verification Notes

This extension embeds official release metadata in exported Prompt JSON and feedback summary JSON. Each installation also creates an anonymous install ID stored only in the browser. The install ID is used for provenance and leak tracing; it is not a personal identity record.

Recommended official website practice:

1. Publish the current release ID and version on the download page.
2. Keep archived copies of each ZIP release.
3. Record the release date, file name, file size, and checksum on the website.
4. Ask users to download only from the official website or verified channels.

## Included Anti-Rebranding Signals

- Manifest author metadata.
- Footer brand attribution.
- License and notice files.
- Official release ID.
- Official site metadata.
- Creator/studio metadata in every newly created Prompt.
- Owner/provenance metadata in exported JSON.
- Anonymous install provenance in exported JSON and feedback summaries.

These measures do not make a browser extension impossible to copy. They preserve attribution, support source tracing, and make unauthorized rebranding easier to detect.
