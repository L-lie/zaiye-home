# Prompt Vault Notice

Prompt Vault is created by 田田田野里 and 再野文化工作室（个人独资）.

Copyright (c) 2026 田田田野里 / 再野文化工作室（个人独资）.

This extension is provided for personal evaluation and product prototyping. Redistribution, resale, rebranding, removal of attribution, or derivative commercial distribution without written permission is prohibited.

Browser extensions can be technically inspected by users, so this notice and the attribution metadata in exported JSON are intended to preserve provenance and support anti-rebranding claims.
