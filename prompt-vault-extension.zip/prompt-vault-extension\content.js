const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const SYNC_META_KEY = "promptVaultSyncMeta";
const SYNC_CHUNK_PREFIX = "promptVaultChunk";
const FAB_POSITION_KEY = "promptVaultFabPosition";
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "再野文化工作室（个人独资）",
  creator: "田田田野里"
};

let promptVaultTarget = null;

function isTextTarget(element) {
  if (!element) return false;
  const tag = element.tagName?.toLowerCase();
  return tag === "textarea" || tag === "input" || element.isContentEditable;
}

document.addEventListener("focusin", (event) => {
  if (isTextTarget(event.target)) promptVaultTarget = event.target;
});

function insertText(target, text) {
  if (!target) return false;
  target.focus();

  if (target.isContentEditable) {
    document.execCommand("insertText", false, text);
    target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    return true;
  }

  const start = target.selectionStart ?? target.value.length;
  const end = target.selectionEnd ?? target.value.length;
  target.value = `${target.value.slice(0, start)}${text}${target.value.slice(end)}`;
  const next = start + text.length;
  target.setSelectionRange(next, next);
  target.dispatchEvent(new Event("input", { bubbles: true }));
  target.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function composePrompt(item) {
  const parts = [];
  if (item.prompt?.trim()) parts.push(item.prompt.trim());
  if (item.promptEn?.trim()) parts.push(item.promptEn.trim());
  if (item.negative?.trim()) parts.push(`禁止：${item.negative.trim()}`);
  return parts.join("\n\n");
}

function matches(item, query) {
  const haystack = [item.title, item.project, item.scene, item.genre, item.type, item.prompt, item.promptEn, item.negative, ...(item.tags || [])].join(" ").toLowerCase();
  return haystack.includes(query.toLowerCase());
}

function sanitizePrompt(item) {
  return {
    id: item.id || crypto.randomUUID(),
    title: item.title || "未命名 Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || "",
    type: ["scene", "constraint", "negative"].includes(item.type) ? item.type : "scene",
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    createdAt: Number(item.createdAt) || Date.now(),
    updatedAt: Number(item.updatedAt) || Date.now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

async function getSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: { storageMode: "local" } });
  return data[SETTINGS_KEY];
}

async function readSyncPrompts() {
  const metaData = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const count = metaData[SYNC_META_KEY]?.count || 0;
  if (!count) return [];
  const keys = Array.from({ length: count }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  const chunks = await chrome.storage.sync.get(keys);
  const json = keys.map((key) => chunks[key] || "").join("");
  return json ? JSON.parse(json).map(sanitizePrompt) : [];
}

async function getPrompts() {
  const settings = await getSettings();
  if (settings.storageMode === "sync") {
    const synced = await readSyncPrompts();
    if (synced.length) return synced;
  }
  const data = await chrome.storage.local.get({ [LOCAL_KEY]: [] });
  return data[LOCAL_KEY].map(sanitizePrompt);
}

function buildPanel() {
  const fab = document.createElement("button");
  fab.className = "prompt-vault-fab";
  fab.type = "button";
  fab.title = "Prompt Vault";
  fab.textContent = "P";

  const panel = document.createElement("section");
  panel.className = "prompt-vault-panel";
  panel.innerHTML = `
    <div class="prompt-vault-header">
      <div class="prompt-vault-title">Prompt Vault</div>
      <button class="prompt-vault-close" type="button" aria-label="关闭">x</button>
    </div>
    <div class="prompt-vault-search">
      <input type="search" placeholder="搜索 Prompt、标签、负面词" />
    </div>
    <div class="prompt-vault-list"></div>
  `;

  document.documentElement.append(fab, panel);

  const input = panel.querySelector("input");
  const list = panel.querySelector(".prompt-vault-list");

  function clampPosition(position) {
    const size = 44;
    return {
      x: Math.min(Math.max(8, Number(position?.x) || window.innerWidth - 62), window.innerWidth - size - 8),
      y: Math.min(Math.max(8, Number(position?.y) || window.innerHeight - 62), window.innerHeight - size - 8)
    };
  }

  function placePanel(position) {
    const panelWidth = Math.min(420, window.innerWidth - 28);
    const panelHeight = Math.min(660, window.innerHeight - 96);
    const left = Math.min(Math.max(8, position.x - panelWidth + 44), window.innerWidth - panelWidth - 8);
    const top = position.y > window.innerHeight / 2
      ? Math.max(8, position.y - panelHeight - 10)
      : Math.min(window.innerHeight - panelHeight - 8, position.y + 54);
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  }

  function placeFab(position) {
    const next = clampPosition(position);
    fab.style.left = `${next.x}px`;
    fab.style.top = `${next.y}px`;
    fab.style.right = "auto";
    fab.style.bottom = "auto";
    placePanel(next);
    return next;
  }

  async function restoreFabPosition() {
    const data = await chrome.storage.local.get({ [FAB_POSITION_KEY]: null });
    placeFab(data[FAB_POSITION_KEY]);
  }

  let dragState = null;
  fab.addEventListener("pointerdown", (event) => {
    dragState = {
      startX: event.clientX,
      startY: event.clientY,
      left: fab.getBoundingClientRect().left,
      top: fab.getBoundingClientRect().top,
      moved: false
    };
    fab.setPointerCapture(event.pointerId);
  });

  fab.addEventListener("pointermove", (event) => {
    if (!dragState) return;
    const dx = event.clientX - dragState.startX;
    const dy = event.clientY - dragState.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) dragState.moved = true;
    if (!dragState.moved) return;
    event.preventDefault();
    const next = placeFab({ x: dragState.left + dx, y: dragState.top + dy });
    dragState.current = next;
  });

  fab.addEventListener("pointerup", async (event) => {
    if (!dragState) return;
    fab.releasePointerCapture(event.pointerId);
    if (dragState.current) await chrome.storage.local.set({ [FAB_POSITION_KEY]: dragState.current });
  });

  fab.addEventListener("pointercancel", () => {
    dragState = null;
  });

  async function render() {
    const prompts = await getPrompts();
    const query = input.value.trim();
    const visible = query ? prompts.filter((item) => matches(item, query)) : prompts;

    if (!visible.length) {
      list.innerHTML = `<div class="prompt-vault-empty">还没有匹配的 Prompt。可以在扩展弹窗里新建、导入 JSON，或选中文字后右键保存。</div>`;
      return;
    }

    list.innerHTML = "";
    for (const item of visible) {
      const card = document.createElement("article");
      card.className = "prompt-vault-item";
      card.innerHTML = `
        <div class="prompt-vault-item-top">
          <div class="prompt-vault-item-title"></div>
          <span class="prompt-vault-type"></span>
        </div>
        <div class="prompt-vault-tags" data-project></div>
        <div class="prompt-vault-tags" data-scene></div>
        <div class="prompt-vault-tags" data-genre></div>
        <div class="prompt-vault-body"></div>
        <div class="prompt-vault-tags"></div>
        <div class="prompt-vault-actions">
          <button type="button" data-action="insert">插入</button>
          <button type="button" data-secondary="true" data-action="copy">复制</button>
        </div>
      `;
      card.querySelector(".prompt-vault-item-title").textContent = item.title || "未命名 Prompt";
      card.querySelector(".prompt-vault-type").textContent = item.type === "constraint" ? "约束" : item.type === "negative" ? "负面" : "画面";
      card.querySelector("[data-project]").textContent = item.project ? `项目：${item.project}` : "未分项目";
      card.querySelector("[data-scene]").textContent = item.scene ? `场景：${item.scene}` : "未分场景";
      card.querySelector("[data-genre]").textContent = item.genre ? `类型：${item.genre}` : "未分类型";
      card.querySelector(".prompt-vault-body").textContent = composePrompt(item);
      const tags = card.querySelector(".prompt-vault-tags:not([data-project]):not([data-scene]):not([data-genre])");
      for (const tag of item.tags || []) {
        const chip = document.createElement("span");
        chip.className = "prompt-vault-tag";
        chip.textContent = tag;
        tags.append(chip);
      }
      card.querySelector('[data-action="insert"]').addEventListener("click", () => insertText(promptVaultTarget || document.activeElement, composePrompt(item)));
      card.querySelector('[data-action="copy"]').addEventListener("click", async () => navigator.clipboard.writeText(composePrompt(item)));
      list.append(card);
    }
  }

  fab.addEventListener("click", async () => {
    if (dragState?.moved) {
      dragState = null;
      return;
    }
    dragState = null;
    panel.dataset.open = panel.dataset.open === "true" ? "false" : "true";
    if (panel.dataset.open === "true") await render();
  });
  panel.querySelector(".prompt-vault-close").addEventListener("click", () => {
    panel.dataset.open = "false";
  });
  input.addEventListener("input", render);
  chrome.storage.onChanged.addListener((changes, area) => {
    const localChanged = area === "local" && (changes[LOCAL_KEY] || changes[SETTINGS_KEY]);
    const syncChanged = area === "sync" && changes[SYNC_META_KEY];
    if ((localChanged || syncChanged) && panel.dataset.open === "true") render();
  });

  restoreFabPosition();
}

buildPanel();
