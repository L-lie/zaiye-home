const CATEGORY_LABELS = {
  scene: "画面",
  constraint: "约束",
  negative: "负面"
};

const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const DRAFT_KEY = "promptVaultDraft";
const FEEDBACK_KEY = "promptVaultFeedback";
const INSTALL_ID_KEY = "promptVaultInstallId";
const SYNC_META_KEY = "promptVaultSyncMeta";
const SYNC_CHUNK_PREFIX = "promptVaultChunk";
const SYNC_CHUNK_SIZE = 7000;
const IMAGE_MAX_EDGE = 960;
const IMAGE_QUALITY = 0.78;
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "再野文化工作室（个人独资）",
  creator: "田田田野里",
  copyright: "Copyright (c) 2026 田田田野里 / 再野文化工作室（个人独资）",
  license: "Personal evaluation use only. Redistribution, resale, rebranding, or derivative commercial distribution without written permission is prohibited."
};
const OFFICIAL_RELEASE = {
  releaseId: "PV-ZY-2026-07-03-0001",
  channel: "official-website",
  officialSite: "https://zaiye.studio",
  issuedAt: "2026-07-03",
  notice: "Only downloads from the official website or verified channels are authorized. Keep this release metadata when sharing feedback or exports."
};

let prompts = [];
let selectedId = null;
let activeCategory = "all";
let settings = { storageMode: "local" };
let autoSaveTimer = null;
let isHydrating = false;
let pendingImport = [];
let installId = "";

const els = {
  list: document.getElementById("promptList"),
  search: document.getElementById("search"),
  projectFilter: document.getElementById("projectFilter"),
  sceneFilter: document.getElementById("sceneFilter"),
  genreFilter: document.getElementById("genreFilter"),
  tagFilter: document.getElementById("tagFilter"),
  resetFilters: document.getElementById("resetFilters"),
  categoryTabs: [...document.querySelectorAll("[data-category]")],
  form: document.getElementById("promptForm"),
  newPrompt: document.getElementById("newPrompt"),
  title: document.getElementById("title"),
  project: document.getElementById("project"),
  projectOptions: document.getElementById("projectOptions"),
  scene: document.getElementById("scene"),
  sceneOptions: document.getElementById("sceneOptions"),
  genre: document.getElementById("genre"),
  genreOptions: document.getElementById("genreOptions"),
  category: document.getElementById("category"),
  prompt: document.getElementById("prompt"),
  promptEn: document.getElementById("promptEn"),
  negative: document.getElementById("negative"),
  tags: document.getElementById("tags"),
  tagSuggestions: document.getElementById("tagSuggestions"),
  rating: document.getElementById("rating"),
  imageUrl: document.getElementById("imageUrl"),
  imageFile: document.getElementById("imageFile"),
  preview: document.getElementById("preview"),
  sourceUrl: document.getElementById("sourceUrl"),
  openSource: document.getElementById("openSource"),
  copyPrompt: document.getElementById("copyPrompt"),
  duplicatePrompt: document.getElementById("duplicatePrompt"),
  deletePrompt: document.getElementById("deletePrompt"),
  exportPrompts: document.getElementById("exportPrompts"),
  exportFilteredPrompts: document.getElementById("exportFilteredPrompts"),
  importPrompts: document.getElementById("importPrompts"),
  importFile: document.getElementById("importFile"),
  refreshLibrary: document.getElementById("refreshLibrary"),
  feedbackToggle: document.getElementById("feedbackToggle"),
  feedbackPanel: document.getElementById("feedbackPanel"),
  feedbackType: document.getElementById("feedbackType"),
  feedbackText: document.getElementById("feedbackText"),
  saveFeedback: document.getElementById("saveFeedback"),
  exportFeedback: document.getElementById("exportFeedback"),
  clearFeedbackForm: document.getElementById("clearFeedbackForm"),
  creatorToggle: document.getElementById("creatorToggle"),
  creatorPanel: document.getElementById("creatorPanel"),
  importPanel: document.getElementById("importPanel"),
  importSummary: document.getElementById("importSummary"),
  importList: document.getElementById("importList"),
  selectAllImport: document.getElementById("selectAllImport"),
  invertImport: document.getElementById("invertImport"),
  confirmImport: document.getElementById("confirmImport"),
  cancelImport: document.getElementById("cancelImport"),
  syncToggle: document.getElementById("syncToggle"),
  syncStatus: document.getElementById("syncStatus"),
  manageTaxonomy: document.getElementById("manageTaxonomy"),
  taxonomyPanel: document.getElementById("taxonomyPanel"),
  projectManageSelect: document.getElementById("projectManageSelect"),
  projectRename: document.getElementById("projectRename"),
  renameProject: document.getElementById("renameProject"),
  deleteProject: document.getElementById("deleteProject"),
  sceneManageSelect: document.getElementById("sceneManageSelect"),
  sceneRename: document.getElementById("sceneRename"),
  renameScene: document.getElementById("renameScene"),
  deleteScene: document.getElementById("deleteScene"),
  genreManageSelect: document.getElementById("genreManageSelect"),
  genreRename: document.getElementById("genreRename"),
  renameGenre: document.getElementById("renameGenre"),
  deleteGenre: document.getElementById("deleteGenre"),
  emptyTemplate: document.getElementById("emptyTemplate")
};

function now() {
  return Date.now();
}

function uid() {
  return crypto.randomUUID();
}

async function ensureInstallId() {
  const data = await chrome.storage.local.get({ [INSTALL_ID_KEY]: "" });
  installId = data[INSTALL_ID_KEY] || uid();
  if (!data[INSTALL_ID_KEY]) await chrome.storage.local.set({ [INSTALL_ID_KEY]: installId });
  return installId;
}

function normalizeTags(value) {
  return value
    .split(/[,，]/)
    .map((tag) => tag.trim())
    .filter(Boolean);
}

function normalizeCategory(value) {
  return ["scene", "constraint", "negative"].includes(value) ? value : "scene";
}

function composePrompt(item) {
  const parts = [];
  if (item.prompt?.trim()) parts.push(item.prompt.trim());
  if (item.promptEn?.trim()) parts.push(item.promptEn.trim());
  if (item.negative?.trim()) parts.push(`禁止：${item.negative.trim()}`);
  return parts.join("\n\n");
}

function draftPrompt(overrides = {}) {
  return {
    id: uid(),
    title: "未命名 Prompt",
    project: "",
    scene: "",
    genre: "",
    type: "scene",
    prompt: "",
    promptEn: "",
    negative: "",
    tags: [],
    image: "",
    sourceUrl: "",
    rating: 0,
    createdAt: now(),
    updatedAt: now(),
    sourceProduct: PRODUCT_OWNER.product,
    sourceStudio: PRODUCT_OWNER.studio,
    sourceCreator: PRODUCT_OWNER.creator,
    sourceReleaseId: OFFICIAL_RELEASE.releaseId,
    sourceOfficialSite: OFFICIAL_RELEASE.officialSite,
    sourceInstallId: installId,
    versions: [],
    ...overrides
  };
}

function sanitizePrompt(item) {
  return {
    id: item.id || uid(),
    title: item.title || "未命名 Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || item.customType || "",
    type: normalizeCategory(item.type),
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    createdAt: Number(item.createdAt) || now(),
    updatedAt: Number(item.updatedAt) || now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    sourceReleaseId: item.sourceReleaseId || OFFICIAL_RELEASE.releaseId,
    sourceOfficialSite: item.sourceOfficialSite || OFFICIAL_RELEASE.officialSite,
    sourceInstallId: item.sourceInstallId || installId,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

function syncSafePrompt(item) {
  const safe = sanitizePrompt(item);
  if (safe.image.startsWith("data:")) safe.image = "";
  return safe;
}

async function loadSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: settings });
  settings = { ...settings, ...data[SETTINGS_KEY] };
  els.syncToggle.checked = settings.storageMode === "sync";
  updateSyncStatus();
}

async function saveSettings() {
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  updateSyncStatus();
}

function updateSyncStatus(extra = "") {
  const base = settings.storageMode === "sync" ? "浏览器同步已开启" : "仅保存在本机";
  els.syncStatus.textContent = extra ? `${base}. ${extra}` : base;
}

async function readSyncPrompts() {
  const metaData = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const count = metaData[SYNC_META_KEY]?.count || 0;
  if (!count) return [];
  const keys = Array.from({ length: count }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  const chunks = await chrome.storage.sync.get(keys);
  const json = keys.map((key) => chunks[key] || "").join("");
  if (!json) return [];
  return JSON.parse(json).map(sanitizePrompt);
}

async function writeSyncPrompts(items) {
  const json = JSON.stringify(items.map(syncSafePrompt));
  const chunks = [];
  for (let index = 0; index < json.length; index += SYNC_CHUNK_SIZE) {
    chunks.push(json.slice(index, index + SYNC_CHUNK_SIZE));
  }

  if (chunks.length > 12) {
    throw new Error("同步空间已满。建议使用导出/导入，或把本地图片换成图片链接。");
  }

  const oldMeta = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const oldCount = oldMeta[SYNC_META_KEY]?.count || 0;
  const toRemove = Array.from({ length: oldCount }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  if (toRemove.length) await chrome.storage.sync.remove(toRemove);

  const data = { [SYNC_META_KEY]: { count: chunks.length, updatedAt: now() } };
  chunks.forEach((chunk, index) => {
    data[`${SYNC_CHUNK_PREFIX}${index}`] = chunk;
  });
  await chrome.storage.sync.set(data);
}

async function saveAll() {
  await chrome.storage.local.set({ [LOCAL_KEY]: prompts });
  if (settings.storageMode === "sync") {
    try {
      await writeSyncPrompts(prompts);
    } catch (error) {
      settings.storageMode = "local";
      els.syncToggle.checked = false;
      await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
      updateSyncStatus(`同步失败，已先保存在本机：${error.message}`);
    }
  }
}

async function loadAll() {
  await loadSettings();
  if (settings.storageMode === "sync") {
    try {
      prompts = await readSyncPrompts();
      if (prompts.length) {
        await chrome.storage.local.set({ [LOCAL_KEY]: prompts });
        selectedId = prompts[0].id;
        return;
      }
    } catch (error) {
      updateSyncStatus(error.message);
    }
  }

  const result = await chrome.storage.local.get({ [LOCAL_KEY]: null });
  if (result[LOCAL_KEY]) {
    prompts = result[LOCAL_KEY].map(sanitizePrompt);
    selectedId = prompts[0]?.id || null;
    return;
  }

  prompts = [];
}

function selectedPrompt() {
  return prompts.find((item) => item.id === selectedId) || prompts[0] || null;
}

function uniqueValues(values) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "zh-CN"));
}

function uniqueProjects() {
  return uniqueValues(prompts.map((item) => item.project));
}

function uniqueGenres() {
  return uniqueValues(prompts.map((item) => item.genre));
}

function uniqueScenes(project = "") {
  return uniqueValues(
    prompts
      .filter((item) => !project || item.project === project)
      .map((item) => item.scene)
  );
}

function uniqueTags() {
  return uniqueValues(prompts.flatMap((item) => item.tags || []));
}

function matches(item) {
  const query = els.search.value.trim().toLowerCase();
  const project = els.projectFilter.value;
  const scene = els.sceneFilter.value;
  const genre = els.genreFilter.value;
  const tag = els.tagFilter.value;
  const haystack = [item.title, item.project, item.scene, item.genre, item.type, item.prompt, item.promptEn, item.negative, ...(item.tags || [])].join(" ").toLowerCase();
  return (
    (!query || haystack.includes(query)) &&
    (activeCategory === "all" || item.type === activeCategory) &&
    (project === "all" || (item.project || "") === project) &&
    (scene === "all" || (item.scene || "") === scene) &&
    (genre === "all" || (item.genre || "") === genre) &&
    (tag === "all" || (item.tags || []).includes(tag))
  );
}

function replaceOptions(select, firstLabel, values) {
  const current = select.value;
  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "all";
  all.textContent = firstLabel;
  select.append(all);
  for (const value of values) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.append(option);
  }
  select.value = values.includes(current) ? current : "all";
}

function replaceManageOptions(select, values) {
  const current = select.value;
  select.innerHTML = "";
  if (!values.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "暂无可管理项";
    select.append(option);
    return;
  }
  for (const value of values) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.append(option);
  }
  select.value = values.includes(current) ? current : values[0];
}

function renderTaxonomy() {
  const projects = uniqueProjects();
  const filteredProject = els.projectFilter.value === "all" ? "" : els.projectFilter.value;
  const scenes = uniqueScenes(filteredProject);
  const editorScenes = uniqueScenes(els.project.value.trim());
  const genres = uniqueGenres();
  const tags = uniqueTags();

  replaceOptions(els.projectFilter, "全部项目", projects);
  replaceOptions(els.sceneFilter, "全部场景", scenes);
  replaceOptions(els.genreFilter, "全部类型", genres);
  replaceOptions(els.tagFilter, "全部标签", tags);
  replaceManageOptions(els.projectManageSelect, projects);
  replaceManageOptions(els.sceneManageSelect, uniqueScenes(els.projectManageSelect.value));
  replaceManageOptions(els.genreManageSelect, genres);

  els.projectOptions.innerHTML = "";
  for (const project of projects) {
    const option = document.createElement("option");
    option.value = project;
    els.projectOptions.append(option);
  }

  els.sceneOptions.innerHTML = "";
  for (const scene of editorScenes) {
    const option = document.createElement("option");
    option.value = scene;
    els.sceneOptions.append(option);
  }

  els.genreOptions.innerHTML = "";
  for (const genre of genres) {
    const option = document.createElement("option");
    option.value = genre;
    els.genreOptions.append(option);
  }

  els.tagSuggestions.innerHTML = "";
  for (const tag of tags.slice(0, 24)) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = tag;
    button.addEventListener("click", () => addTag(tag));
    els.tagSuggestions.append(button);
  }
}

function addTag(tag) {
  const tags = normalizeTags(els.tags.value);
  if (!tags.includes(tag)) tags.push(tag);
  els.tags.value = tags.join(", ");
}

function renderCategoryTabs() {
  for (const button of els.categoryTabs) {
    button.setAttribute("aria-pressed", String(button.dataset.category === activeCategory));
  }
}

function renderList() {
  renderCategoryTabs();
  const visible = prompts.filter(matches);
  els.list.innerHTML = "";

  if (!visible.length) {
    els.list.append(els.emptyTemplate.content.cloneNode(true));
    return;
  }

  for (const item of visible) {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "prompt-card";
    card.setAttribute("aria-selected", String(item.id === selectedId));

    const thumb = item.image
      ? `<img class="thumb" alt="" src="${item.image}">`
      : `<div class="thumb fallback-thumb">${CATEGORY_LABELS[item.type] || "P"}</div>`;

    card.innerHTML = `
      <div class="prompt-card-top">
        ${thumb}
        <div>
          <h2></h2>
          <div class="meta">
            <span class="chip" data-category></span>
            <span class="chip" data-project></span>
            <span class="chip" data-scene></span>
            <span class="chip" data-genre></span>
          </div>
        </div>
      </div>
      <div class="excerpt"></div>
    `;
    card.querySelector("h2").textContent = item.title || "未命名 Prompt";
    card.querySelector("[data-category]").textContent = CATEGORY_LABELS[item.type] || item.type;
    card.querySelector("[data-project]").textContent = item.project || "未分项目";
    card.querySelector("[data-scene]").textContent = item.scene || "未分场景";
    card.querySelector("[data-genre]").textContent = item.genre || "未分类型";
    card.querySelector(".excerpt").textContent = composePrompt(item);
    card.addEventListener("click", async () => {
      await persistCurrentForm();
      selectedId = item.id;
      render();
    });
    els.list.append(card);
  }
}

function fillEditor(item) {
  isHydrating = true;
  if (!item) {
    els.form.reset();
    els.preview.removeAttribute("src");
    isHydrating = false;
    return;
  }
  els.title.value = item.title || "";
  els.project.value = item.project || "";
  els.scene.value = item.scene || "";
  els.genre.value = item.genre || "";
  els.category.value = item.type || "scene";
  els.prompt.value = item.prompt || "";
  els.promptEn.value = item.promptEn || "";
  els.negative.value = item.negative || "";
  els.tags.value = (item.tags || []).join(", ");
  els.rating.value = item.rating || 0;
  els.imageUrl.value = item.image || "";
  els.sourceUrl.value = item.sourceUrl || "";
  if (item.image) els.preview.src = item.image;
  else els.preview.removeAttribute("src");
  isHydrating = false;
}

function render() {
  if (!selectedId && prompts.length) selectedId = prompts[0].id;
  renderTaxonomy();
  renderList();
  fillEditor(selectedPrompt());
}

function clearFilters() {
  activeCategory = "all";
  els.search.value = "";
  clearTopFilters();
}

function clearTopFilters() {
  els.projectFilter.value = "all";
  els.sceneFilter.value = "all";
  els.genreFilter.value = "all";
  els.tagFilter.value = "all";
  renderTaxonomy();
}

function revealItem(item) {
  if (!item || matches(item)) return;
  clearFilters();
}

function formValue() {
  return {
    title: els.title.value.trim() || "未命名 Prompt",
    project: els.project.value.trim(),
    scene: els.scene.value.trim(),
    genre: els.genre.value.trim(),
    type: els.category.value,
    prompt: els.prompt.value.trim(),
    promptEn: els.promptEn.value.trim(),
    negative: els.negative.value.trim(),
    tags: normalizeTags(els.tags.value),
    rating: Number(els.rating.value) || 0,
    image: els.imageUrl.value.trim(),
    sourceUrl: els.sourceUrl.value.trim()
  };
}

async function saveDraft() {
  if (isHydrating || !selectedId) return;
  await chrome.storage.local.set({
    [DRAFT_KEY]: {
      selectedId,
      savedAt: now(),
      data: formValue()
    }
  });
}

async function recoverDraft() {
  const result = await chrome.storage.local.get({ [DRAFT_KEY]: null });
  const draft = result[DRAFT_KEY];
  if (!draft?.selectedId || !draft.data) return;
  const item = prompts.find((prompt) => prompt.id === draft.selectedId);
  if (!item) return;
  if ((item.updatedAt || 0) > (draft.savedAt || 0)) return;
  Object.assign(item, sanitizePrompt({ ...item, ...draft.data, id: item.id, updatedAt: draft.savedAt }));
  selectedId = item.id;
  await saveAll();
}

async function persistCurrentForm({ withVersion = false, redraw = false } = {}) {
  const current = selectedPrompt();
  if (!current) return;
  const data = formValue();
  const previous = { ...current };
  Object.assign(current, data, { updatedAt: now() });
  if (withVersion && (previous.prompt !== data.prompt || previous.promptEn !== data.promptEn || previous.negative !== data.negative)) {
    current.versions = [{ prompt: previous.prompt, promptEn: previous.promptEn || "", negative: previous.negative, savedAt: now() }, ...(current.versions || [])].slice(0, 20);
  }
  await saveAll();
  await chrome.storage.local.remove(DRAFT_KEY);
  updateSyncStatus(withVersion ? "已保存" : "已自动保存");
  if (redraw) {
    revealItem(current);
    render();
  }
}

function scheduleAutoSave() {
  if (isHydrating || !selectedId) return;
  saveDraft();
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(() => {
    persistCurrentForm({ redraw: true });
  }, 450);
}

function normalizeUrl(value) {
  const url = value.trim();
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  return `https://${url}`;
}

async function extensionVersion() {
  return chrome.runtime.getManifest().version || "";
}

async function makeFeedbackEntry() {
  return {
    id: uid(),
    product: PRODUCT_OWNER.product,
    studio: PRODUCT_OWNER.studio,
    creator: PRODUCT_OWNER.creator,
    version: await extensionVersion(),
    release: OFFICIAL_RELEASE,
    installId,
    type: els.feedbackType.value,
    content: els.feedbackText.value.trim(),
    createdAt: new Date().toISOString(),
    userAgent: navigator.userAgent
  };
}

function formatFeedback(entry) {
  return [
    "Prompt Vault 意见反馈",
    `类型：${entry.type}`,
    `版本：${entry.version}`,
    `时间：${entry.createdAt}`,
    "",
    entry.content
  ].join("\n");
}

async function readFeedback() {
  const data = await chrome.storage.local.get({ [FEEDBACK_KEY]: [] });
  return Array.isArray(data[FEEDBACK_KEY]) ? data[FEEDBACK_KEY] : [];
}

async function saveFeedbackEntry(entry) {
  const feedback = await readFeedback();
  feedback.unshift(entry);
  await chrome.storage.local.set({ [FEEDBACK_KEY]: feedback.slice(0, 200) });
}

function clearFeedbackForm() {
  els.feedbackType.value = "bug";
  els.feedbackText.value = "";
}

async function exportFeedbackLibrary() {
  const feedback = await readFeedback();
  const payload = {
    app: "Prompt Vault",
    type: "feedback",
    owner: PRODUCT_OWNER,
    release: OFFICIAL_RELEASE,
    installId,
    exportedAt: new Date().toISOString(),
    count: feedback.length,
    feedback
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `prompt-vault-feedback-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  updateSyncStatus(`已导出 ${feedback.length} 条反馈`);
}

function loadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.addEventListener("load", () => {
      URL.revokeObjectURL(url);
      resolve(image);
    });
    image.addEventListener("error", () => {
      URL.revokeObjectURL(url);
      reject(new Error("图片读取失败"));
    });
    image.src = url;
  });
}

async function compressImageFile(file) {
  const image = await loadImageFromFile(file);
  const scale = Math.min(1, IMAGE_MAX_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * scale));
  const height = Math.max(1, Math.round(image.naturalHeight * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(image, 0, 0, width, height);

  const webp = canvas.toDataURL("image/webp", IMAGE_QUALITY);
  if (webp.startsWith("data:image/webp")) return webp;
  return canvas.toDataURL("image/jpeg", IMAGE_QUALITY);
}

async function getActiveTabUrl() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0]?.url || "";
}

function currentExportScope(mode) {
  return {
    mode,
    category: activeCategory,
    search: els.search.value.trim(),
    project: els.projectFilter.value,
    scene: els.sceneFilter.value,
    genre: els.genreFilter.value,
    tag: els.tagFilter.value
  };
}

function exportLibrary(items = prompts, scope = currentExportScope("all")) {
  const payload = {
    app: "Prompt Vault",
    version: 4,
    owner: PRODUCT_OWNER,
    release: OFFICIAL_RELEASE,
    installId,
    provenance: {
      exportedBy: "Prompt Vault",
      studio: PRODUCT_OWNER.studio,
      creator: PRODUCT_OWNER.creator,
      releaseId: OFFICIAL_RELEASE.releaseId,
      officialSite: OFFICIAL_RELEASE.officialSite,
      notice: "This export contains creator attribution, official release metadata, and anonymous install provenance for anti-rebranding and source tracing."
    },
    exportScope: scope,
    count: items.length,
    exportedAt: new Date().toISOString(),
    prompts: items.map(sanitizePrompt)
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  const suffix = scope.mode === "filtered" ? "filtered" : "all";
  link.download = `prompt-vault-${suffix}-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  updateSyncStatus(`已导出 ${items.length} 条 Prompt`);
}

function exportFilteredLibrary() {
  const visible = prompts.filter(matches);
  exportLibrary(visible, currentExportScope("filtered"));
}

async function importLibrary(file) {
  const text = await file.text();
  const payload = JSON.parse(text);
  const incoming = Array.isArray(payload) ? payload : payload.prompts;
  if (!Array.isArray(incoming)) throw new Error("这个文件不像 Prompt Vault 导出的 JSON。");

  pendingImport = incoming.map(sanitizePrompt);
  renderImportPreview();
  updateSyncStatus(`已读取 ${pendingImport.length} 条，请选择要导入的 Prompt`);
}

function renderImportPreview() {
  els.importList.innerHTML = "";
  els.importPanel.hidden = pendingImport.length === 0;
  els.importSummary.textContent = `待导入 ${pendingImport.length} 条 Prompt`;

  for (const item of pendingImport) {
    const row = document.createElement("label");
    row.className = "import-row";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = true;
    checkbox.dataset.id = item.id;

    const body = document.createElement("span");
    body.className = "import-row-body";

    const title = document.createElement("strong");
    title.textContent = item.title || "未命名 Prompt";

    const meta = document.createElement("span");
    meta.className = "import-row-meta";
    meta.textContent = [CATEGORY_LABELS[item.type], item.project, item.scene, item.genre, ...(item.tags || [])]
      .filter(Boolean)
      .join(" / ");

    body.append(title, meta);
    row.append(checkbox, body);
    els.importList.append(row);
  }
}

function selectedImportItems() {
  const selected = new Set(
    [...els.importList.querySelectorAll("input[type='checkbox']:checked")].map((input) => input.dataset.id)
  );
  return pendingImport.filter((item) => selected.has(item.id));
}

async function confirmImportSelected() {
  const incoming = selectedImportItems();
  if (!incoming.length) {
    updateSyncStatus("还没有选择要导入的 Prompt");
    return;
  }

  const byId = new Map(prompts.map((item) => [item.id, item]));
  for (const item of incoming.map(sanitizePrompt)) {
    byId.set(item.id, { ...byId.get(item.id), ...item, updatedAt: now() });
  }
  prompts = Array.from(byId.values()).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  selectedId = incoming[0]?.id || prompts[0]?.id || null;
  pendingImport = [];
  els.importPanel.hidden = true;
  await saveAll();
  clearFilters();
  render();
  updateSyncStatus(`已导入 ${incoming.length} 条 Prompt`);
}

async function renameField(field, select, input) {
  await persistCurrentForm();
  const oldValue = select.value;
  const newValue = input.value.trim();
  if (!oldValue || !newValue || oldValue === newValue) return;
  prompts = prompts.map((item) => (item[field] === oldValue ? { ...item, [field]: newValue, updatedAt: now() } : item));
  input.value = "";
  await saveAll();
  render();
}

async function deleteField(field, select) {
  await persistCurrentForm();
  const oldValue = select.value;
  if (!oldValue) return;
  prompts = prompts.map((item) => {
    if (field === "project" && item.project === oldValue) {
      return { ...item, project: "", scene: "", updatedAt: now() };
    }
    return item[field] === oldValue ? { ...item, [field]: "", updatedAt: now() } : item;
  });
  await saveAll();
  render();
}

async function renameScene() {
  await persistCurrentForm();
  const oldValue = els.sceneManageSelect.value;
  const newValue = els.sceneRename.value.trim();
  const project = els.projectManageSelect.value;
  if (!oldValue || !newValue || oldValue === newValue) return;
  prompts = prompts.map((item) => {
    const projectMatches = !project || item.project === project;
    return projectMatches && item.scene === oldValue ? { ...item, scene: newValue, updatedAt: now() } : item;
  });
  els.sceneRename.value = "";
  await saveAll();
  render();
}

async function deleteScene() {
  await persistCurrentForm();
  const oldValue = els.sceneManageSelect.value;
  const project = els.projectManageSelect.value;
  if (!oldValue) return;
  prompts = prompts.map((item) => {
    const projectMatches = !project || item.project === project;
    return projectMatches && item.scene === oldValue ? { ...item, scene: "", updatedAt: now() } : item;
  });
  await saveAll();
  render();
}

els.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  await persistCurrentForm({ withVersion: true, redraw: true });
});

els.newPrompt.addEventListener("click", async () => {
  clearTimeout(autoSaveTimer);
  await persistCurrentForm();
  await chrome.storage.local.remove(DRAFT_KEY);
  const item = draftPrompt({ sourceUrl: await getActiveTabUrl() });
  prompts.unshift(item);
  selectedId = item.id;
  clearFilters();
  await saveAll();
  render();
  els.title.focus();
  els.title.select();
});

els.copyPrompt.addEventListener("click", async () => {
  await persistCurrentForm();
  const item = selectedPrompt();
  if (item) await navigator.clipboard.writeText(composePrompt({ ...item, ...formValue() }));
});

els.duplicatePrompt.addEventListener("click", async () => {
  await persistCurrentForm();
  const item = selectedPrompt();
  if (!item) return;
  const copy = draftPrompt({ ...item, ...formValue(), id: uid(), title: `${els.title.value.trim() || item.title} 副本`, createdAt: now(), updatedAt: now() });
  prompts.unshift(copy);
  selectedId = copy.id;
  await saveAll();
  render();
});

els.deletePrompt.addEventListener("click", async () => {
  if (!selectedId) return;
  prompts = prompts.filter((item) => item.id !== selectedId);
  selectedId = prompts[0]?.id || null;
  await saveAll();
  render();
});

els.exportPrompts.addEventListener("click", () => exportLibrary());
els.exportFilteredPrompts.addEventListener("click", exportFilteredLibrary);
els.importPrompts.addEventListener("click", () => els.importFile.click());
els.importFile.addEventListener("change", async () => {
  const file = els.importFile.files?.[0];
  if (!file) return;
  try {
    await importLibrary(file);
  } catch (error) {
    updateSyncStatus(error.message);
  } finally {
    els.importFile.value = "";
  }
});

els.refreshLibrary.addEventListener("click", async () => {
  await loadAll();
  render();
  updateSyncStatus("已刷新");
});

els.feedbackToggle.addEventListener("click", () => {
  els.feedbackPanel.hidden = !els.feedbackPanel.hidden;
  if (!els.feedbackPanel.hidden) els.feedbackText.focus();
});

els.creatorToggle.addEventListener("click", () => {
  els.creatorPanel.hidden = !els.creatorPanel.hidden;
});

els.saveFeedback.addEventListener("click", async () => {
  const entry = await makeFeedbackEntry();
  if (!entry.content) {
    updateSyncStatus("请先填写反馈内容");
    return;
  }
  await saveFeedbackEntry(entry);
  await navigator.clipboard.writeText(formatFeedback(entry));
  updateSyncStatus("反馈已复制到剪贴板；当前不会自动发送");
  clearFeedbackForm();
});

els.exportFeedback.addEventListener("click", exportFeedbackLibrary);
els.clearFeedbackForm.addEventListener("click", clearFeedbackForm);

els.selectAllImport.addEventListener("click", () => {
  els.importList.querySelectorAll("input[type='checkbox']").forEach((input) => {
    input.checked = true;
  });
});

els.invertImport.addEventListener("click", () => {
  els.importList.querySelectorAll("input[type='checkbox']").forEach((input) => {
    input.checked = !input.checked;
  });
});

els.confirmImport.addEventListener("click", confirmImportSelected);

els.cancelImport.addEventListener("click", () => {
  pendingImport = [];
  els.importPanel.hidden = true;
  els.importList.innerHTML = "";
  updateSyncStatus("已取消导入");
});

els.openSource.addEventListener("click", async () => {
  await persistCurrentForm();
  const url = normalizeUrl(els.sourceUrl.value);
  if (url) await chrome.tabs.create({ url });
});

els.manageTaxonomy.addEventListener("click", () => {
  els.taxonomyPanel.hidden = !els.taxonomyPanel.hidden;
});
els.renameProject.addEventListener("click", () => renameField("project", els.projectManageSelect, els.projectRename));
els.deleteProject.addEventListener("click", () => deleteField("project", els.projectManageSelect));
els.renameScene.addEventListener("click", renameScene);
els.deleteScene.addEventListener("click", deleteScene);
els.renameGenre.addEventListener("click", () => renameField("genre", els.genreManageSelect, els.genreRename));
els.deleteGenre.addEventListener("click", () => deleteField("genre", els.genreManageSelect));

els.syncToggle.addEventListener("change", async () => {
  settings.storageMode = els.syncToggle.checked ? "sync" : "local";
  await saveSettings();
  if (settings.storageMode === "sync") {
    try {
      const remote = await readSyncPrompts();
      const byId = new Map([...remote, ...prompts].map((item) => [item.id, sanitizePrompt(item)]));
      prompts = Array.from(byId.values()).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      await saveAll();
      selectedId = prompts[0]?.id || null;
      updateSyncStatus("已合并本机和同步中的 Prompt");
    } catch (error) {
      settings.storageMode = "local";
      els.syncToggle.checked = false;
      await saveSettings();
      updateSyncStatus(error.message);
    }
  }
  render();
});

els.categoryTabs.forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    if (activeCategory === "constraint" || activeCategory === "negative") clearTopFilters();
    renderList();
  });
});

els.search.addEventListener("input", renderList);
els.resetFilters.addEventListener("click", () => {
  clearFilters();
  render();
});
els.projectFilter.addEventListener("change", () => {
  renderTaxonomy();
  renderList();
});
els.sceneFilter.addEventListener("change", renderList);
els.genreFilter.addEventListener("change", renderList);
els.tagFilter.addEventListener("change", renderList);
els.projectManageSelect.addEventListener("change", renderTaxonomy);
els.form.addEventListener("input", scheduleAutoSave);
els.form.addEventListener("change", scheduleAutoSave);
els.project.addEventListener("input", () => {
  renderTaxonomy();
});
els.imageUrl.addEventListener("input", () => {
  if (els.imageUrl.value.trim()) els.preview.src = els.imageUrl.value.trim();
  else els.preview.removeAttribute("src");
});

els.imageFile.addEventListener("change", async () => {
  const file = els.imageFile.files?.[0];
  if (!file) return;
  try {
    const compressed = await compressImageFile(file);
    els.imageUrl.value = compressed;
    els.preview.src = compressed;
    scheduleAutoSave();
    updateSyncStatus("图片已压缩");
  } catch (error) {
    updateSyncStatus(error.message || "图片压缩失败");
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") persistCurrentForm();
});
window.addEventListener("pagehide", () => persistCurrentForm());

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "sync" || settings.storageMode !== "sync") return;
  if (!changes[SYNC_META_KEY]) return;
  prompts = await readSyncPrompts();
  selectedId = selectedId || prompts[0]?.id || null;
  render();
  updateSyncStatus("已从浏览器同步更新");
});

ensureInstallId()
  .then(loadAll)
  .then(recoverDraft)
  .then(render);
