const MENU_SAVE_SELECTION = "prompt-vault-save-selection";
const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const SYNC_META_KEY = "promptVaultSyncMeta";
const SYNC_CHUNK_PREFIX = "promptVaultChunk";
const SYNC_CHUNK_SIZE = 7000;
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "再野文化工作室（个人独资）",
  creator: "田田田野里"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_SAVE_SELECTION,
    title: "保存为 Prompt",
    contexts: ["selection"]
  });
});

function sanitizePrompt(item) {
  return {
    id: item.id || crypto.randomUUID(),
    title: item.title || "未命名 Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || "",
    type: ["scene", "constraint", "negative"].includes(item.type) ? item.type : "scene",
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    createdAt: Number(item.createdAt) || Date.now(),
    updatedAt: Number(item.updatedAt) || Date.now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

function syncSafePrompt(item) {
  const safe = sanitizePrompt(item);
  if (safe.image.startsWith("data:")) safe.image = "";
  return safe;
}

async function getSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: { storageMode: "local" } });
  return data[SETTINGS_KEY];
}

async function readSyncPrompts() {
  const metaData = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const count = metaData[SYNC_META_KEY]?.count || 0;
  if (!count) return [];
  const keys = Array.from({ length: count }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  const chunks = await chrome.storage.sync.get(keys);
  const json = keys.map((key) => chunks[key] || "").join("");
  return json ? JSON.parse(json).map(sanitizePrompt) : [];
}

async function writeSyncPrompts(items) {
  const json = JSON.stringify(items.map(syncSafePrompt));
  const chunks = [];
  for (let index = 0; index < json.length; index += SYNC_CHUNK_SIZE) {
    chunks.push(json.slice(index, index + SYNC_CHUNK_SIZE));
  }

  const oldMeta = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const oldCount = oldMeta[SYNC_META_KEY]?.count || 0;
  const toRemove = Array.from({ length: oldCount }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  if (toRemove.length) await chrome.storage.sync.remove(toRemove);

  const data = { [SYNC_META_KEY]: { count: chunks.length, updatedAt: Date.now() } };
  chunks.forEach((chunk, index) => {
    data[`${SYNC_CHUNK_PREFIX}${index}`] = chunk;
  });
  await chrome.storage.sync.set(data);
}

async function getPrompts() {
  const settings = await getSettings();
  if (settings.storageMode === "sync") {
    const synced = await readSyncPrompts();
    if (synced.length) return synced;
  }
  const data = await chrome.storage.local.get({ [LOCAL_KEY]: [] });
  return data[LOCAL_KEY].map(sanitizePrompt);
}

async function setPrompts(items) {
  const prompts = items.map(sanitizePrompt);
  await chrome.storage.local.set({ [LOCAL_KEY]: prompts });
  const settings = await getSettings();
  if (settings.storageMode === "sync") await writeSyncPrompts(prompts);
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_SAVE_SELECTION || !info.selectionText) return;
  const text = info.selectionText.trim();
  if (!text) return;

  const prompt = {
    id: crypto.randomUUID(),
    title: text.slice(0, 36) || "未命名 Prompt",
    project: "",
    scene: "",
    genre: "",
    type: "scene",
    prompt: text,
    promptEn: "",
    negative: "",
    tags: [],
    image: "",
    sourceUrl: info.pageUrl || "",
    rating: 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    sourceProduct: PRODUCT_OWNER.product,
    sourceStudio: PRODUCT_OWNER.studio,
    sourceCreator: PRODUCT_OWNER.creator,
    versions: []
  };

  const prompts = await getPrompts();
  await setPrompts([prompt, ...prompts]);
});
