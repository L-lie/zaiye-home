const fs = require("fs");
const http = require("http");
const os = require("os");
const path = require("path");
const { chromium } = require("playwright");

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const chromeMock = `
<script>
(() => {
  const createStore = () => {
    const values = {};
    return {
      async get(keys) {
        if (keys == null) return { ...values };
        if (typeof keys === "string") return { [keys]: values[keys] };
        if (Array.isArray(keys)) return Object.fromEntries(keys.map((key) => [key, values[key]]));
        return Object.assign({}, keys, Object.fromEntries(Object.keys(keys).filter((key) => key in values).map((key) => [key, values[key]])));
      },
      async set(next) { Object.assign(values, next || {}); },
      async remove(keys) { for (const key of Array.isArray(keys) ? keys : [keys]) delete values[key]; }
    };
  };
  const local = createStore();
  const sync = createStore();
  const session = createStore();
  window.chrome = {
    permissions: { contains: async () => true, request: async () => true },
    runtime: {
      getManifest: () => ({ version: "1.1.4" }),
      getURL: (resource) => new URL(resource, location.href).href,
      sendMessage: async () => null
    },
    storage: {
      local,
      sync,
      session,
      onChanged: { addListener() {} }
    },
    tabs: {
      create: async () => null,
      query: async () => [{ id: 1 }],
      sendMessage: async () => null
    }
  };
})();
</script>
`;

function startStaticServer(root) {
  const server = http.createServer((request, response) => {
    const pathname = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
    const requested = pathname === "/" ? "popup.html" : pathname.slice(1);
    const file = path.resolve(root, requested);
    if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      response.writeHead(404);
      response.end("Not found");
      return;
    }
    let content = fs.readFileSync(file);
    if (file.endsWith(".html")) {
      content = Buffer.from(content.toString("utf8").replace('<script src="popup.js"></script>', `${chromeMock}<script src="popup.js"></script>`));
    }
    const type = file.endsWith(".html") ? "text/html; charset=utf-8"
      : file.endsWith(".js") ? "text/javascript; charset=utf-8"
        : file.endsWith(".css") ? "text/css; charset=utf-8"
          : file.endsWith(".json") ? "application/json; charset=utf-8"
            : "application/octet-stream";
    response.writeHead(200, { "Content-Type": type });
    response.end(content);
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve(server));
  });
}

(async () => {
  const extensionPath = path.resolve(__dirname, "..");
  const server = await startStaticServer(extensionPath);
  const address = server.address();
  const baseUrl = `http://127.0.0.1:${address.port}`;
  const installedChrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const executablePath = fs.existsSync(installedChrome) ? installedChrome : chromium.executablePath();
  const browser = await chromium.launch({
    headless: true,
    executablePath
  });
  const context = await browser.newContext();
  await context.route("https://zaiye.art/**", (route) => route.abort());

  try {
    const page = await context.newPage();
    await page.setViewportSize({ width: 760, height: 580 });
    await page.goto(`${baseUrl}/popup.html`);
    await page.getByRole("button", { name: "灵感" }).click();
    await page.getByText(/灵感资源 24 条/).waitFor({ timeout: 12000 });

    let cards = page.locator(".resource-card");
    assert(await cards.count() === 24, "资源库应显示 24 张卡片");

    const search = page.locator('[data-resource-filter="query"]');
    await search.fill("镜头穿模");
    await page.getByText(/灵感资源 1\/24 条/).waitFor();
    cards = page.locator(".resource-card");
    assert(await cards.count() === 1, "搜索“镜头穿模”应只剩 1 条");
    assert((await cards.first().innerText()).includes("运镜提示词"), "搜索结果应为运镜提示词");

    await search.fill("");
    const category = page.locator('[data-resource-filter="category"]');
    await category.selectOption("coding");
    await page.getByText(/灵感资源 4\/24 条/).waitFor();
    assert(await page.locator(".resource-card").count() === 4, "编程类别应有 4 条");

    await category.selectOption("all");
    const firstCard = page.locator(".resource-card").first();
    await firstCard.getByRole("button", { name: "查看详情" }).click();
    const dialog = page.locator("#inspirationDetailDialog");
    await dialog.waitFor({ state: "visible" });
    assert(await dialog.locator(".resource-detail-title").innerText(), "详情应显示标题");
    assert(await dialog.locator(".resource-prompt-preview pre").innerText(), "详情应显示完整 Prompt");

    const firstVariable = dialog.locator(".resource-variable-fields input").first();
    assert(await firstVariable.count() === 1, "详情应显示变量输入框");
    await firstVariable.fill("测试主题");
    assert((await dialog.locator(".resource-prompt-preview pre").innerText()).includes("测试主题"), "变量应实时替换");
    await page.screenshot({ path: path.join(os.tmpdir(), "prompt-vault-resource-detail.png"), fullPage: true });
    await page.evaluate(() => {
      document.documentElement.dataset.theme = "dark";
    });
    const darkDialogBackground = await dialog.evaluate((element) => getComputedStyle(element).backgroundColor);
    assert(darkDialogBackground !== "rgb(255, 255, 255)", "详情弹窗应适配深色主题");
    await page.screenshot({ path: path.join(os.tmpdir(), "prompt-vault-resource-detail-dark.png"), fullPage: true });
    await page.evaluate(() => {
      document.documentElement.dataset.theme = "light";
    });

    await dialog.getByRole("button", { name: "收藏到我的库" }).click();
    await page.locator("#title").waitFor({ state: "visible" });
    assert(await page.locator("#title").inputValue() === "结构化文章起草", "收藏后应打开新条目编辑页");
    assert(!(await page.getByText(/灵感资源 24 条/).count()), "收藏后应返回我的库");

    await page.getByRole("button", { name: "灵感" }).click();
    await page.getByText(/灵感资源 24 条/).waitFor();
    await page.screenshot({ path: path.join(os.tmpdir(), "prompt-vault-resource-library.png"), fullPage: true });

    const sidepanel = await context.newPage();
    await sidepanel.setViewportSize({ width: 420, height: 760 });
    await sidepanel.goto(`${baseUrl}/sidepanel.html`);
    await sidepanel.getByRole("button", { name: "灵感" }).click();
    await sidepanel.getByText(/灵感资源 24 条/).waitFor({ timeout: 12000 });
    await sidepanel.locator(".resource-card").first().click();
    await sidepanel.locator("#inspirationDetailDialog").waitFor({ state: "visible" });
    assert(await sidepanel.locator(".resource-variable-fields input").count() > 0, "侧边栏详情应显示变量输入框");
    await sidepanel.screenshot({ path: path.join(os.tmpdir(), "prompt-vault-resource-sidepanel.png"), fullPage: true });

    process.stdout.write("OK popup browse/search/filter/detail/variables/collect\n");
    process.stdout.write("OK sidepanel responsive detail\n");
    process.stdout.write(`SCREENSHOT ${path.join(os.tmpdir(), "prompt-vault-resource-library.png")}\n`);
    process.stdout.write(`SCREENSHOT ${path.join(os.tmpdir(), "prompt-vault-resource-detail.png")}\n`);
    process.stdout.write(`SCREENSHOT ${path.join(os.tmpdir(), "prompt-vault-resource-detail-dark.png")}\n`);
    process.stdout.write(`SCREENSHOT ${path.join(os.tmpdir(), "prompt-vault-resource-sidepanel.png")}\n`);
  } finally {
    await context.close();
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
