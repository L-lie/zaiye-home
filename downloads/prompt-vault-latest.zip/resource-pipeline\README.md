# Prompt Vault resource review queue

candidates.json is the local review queue. It must never include private user prompts.

Each candidate must include sourceUrl, sourceName, author when available, license
or written reuse permission, capturedAt, reviewStatus (pending, approved, or
rejected), and reviewNote.

Only approved entries whose license allows redistribution may be copied into
the docs/resources.json file. Commit and push the docs folder to update the
public resource library. Do not publish entries merely because they are visible
on a prompt website.

Validate the extension, docs, and website copies before publishing:

```powershell
node .\resource-pipeline\validate-library.js `
  .\resources\inspiration-library.json `
  .\docs\resources.json `
  "E:\work\3.工作室\llie-studio-site\prompt-vault-resources.json"
```

The validator checks schema version, required fields, duplicate IDs, categories,
Prompt variables, HTTPS source URLs, and accidental local absolute paths.
