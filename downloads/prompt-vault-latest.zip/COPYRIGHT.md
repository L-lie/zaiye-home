# Prompt Vault Copyright Notice

Copyright (c) 2026 田田田野里 / 再野文化工作室. All rights reserved.

Prompt Vault is a browser extension created by 田田田野里 / 再野文化工作室 for collecting, organizing, previewing, importing, exporting, and reusing AI prompts.

Unless you have prior written permission from the copyright holder, you may not:

- remove or hide creator, studio, copyright, or provenance information;
- rebrand, resell, sublicense, redistribute, or republish this extension as your own product;
- publish a modified version that removes attribution;
- use the code, interface structure, bundled assets, or release metadata as the basis of a competing extension.

Exported JSON files may contain Prompt Vault source metadata, including product name, studio, creator, official site, release ID, and install provenance. This metadata is kept for attribution, source tracing, and anti-rebranding purposes.

Official site: http://zaiye.art/
