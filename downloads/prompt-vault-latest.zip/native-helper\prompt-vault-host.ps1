$ErrorActionPreference = "Stop"
$dataDirectory = Join-Path ([Environment]::GetFolderPath("LocalApplicationData")) "ZaiyePromptVault"
$libraryPath = Join-Path $dataDirectory "shared-library.json"
$transferDirectory = Join-Path $dataDirectory "transfers"
New-Item -ItemType Directory -Force -Path $dataDirectory, $transferDirectory | Out-Null

function Read-Exact([System.IO.Stream]$Stream, [int]$Length) {
  $buffer = New-Object byte[] $Length
  $offset = 0
  while ($offset -lt $Length) {
    $count = $Stream.Read($buffer, $offset, $Length - $offset)
    if ($count -le 0) { return $null }
    $offset += $count
  }
  return $buffer
}

function Write-Response($Response) {
  $json = $Response | ConvertTo-Json -Compress -Depth 40
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $output = [Console]::OpenStandardOutput()
  $length = [BitConverter]::GetBytes([int]$bytes.Length)
  $output.Write($length, 0, $length.Length)
  $output.Write($bytes, 0, $bytes.Length)
  $output.Flush()
}

function Read-Library() {
  if (-not (Test-Path -LiteralPath $libraryPath)) {
    return @{ prompts = @(); updatedAt = 0 }
  }
  try {
    $raw = Get-Content -LiteralPath $libraryPath -Raw -Encoding UTF8 | ConvertFrom-Json
    return @{ prompts = @($raw.prompts); updatedAt = [int64]$raw.updatedAt }
  } catch {
    return @{ prompts = @(); updatedAt = 0 }
  }
}

function Write-Library($Payload) {
  $temporaryPath = "$libraryPath.tmp"
  $Payload | ConvertTo-Json -Compress -Depth 40 | Set-Content -LiteralPath $temporaryPath -Encoding UTF8
  Move-Item -LiteralPath $temporaryPath -Destination $libraryPath -Force
}

$input = [Console]::OpenStandardInput()
while ($true) {
  $lengthBytes = Read-Exact $input 4
  if ($null -eq $lengthBytes) { break }
  $length = [BitConverter]::ToInt32($lengthBytes, 0)
  if ($length -le 0 -or $length -gt 1048576) { Write-Response @{ ok = $false; error = "Invalid message length" }; continue }
  $messageBytes = Read-Exact $input $length
  if ($null -eq $messageBytes) { break }
  try {
    $message = [System.Text.Encoding]::UTF8.GetString($messageBytes) | ConvertFrom-Json
    switch ($message.type) {
      "read-library" {
        $library = Read-Library
        Write-Response @{ ok = $true; prompts = @($library.prompts); updatedAt = $library.updatedAt }
      }
      "write-library-chunk" {
        $transferId = [string]$message.transferId
        $index = [int]$message.index
        $total = [int]$message.total
        if ($transferId -notmatch '^[a-zA-Z0-9-]{8,80}$' -or $index -lt 0 -or $total -lt 1 -or $index -ge $total) { throw "Invalid transfer" }
        [string]$message.chunk | Set-Content -LiteralPath (Join-Path $transferDirectory "$transferId.$index.part") -Encoding UTF8 -NoNewline
        Write-Response @{ ok = $true }
      }
      "commit-library" {
        $transferId = [string]$message.transferId
        if ($transferId -notmatch '^[a-zA-Z0-9-]{8,80}$') { throw "Invalid transfer" }
        $parts = @(Get-ChildItem -LiteralPath $transferDirectory -Filter "$transferId.*.part" | Sort-Object { [int](($_.BaseName -split '\.')[1]) })
        if (-not $parts.Count) { throw "No transfer parts" }
        $json = ($parts | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8 }) -join ""
        $payload = $json | ConvertFrom-Json
        if ($null -eq $payload.prompts -or $payload.prompts -isnot [System.Collections.IEnumerable]) { throw "Invalid library" }
        Write-Library @{ prompts = @($payload.prompts); updatedAt = [int64]$payload.updatedAt }
        $parts | Remove-Item -Force
        Write-Response @{ ok = $true }
      }
      default { Write-Response @{ ok = $false; error = "Unknown request" } }
    }
  } catch {
    Write-Response @{ ok = $false; error = $_.Exception.Message }
  }
}
