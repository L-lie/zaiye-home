# Prompt Vault 多任务协作状态

更新时间：2026-07-30

## 唯一项目源

`E:\work\4.程序\1.AI Prompt Vault\prompt-vault-rebuild`

所有任务都修改这一份源项目。禁止复制出第二份项目作为后续主线。

## 当前分工

- `prompt` 任务：处理用户日常、琐碎、局部的 Prompt Vault 修改。
- 网站接手任务：承担跨扩展与网站的主控、版本整合、测试、打包和发布协调。

## 协作规则

1. 开始修改前先读取本文件。
2. 同一时间只允许一个任务修改或打包 `prompt-vault-rebuild`。
3. 修改前通过任务消息告知另一个任务准备处理的文件。
4. 完成后在“最近变更”中记录结果，并向另一个任务发送摘要。
5. 不根据旧对话记忆覆盖磁盘中的新代码。
6. 打包、提交网站、推送和上线分别确认。
7. 用户私人 Prompt 存在浏览器本地数据中，不写入本文件或代码仓库。

## 当前版本

- 扩展版本：1.1.4
- 资源数据版本：2
- 官方资源地址：`https://zaiye.art/prompt-vault-resources.json`

## 最近变更

### 2026-07-30 prompt 任务

- 新增可开关的大类栏：默认图媒、写作、编程、办公；按大类筛选类别和 Prompt，关闭后保留所有归属；支持添加、拖动排序、右键改名/删除大类，以及右键类别迁移所属大类。
- 大类改为提示词列表顶部的独立横向一行，位于“全部条数 / 更新时间 / 批量”上方；关闭大类时仅隐藏该行，分类栏与 Prompt 列表不再错位或挤成窄卡片。
- 大类横栏去除白底、边框和胶囊样式；“全部”简化为“全”，添加项仅显示“＋”。行末可横向拖拽统一调整大类项宽度，压缩至窄宽度时自动切换为图标显示。
- “移动到大类”改为点选对话框；大类支持右键重命名、换图标、删除并为所属类别点选迁移目标。默认及可选图标为九宫格、图片、笔、代码和公文包；正常宽度仅显示文字，窄宽度仅显示图标。灵感资源入口已接入类别栏现有的宽度压缩逻辑，并使用灯泡图标。
- 编辑 Prompt 的项目、场景、类型、标签四栏改为可收缩四等分，输入框不会再把标签栏推出编辑区域。
- 编辑窗口顶部新增独立的大类切换条：新建时默认跟随当前列表大类，编辑既有 Prompt 时从其类别归属自动定位；切换大类只显示该大类的类别，新建类别会自动归入当前大类。
- 修复大类横栏压缩到图标宽度后图标未生成、只剩“＋”的问题；图标伪元素现会正常显示。
- 大类横栏下方的“全部条数 / 排序 / 批量”次级信息字号已缩小，明确低于上层大类文字。
- 修正“批量”按钮被后置样式覆盖而未缩小的问题；大类横栏背景固定为与左右分栏顶部一致的白色底色。
- 新增“采集当前页”：由用户主动触发，读取当前页面可见文本、标题、作者元数据、来源链接和可见图片 URL，进入既有勾选式导入预览后批量保存；自动给出类别启发式建议并以来源 URL 引用图片，不后台采集或下载受限内容。
- 采集流程升级为独立候选弹窗：每条展示缩略图、标题、摘要和勾选框；勾选后展开大类、类别、类型及“保存参考图”选择，大类变化会联动类别。保存时仅写入勾选条目，并跳过来源与正文均相同的已存内容。
- 修复采集弹窗：现在先扫描当前页面可见的大图并回退绑定到文本候选，图片不再只局限于文字块内部；隐藏冗余页面标题行、收紧顶部空间；保存按钮会显示“正在保存”，保存失败会给出状态提示。
- 网页文本框 mini 图标打开的面板改为按输入框左右可用空间定位：左侧可容纳完整面板时优先放左侧，否则右侧或空间较大的一侧；不再因仅按上下空间定位而被压扁。
- 启动时本地 Prompt 读取后立即首屏渲染；在线资源库、撤销记录和备份句柄改为首屏后的后台加载，不再被资源库网络超时阻塞。
- 修复网页文本框 mini 图标插入时在部分富文本框回退到开头的问题：按打开时保存的选区直接插入，并将光标置于插入内容末尾。
- 压缩 mini 浮窗的顶部、筛选、分类、卡片和操作按钮密度；不影响主界面和侧边栏。

- 采集入口扩展到网页悬浮图标与输入框 mini 图标的悬停按钮“采集页面”；点击后自动打开扩展并进入采集流程。采集器补充正文容器兜底，覆盖不使用 p/li 标签的图文页面；当内容脚本尚未载入时会先按当前授权页补注入再重试。
- 采集器改为图文卡片多选模式：优先按每张可见内容图向上定位所属卡片，再补充正文块；排除备案、页脚和扩展自身界面，不再强制正文必须包含“Prompt/提示词”等关键词，避免漏掉 SnackPrompt 等模板站内容。

- 网页采集候选默认不勾选；仅勾选单条后显示其大类、类别、已有类型下拉和图片设置。网页图片默认作为示例图；同一卡片有多图时，可切换示例图并把其他图片勾作参考图。每条新增“查看全文/收起”，以便保存前核对正文。

- 修复采集候选未勾选时分类与图片设置仍显示的问题：为设置区域显式覆盖网格样式，未勾选候选不再占用空间。

- 采集正文识别改为优先读取短而完整的提示词文本块（引号/括号段、指令式句子），再回退到图文卡片；避免标题、作者、日期和点赞数取代真正 Prompt 正文。

- 修复标题含“提示词”而抢占正文候选的问题：正文优先规则不再仅按“提示词/Prompt”字样命中，改为引号内容或明确指令句。

- 支持小红书的同页详情弹窗：检测到最上层详情弹窗时，采集范围仅限该弹窗，底层瀑布流标题卡不再参与候选。

- 修复图文详情的“外层杂项文本”候选：当容器含更精确 Prompt 子块时跳过外层，且 Prompt 子块没有同层图片时按详情弹窗内视觉距离绑定最近图片。

- 修复悬浮图标与 mini 图标面板读空 Prompt：内容脚本改为优先向扩展后台读取 Prompt，三个界面共用同一数据来源；后台不可用时才回退本地和同步读取。

- 悬浮图标与 mini 图标的采集入口改为两级悬停：先显示无文字采集图标，再悬停该图标才出现“采集网页”提示。

- 修复详情弹窗中 Prompt 正文与封面标题被拆分：存在明确 Prompt 正文时仅保留正文候选；正文配图与同卡片图像采集过滤小图标、头像和搜索图标，只选大尺寸内容图。

- 小图标采集入口改为优先打开侧边栏，失败时打开扩展页面，避免首次点击依赖浏览器气泡而无反应；图片关联补充可见 CSS 背景图扫描，以覆盖非 img 标签展示的网页示例图。
- 小图标与 mini 图标的“采集网页”现在阻止页面拖拽/点击事件吞掉按钮事件；采集结果改为直接新开扩展采集页，不再依赖侧边栏能否响应用户手势。
- 纠正小图标采集的打开位置：采集结果恢复在当前网页的扩展侧边栏中打开，不再新建 chrome-extension 标签页。
- 纠正附属示例图的预览层级：详情顶部仅显示主示例图；其余已选示例图移入 Prompt 下方独立“示例图”行，与“参考图”行使用相同的缩略图排布。
- 修复网页采集的图文归属：先排除包含更精确 Prompt 子块的外层元数据候选；正文候选随后向上查找最近的多图内容容器，并将该容器全部大图按“主图优先、其余附属示例图”交给正文候选。
- 采集候选展开后支持“使用选中文字”替换待保存正文，用户可剔除介绍性废话；勾选候选时同时显示可直接修改的标题输入框，保存使用修改后的标题。
- 小图标采集不再调用会被浏览器手势限制拦截的侧边栏接口：当前网页内嵌扩展采集窗口；保存成功后窗口自动关闭。全文同时新增可跳选的段落复选框，勾选多个不连续段落后可合并为待保存正文。
- 移除错误的段落复选框大面板；改为全文拖选后松开鼠标即自动暂存该片段，可继续跳过中间文字选择其他片段，最后统一“使用已选 X 段”。采集内嵌窗口宽度缩为内容宽度，避免右侧空白。
- 采集到的多张网页配图均可单独保留为示例图，并由“主示例”单选确定详情首图；其他已勾选示例图保存为附属示例图，参考图仍独立按需勾选。
- 修复采集候选中“正确 Prompt 与正确配图分开”的配对规则：正文候选现在识别含变量占位符和英文模板句的 Prompt，并以其视觉中心匹配最近的大图或 CSS 背景图；存在正文候选时不再额外生成网页元数据/标题占图的候选。

### 2026-07-30 网站接手任务

- 将灵感页升级为正式资源库。
- 新增 24 条原创资源，覆盖写作、图像、视频、编程和办公。
- 新增搜索、类别筛选、详情查看、`@变量`实时替换、复制和收藏。
- 官方资源自动读取，失败时回退内置精选资源。
- 完成弹窗、侧边栏、明暗主题与收藏流程测试。
- 扩展、文档和网站三份资源 JSON 已同步。
- 网站 JSON 尚未提交或上线。
- 已生成可安装的 1.1.4 扩展包。
- 安装包：`E:\work\4.程序\1.AI Prompt Vault\prompt-vault-rebuild-v1.1.4.zip`
- SHA-256：`6A3CFE255AD73682E22F7F67A28846A1B5205834BEEAA1E65ECB93CB7196CAE3`

### 2026-08-02 prompt task

- Collection text selection now keeps only fragments directly dragged by the user in the original full text. Multiple non-contiguous selections are retained until one final "使用已选 N 段" action; the earlier pre-split sentence picker is removed.
- The in-page collection iframe now uses its own 660px surface instead of the full 760px popup canvas, removing the unused right-side blank area. Manifest version bumped from 1.1.4 to 1.1.5.
- Multi-fragment selection is preserved again: each completed drag selection in the original text is remembered automatically, even after the browser highlights the next fragment. One final save combines every remembered fragment. Manifest version is now 1.1.7.
- Restored the floating icon above the mini panel: the panel is one stacking layer below the existing icon, so opening the panel no longer visually hides or moves the icon. Manifest version is now 1.1.8.
- Collection rows visibly label the editable title field and confirm the number of remembered blue text selections before the single final save. The embedded collection mode now has no internal backdrop or duplicate close control. Manifest version is now 1.1.10.
- Blue text capture now runs directly on pointer release and verifies the selection range belongs to the candidate body; final save combines all captured fragments. Clicking a selected card title focuses the explicit title input below. Manifest version is now 1.1.11.
- Removed the redundant lower title input: a selected collection card title is edited directly in place. Manifest version is now 1.1.12.
- Simplified collection editing: selected cards now edit Prompt text directly in place and save that edited text; removed the unused multi-selection text workflow. The in-page close button is positioned beside the collection window rather than the browser corner. Manifest version is now 1.1.13.
- Image preview now has previous/next navigation across a Prompt's main example, extra examples, and references. In page collection, drag a non-primary example thumbnail onto the primary example thumbnail to swap their order. Manifest version is now 1.1.14.
- Insert now attempts to upload every saved reference image one by one through the current page's compatible image upload control after inserting the Prompt, with an explicit status when no usable upload control is present. Collection now prefers the smallest topmost opened dialog and treats visible pre/code blocks as Prompt candidates, so modal code content is collected instead of the surrounding page. Manifest version is now 1.1.15.
- Collection image thumbnails now open the full image viewer with previous/next navigation. In Prompt viewing, lower example images can be dragged onto the main example to exchange their order, and the preview body keeps the same compact spacing below the image as above it. Manifest version is now 1.1.16.
- Updated category icons to match the supplied outline set: 约束 uses the bracketed square, 拆分 uses the double-page icon, and 指令 uses the terminal icon. Added 拆分 as a default category. The collection close button now follows the iframe's actual top-right corner and stays above it rather than being clipped outside. Manifest version is now 1.1.17.
- Fixed collection image viewing above the collection window: the lightbox is now a top-layer dialog, so it can cover the existing collection dialog and keep its image navigation usable. Manifest version is now 1.1.18.
- Added the first Windows local shared-library helper. It communicates through Native Messaging, stores Prompt data under the current user's LocalAppData, chunks large image-bearing Prompt payloads, and keeps browser-local storage as fallback until the helper is installed. The provided installer registers Chrome and Edge for the existing extension ID. Manifest version is now 1.1.19.
- Refined the full-image viewer controls: previous/next arrows are transparent with no focus box and use only a small press-scale feedback, rather than a large visual movement. Fixed the helper installer so Windows PowerShell can parse it reliably. Manifest version is now 1.1.20.
- Fixed the sidepanel-specific CSS that was forcibly hiding category icons. Split and Task now use their supplied outline icons in both normal and compact category widths. Manifest version is now 1.1.21.
- Made only the sidepanel category strip mirror the major-group behavior: text-only at normal width, icon-only at 48px and below, with its minimum width lowered to 38px so the compact state is actually reachable. Manifest version is now 1.1.22.
- Categories now support multiple major-group memberships while preserving legacy single-group data as the first membership. Category filtering, the editor's category selector, collection category selection, and major-group deletion all honor every selected membership. The category right-click action is now “设置所属大类” with multi-checkbox selection. Added the settings-menu “检查更新” action, which reads the official release manifest and opens the official download link when a newer version exists. Manifest version is now 1.1.23.

## 当前锁定

当前没有任务锁定项目。开始修改前先通过任务消息声明准备处理的文件。

## 待处理

- 安装并人工确认 1.1.4 不会影响已有本地 Prompt。
- 用户确认后，再单独处理网站资源 JSON 的提交与上线。
