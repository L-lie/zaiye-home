# 语藏 Prompt Vault 本机小助手

这个小助手只在当前 Windows 用户目录保存一份共享 Prompt 库：
`%LOCALAPPDATA%\ZaiyePromptVault\shared-library.json`。

扩展未安装小助手时保持原有浏览器本地保存方式。安装后，已打开的 Chrome、Edge 等 Chromium 浏览器在重载或重新打开扩展时读取同一份 Prompt 数据；每次保存会同时更新这份共享库。

安装命令（仅需一次；Chrome 与 Edge 的扩展 ID 不同时，把两个 ID 都填入）：

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ExtensionId "idiemjhonlahnlnalpanhplbgjcfbpnl","另一浏览器的扩展ID"
```

安装脚本只向当前用户写入 Chrome 和 Edge 的 Native Messaging 注册项；不请求管理员权限、不联网、不上传数据。
