const IS_SIDEPANEL = document.body.classList.contains("sidepanel-surface");
const UNCATEGORIZED_CATEGORY = { id: "uncategorized", label: "\u65E0\u7C7B\u522B", short: "\u65E0\u7C7B\u522B" };
const DEFAULT_CATEGORIES = [
  { id: "scene", label: "场景", short: "场景" },
  { id: "character", label: "\u89D2\u8272\u8BBE\u8BA1", short: "\u89D2\u8272" },
  { id: "video", label: "\u89C6\u9891\u63A7\u5236", short: "\u89C6\u9891" },
  { id: "constraint", label: "\u7EA6\u675F\u6A21\u5757", short: "\u7EA6\u675F" },
  { id: "task", label: "\u4EFB\u52A1\u6307\u4EE4", short: "\u6307\u4EE4" },
  UNCATEGORIZED_CATEGORY
];
const COMPACT_CATEGORY_IDS = new Set(["scene", "character", "video", "constraint", "task"]);
const DEFAULT_MODELS = ["ChatGPT", "Nanobanana", "MJ", "Codex", "SD2", "可灵"];

const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const DRAFT_KEY = "promptVaultDraft";
const INSTALL_ID_KEY = "promptVaultInstallId";
const PENDING_OPEN_KEY = "promptVaultPendingOpen";
const BACKUP_META_KEY = "promptVaultBackupMeta";
const BACKUP_DB_NAME = "promptVaultFileHandles";
const BACKUP_STORE_NAME = "handles";
const INTERNAL_BACKUP_STORE_NAME = "snapshots";
const BACKUP_HANDLE_KEY = "backupDirectory";
const BACKUP_HISTORY_LIMIT = 10;
const SHARED_SYNC_HANDLE_KEY = "sharedSyncDirectory";
const SHARED_SYNC_FILENAME = "prompt-vault-sync.json";
const SHARED_SYNC_INTERVAL = 30000;
const BULK_UNDO_KEY = "promptVaultBulkUndo";
const BULK_UNDO_LIMIT = 20;
const DEFAULT_UI_WIDTHS = { category: 91, library: 306 };
const SIDEPANEL_TEXT_CATEGORY_WIDTH = 60;
const IMAGE_MAX_EDGE = 960;
const IMAGE_QUALITY = 0.78;
const DEFAULT_NEGATIVE_TERMS = [
  "\u4F4E\u8D28\u91CF",
  "\u591A\u4F59\u624B\u6307",
  "\u8FC7\u5EA6\u9510\u5316",
  "\u7578\u5F62\u624B",
  "\u8138\u90E8\u5D29\u574F",
  "\u6A21\u7CCA",
  "\u6C34\u5370",
  "\u6587\u5B57",
  "\u6742\u4E71\u80CC\u666F",
  "\u810F\u6C61\u7EB9\u7406",
  "\u566A\u70B9",
  "logo"
];
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "\u518D\u91CE\u6587\u5316\u5DE5\u4F5C\u5BA4",
  creator: "\u7530\u7530\u7530\u91CE\u91CC",
  copyright: "Copyright (c) 2026 \u7530\u7530\u7530\u91CE\u91CC / \u518D\u91CE\u6587\u5316\u5DE5\u4F5C\u5BA4",
  license: "Personal evaluation use only. Redistribution, resale, rebranding, or derivative commercial distribution without written permission is prohibited."
};
const OFFICIAL_RELEASE = {
  releaseId: "PV-ZY-2026-07-03-0001",
  channel: "official-website",
  officialSite: "http://zaiye.art/",
  promptSite: "https://gptimage2api.net/prompts",
  downloadUrl: "https://github.com/L-lie/zaiye-home/releases/download/v0.9.1/prompt-vault-extension.zip",
  issuedAt: "2026-07-03",
  notice: "Only downloads from the official website or verified channels are authorized. Keep this release metadata when sharing feedback or exports."
};
const PROMPT_SITES = [
  { name: "PromptDen", url: "https://promptden.com/", description: "跨模型社区，涵盖文本、图像、视频提示词，适合对比不同场景下提示词的差异，拓宽提示词思路。" },
  { name: "PromptHero", url: "https://prompthero.com/", description: "全球大型 AI 提示词搜索引擎之一，支持按 Midjourney、Stable Diffusion、ChatGPT 等模型和类型搜索，提供真实出图案例与完整提示词对照，适合寻找灵感与跨模型搜索。" },
  { name: "PromptBase", url: "https://promptbase.com/", description: "专业提示词交易市场，提供写作、绘画、提示工程等高质量付费提示词，适合寻找可直接商用或解决复杂问题的成熟模板。" },
  { name: "AI Wind", url: "https://www.aiwind.org/", description: "专注于 GPT Image 2 / Nano Banana 的提示词库，涵盖多种风格，免登录直接复制，适合快速获取特定模型的提示词模板。" },
  { name: "MidLibrary", url: "https://midlibrary.ai/", description: "Midjourney 风格参考库，提供大量风格代码 SREF 和视觉风格提示词，适合寻找特定视觉风格和色彩氛围。" },
  { name: "Lexica", url: "https://lexica.art/", description: "Stable Diffusion 提示词图库，采用图文结合方式，支持关键词搜索和图片反向搜索，适合寻找优质提示词灵感及反查图片提示词。" },
  { name: "Meigen", url: "https://meigen.ai/", description: "视觉提示词灵感库，提供大量精美大图及对应完整提示词，按风格、摄影、品牌视觉分类，适合寻找视觉灵感及学习提示词结构。" },
  { name: "Image to Prompt", url: "https://image-to-prompt.com/", description: "图片反推提示词工具，上传图片即可生成对应提示词，支持多种 AI 模型，适合看到喜欢的图后反推复现。" },
  { name: "AI Short", url: "https://www.aishort.top/", description: "中文友好的 ChatGPT 快速指令表，按写作辅助、办公效率、编程等分类，支持标签筛选和一键复制，适合快速获取开箱即用的文本指令。" },
  { name: "SnackPrompt", url: "https://snackprompt.com/", description: "提供大量可定制的 ChatGPT 任务模板，支持在线编辑细节并提供浏览器插件，适合寻找结构化、可复用的文本任务模板。" },
  { name: "LearnPrompt.org", url: "https://learnprompt.org/", description: "提供丰富的提示词案例和分类，适合学习提示词背后的逻辑与结构，帮助用户建立提示词思维。" }
];

let prompts = [];
let selectedId = null;
let activeCategory = "all";
let favoriteOnly = false;
let settings = {};
let autoSaveTimer = null;
let isHydrating = false;
let pendingImport = [];
let pendingImportSettings = null;
let pendingImportCategories = [];
let pendingImportCategoryConflicts = 0;
let installId = "";
let currentReferences = [];
let editorMode = "view";
let sidepanelPreviewOpen = false;
let backupTimer = null;
let backupWriteInProgress = false;
let backupDirectoryHandleCache = null;
let sharedSyncDirectoryHandleCache = null;
let sharedSyncTimer = null;
let sharedSyncInProgress = false;
let bulkEditMode = false;
let bulkSelectedIds = new Set();
let bulkUndoStack = [];
let bulkRedoStack = [];
let bulkUndoSessionDirty = false;

const els = {
  list: document.getElementById("promptList"),
  search: document.getElementById("search"),
  projectFilter: document.getElementById("projectFilter"),
  sceneFilter: document.getElementById("sceneFilter"),
  genreFilter: document.getElementById("genreFilter"),
  tagFilter: document.getElementById("tagFilter"),
  favoriteFilter: document.getElementById("favoriteFilter"),
  resetFilters: document.getElementById("resetFilters"),
  categoryTabsContainer: document.getElementById("categoryTabs"),
  categoryTabs: [...document.querySelectorAll("[data-category]")],
  listSummary: document.getElementById("listSummary"),
  sortMode: document.getElementById("sortMode"),
  toggleBulkEdit: document.getElementById("toggleBulkEdit"),
  bulkEditBar: document.getElementById("bulkEditBar"),
  bulkSelectionSummary: document.getElementById("bulkSelectionSummary"),
  selectAllBulk: document.getElementById("selectAllBulk"),
  bulkCategory: document.getElementById("bulkCategory"),
  bulkProject: document.getElementById("bulkProject"),
  bulkScene: document.getElementById("bulkScene"),
  applyBulkEdit: document.getElementById("applyBulkEdit"),
  bulkDelete: document.getElementById("bulkDelete"),
  undoBulkEdit: document.getElementById("undoBulkEdit"),
  redoBulkEdit: document.getElementById("redoBulkEdit"),
  dataMenu: document.getElementById("dataMenu"),
  setupBackup: document.getElementById("setupBackup"),
  manualBackup: document.getElementById("manualBackup"),
  backupHistory: document.getElementById("backupHistory"),
  backupHistoryDialog: document.getElementById("backupHistoryDialog"),
  closeBackupHistory: document.getElementById("closeBackupHistory"),
  backupFolderStatus: document.getElementById("backupFolderStatus"),
  backupHistoryList: document.getElementById("backupHistoryList"),
  backupPermissionActions: document.getElementById("backupPermissionActions"),
  reauthorizeBackup: document.getElementById("reauthorizeBackup"),
  reselectBackup: document.getElementById("reselectBackup"),
  manualBackupFromHistory: document.getElementById("manualBackupFromHistory"),
  downloadLatestBackup: document.getElementById("downloadLatestBackup"),
  enableSharedSync: document.getElementById("enableSharedSync"),
  syncNow: document.getElementById("syncNow"),
  disableSharedSync: document.getElementById("disableSharedSync"),
  sharedSyncStatus: document.getElementById("sharedSyncStatus"),
  aiImportGuide: document.getElementById("aiImportGuide"),
  aiImportDialog: document.getElementById("aiImportDialog"),
  closeAiImportGuide: document.getElementById("closeAiImportGuide"),
  aiImportInstruction: document.getElementById("aiImportInstruction"),
  copyAiImportGuide: document.getElementById("copyAiImportGuide"),
  form: document.getElementById("promptForm"),
  previewPanel: document.getElementById("promptPreview"),
  previewCategory: document.getElementById("previewCategory"),
  previewCategoryMenu: document.getElementById("previewCategoryMenu"),
  previewTitle: document.getElementById("previewTitle"),
  previewMeta: document.getElementById("previewMeta"),
  previewPromptSection: document.getElementById("previewPromptSection"),
  previewPromptEnSection: document.getElementById("previewPromptEnSection"),
  previewNegativeSection: document.getElementById("previewNegativeSection"),
  previewPrompt: document.getElementById("previewPrompt"),
  previewPromptEn: document.getElementById("previewPromptEn"),
  previewNegative: document.getElementById("previewNegative"),
  previewImages: document.getElementById("previewImages"),
  previewReferences: document.getElementById("previewReferences"),
  editPrompt: document.getElementById("editPrompt"),
  toggleFavorite: document.getElementById("toggleFavorite"),
  previewCopyPrompt: document.getElementById("previewCopyPrompt"),
  previewDuplicatePrompt: document.getElementById("previewDuplicatePrompt"),
  previewUndoPrompt: document.getElementById("previewUndoPrompt"),
  previewRedoPrompt: document.getElementById("previewRedoPrompt"),
  editorUndoPrompt: document.getElementById("editorUndoPrompt"),
  editorRedoPrompt: document.getElementById("editorRedoPrompt"),
  previewDeletePrompt: document.getElementById("previewDeletePrompt"),
  editorModeLabel: document.getElementById("editorModeLabel"),
  cancelEdit: document.getElementById("cancelEdit"),
  newPrompt: document.getElementById("newPrompt"),
  openSidepanel: document.getElementById("openSidepanel"),
  themeMenuButton: document.getElementById("themeMenuButton"),
  themeMenu: document.getElementById("themeMenu"),
  themeOptions: [...document.querySelectorAll("[data-theme-value]")],
  closeSidepanelPreview: document.getElementById("closeSidepanelPreview"),
  categoryResizeHandle: document.getElementById("categoryResizeHandle"),
  libraryResizeHandle: document.getElementById("libraryResizeHandle"),
  layout: document.querySelector(".layout"),
  libraryAside: document.querySelector(".layout > aside"),
  title: document.getElementById("title"),
  project: document.getElementById("project"),
  projectOptions: document.getElementById("projectOptions"),
  projectDropdown: document.getElementById("projectDropdown"),
  scene: document.getElementById("scene"),
  sceneOptions: document.getElementById("sceneOptions"),
  sceneDropdown: document.getElementById("sceneDropdown"),
  genre: document.getElementById("genre"),
  genreOptions: document.getElementById("genreOptions"),
  genreDropdown: document.getElementById("genreDropdown"),
  category: document.getElementById("category"),
  model: document.getElementById("model"),
  modelDropdown: document.getElementById("modelDropdown"),
  categoryMigrationDialog: document.getElementById("categoryMigrationDialog"),
  categoryMigrationMessage: document.getElementById("categoryMigrationMessage"),
  categoryMigrationSelect: document.getElementById("categoryMigrationSelect"),
  prompt: document.getElementById("prompt"),
  promptEn: document.getElementById("promptEn"),
  negative: document.getElementById("negative"),
  tags: document.getElementById("tags"),
  tagDropdown: document.getElementById("tagDropdown"),
  negativeSuggestions: document.getElementById("negativeSuggestions"),
  tagSuggestions: document.getElementById("tagSuggestions"),
  exampleField: document.getElementById("exampleField"),
  imageDrop: document.getElementById("imageDrop"),
  pasteImage: document.getElementById("pasteImage"),
  clearImage: document.getElementById("clearImage"),
  mediaStatus: document.getElementById("mediaStatus"),
  pasteCatcher: document.getElementById("pasteCatcher"),
  imageUrl: document.getElementById("imageUrl"),
  imageFile: document.getElementById("imageFile"),
  preview: document.getElementById("preview"),
  referenceField: document.getElementById("referenceField"),
  referenceDrop: document.getElementById("referenceDrop"),
  referenceFiles: document.getElementById("referenceFiles"),
  referenceGallery: document.getElementById("referenceGallery"),
  pasteReferenceImage: document.getElementById("pasteReferenceImage"),
  sourceUrl: document.getElementById("sourceUrl"),
  openSource: document.getElementById("openSource"),
  copyPrompt: document.getElementById("copyPrompt"),
  duplicatePrompt: document.getElementById("duplicatePrompt"),
  deletePrompt: document.getElementById("deletePrompt"),
  exportPrompts: document.getElementById("exportPrompts"),
  exportFilteredPrompts: document.getElementById("exportFilteredPrompts"),
  importPrompts: document.getElementById("importPrompts"),
  importFile: document.getElementById("importFile"),
  refreshLibrary: document.getElementById("refreshLibrary"),
  officialSite: document.getElementById("officialSite"),
  promptSite: document.getElementById("promptSite"),
  promptSiteMenu: document.getElementById("promptSiteMenu"),
  promptSiteList: document.getElementById("promptSiteList"),
  promptSiteDescription: document.getElementById("promptSiteDescription"),
  footerThemeToggle: document.getElementById("footerThemeToggle"),
  creatorToggle: document.getElementById("creatorToggle"),
  importPanel: document.getElementById("importPanel"),
  importSummary: document.getElementById("importSummary"),
  importList: document.getElementById("importList"),
  bulkConflictAction: document.getElementById("bulkConflictAction"),
  clearAllPrompts: document.getElementById("clearAllPrompts"),
  selectAllImport: document.getElementById("selectAllImport"),
  invertImport: document.getElementById("invertImport"),
  confirmImport: document.getElementById("confirmImport"),
  cancelImport: document.getElementById("cancelImport"),
  syncStatus: document.getElementById("syncStatus"),
  previewPromptLabel: document.getElementById("previewPromptLabel"),
  previewPromptEnLabel: document.getElementById("previewPromptEnLabel"),
  previewNegativeLabel: document.getElementById("previewNegativeLabel"),
  emptyTemplate: document.getElementById("emptyTemplate")
};

const compactFilterDisplays = new Map();

for (const select of [els.projectFilter, els.sceneFilter, els.genreFilter, els.tagFilter]) {
  const control = document.createElement("span");
  control.className = "compact-filter-control";
  const display = document.createElement("span");
  display.className = "compact-filter-display";
  const label = document.createElement("span");
  label.className = "compact-filter-label";
  const arrow = document.createElement("span");
  arrow.className = "compact-filter-arrow";
  display.append(label, arrow);
  select.before(control);
  control.append(select, display);
  compactFilterDisplays.set(select, label);
}

function syncCompactFilterDisplays() {
  for (const [select, label] of compactFilterDisplays) {
    label.textContent = select.selectedOptions[0]?.textContent || "";
  }
}

syncCompactFilterDisplays();

for (const select of compactFilterDisplays.keys()) {
  select.addEventListener("change", syncCompactFilterDisplays);
  new MutationObserver(syncCompactFilterDisplays).observe(select, {
    childList: true,
    subtree: true
  });
}

function now() {
  return Date.now();
}

function applyTheme(value = settings.themeMode) {
  const theme = value === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = theme;
  if (els.footerThemeToggle) {
    const label = theme === "dark" ? "切换到日间模式" : "切换到夜间模式";
    els.footerThemeToggle.setAttribute("aria-label", label);
    els.footerThemeToggle.title = label;
  }
  for (const option of els.themeOptions) {
    option.setAttribute("aria-checked", String(option.dataset.themeValue === theme));
  }
}

if (els.footerThemeToggle) {
  els.footerThemeToggle.addEventListener("click", async () => {
    settings.themeMode = settings.themeMode === "dark" ? "light" : "dark";
    applyTheme(settings.themeMode);
    await saveSettings();
  });
}

function uid() {
  return crypto.randomUUID();
}

async function ensureInstallId() {
  const data = await chrome.storage.local.get({ [INSTALL_ID_KEY]: "" });
  installId = data[INSTALL_ID_KEY] || uid();
  if (!data[INSTALL_ID_KEY]) await chrome.storage.local.set({ [INSTALL_ID_KEY]: installId });
  return installId;
}

function normalizeTags(value) {
  return value
    .split(/[,\uFF0C\u3001\s]+/)
    .map((tag) => tag.trim())
    .filter(Boolean);
}

function shortCategoryLabel(label) {
  const text = String(label || "").trim();
  return text.replace(/(描述|设计|控制|模块|提示词|任务)/g, "").slice(0, 4) || text.slice(0, 4) || "类";
}

function categoryIdFromLabel(label, existing = []) {
  const text = String(label || "").trim();
  const existed = existing.find((item) => item.label === text || item.short === text);
  if (existed) return existed.id;
  const preset = DEFAULT_CATEGORIES.find((item) => item.label === text || item.short === text);
  if (preset) return preset.id;
  let hash = 0;
  for (const char of text) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  return `custom_${Math.abs(hash).toString(36)}`;
}

function normalizeCategories(value) {
  const source = Array.isArray(value) && value.length ? value : DEFAULT_CATEGORIES;
  const seen = new Set();
  const categories = [];
  for (const item of source) {
    const label = String(item?.label || item?.short || "").trim();
    if (!label) continue;
    const id = String(item?.id || categoryIdFromLabel(label, source)).trim();
    if (!id || seen.has(id)) continue;
    seen.add(id);
    categories.push({
      id,
      label,
      short: String(item?.short || shortCategoryLabel(label)).trim(),
      icon: String(item?.icon || "").trim(),
      updatedAt: Number(item?.updatedAt) || 0
    });
  }
  const normalized = categories.filter((item) => item.id !== UNCATEGORIZED_CATEGORY.id);
  normalized.push({ ...UNCATEGORIZED_CATEGORY, updatedAt: 0 });
  return normalized.length ? normalized : DEFAULT_CATEGORIES;
}

function normalizeImportedCategories(value) {
  return Array.isArray(value) && value.length ? normalizeCategories(value) : [];
}

function mergeImportedCategories(importedCategories) {
  const merged = [...categoryList()];
  const typeMap = new Map();
  let conflicts = 0;

  for (const imported of normalizeImportedCategories(importedCategories)) {
    const sameId = merged.find((item) => item.id === imported.id);
    const sameLabel = merged.find((item) => item.label === imported.label);
    if (sameId?.label === imported.label) {
      typeMap.set(imported.id, sameId.id);
      continue;
    }
    if (sameLabel) {
      if (sameId && sameId.id !== sameLabel.id) conflicts += 1;
      typeMap.set(imported.id, sameLabel.id);
      continue;
    }

    let id = imported.id;
    if (sameId) {
      conflicts += 1;
      id = categoryIdFromLabel(imported.label, merged);
      let suffix = 2;
      while (merged.some((item) => item.id === id)) id = `${categoryIdFromLabel(imported.label, merged)}_${suffix++}`;
    }
    const next = { ...imported, id };
    merged.push(next);
    typeMap.set(imported.id, id);
  }

  return { categories: normalizeCategories(merged), typeMap, conflicts };
}

function categoryList() {
  return normalizeCategories(settings.categories);
}

function defaultCategoryId() {
  return categoryList()[0]?.id || DEFAULT_CATEGORIES[0].id;
}

function categoryLabel(id) {
  return categoryList().find((item) => item.id === id)?.label || categoryList().find((item) => item.id === defaultCategoryId())?.label || "Prompt";
}

function categoryShortLabel(id) {
  const category = categoryList().find((item) => item.id === id);
  return category?.short || shortCategoryLabel(category?.label || id);
}

function normalizeCategory(value) {
  return categoryList().some((item) => item.id === value) ? value : UNCATEGORIZED_CATEGORY.id;
}

function composePrompt(item) {
  const parts = [];
  if (item.prompt?.trim()) parts.push(item.prompt.trim());
  if (item.promptEn?.trim()) parts.push(item.promptEn.trim());
  if (item.negative?.trim()) parts.push(`\u7981\u6B62\uFF1A${item.negative.trim()}`);
  const text = parts.join("\n\n");
  const mjSuffix = "--ar 21:9 --v 7 --stylize 750";
  if (String(item.model || "").trim().toUpperCase() === "MJ" && text && !text.endsWith(mjSuffix)) {
    return `${text} ${mjSuffix}`;
  }
  return text;
}

function draftPrompt(overrides = {}) {
  return {
    id: uid(),
    title: "\u672A\u547D\u540D Prompt",
    project: "",
    scene: "",
    genre: "",
    type: "scene",
    model: "",
    prompt: "",
    promptEn: "",
    negative: "",
    favorite: false,
    tags: [],
    image: "",
    references: [],
    sourceUrl: "",
    rating: 0,
    usageCount: 0,
    lastUsedAt: 0,
    order: Number.MAX_SAFE_INTEGER,
    createdAt: now(),
    updatedAt: now(),
    sourceProduct: PRODUCT_OWNER.product,
    sourceStudio: PRODUCT_OWNER.studio,
    sourceCreator: PRODUCT_OWNER.creator,
    sourceReleaseId: OFFICIAL_RELEASE.releaseId,
    sourceOfficialSite: OFFICIAL_RELEASE.officialSite,
    sourceInstallId: installId,
    versions: [],
    ...overrides
  };
}

function sanitizePrompt(item) {
  return {
    ...item,
    id: item.id || uid(),
    title: item.title || "\u672A\u547D\u540D Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || item.customType || "",
    type: item.type || UNCATEGORIZED_CATEGORY.id,
    model: item.model || "",
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    favorite: Boolean(item.favorite),
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    references: Array.isArray(item.references) ? item.references.map(String).filter(Boolean) : [],
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    usageCount: Object.prototype.hasOwnProperty.call(item, "usageCount") ? Number(item.usageCount) || 0 : 0,
    lastUsedAt: Object.prototype.hasOwnProperty.call(item, "lastUsedAt") ? Number(item.lastUsedAt) || 0 : 0,
    order: Number.isFinite(Number(item.order)) ? Number(item.order) : Number.MAX_SAFE_INTEGER,
    createdAt: Number(item.createdAt) || now(),
    updatedAt: Number(item.updatedAt) || now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    sourceReleaseId: item.sourceReleaseId || OFFICIAL_RELEASE.releaseId,
    sourceOfficialSite: item.sourceOfficialSite || OFFICIAL_RELEASE.officialSite,
    sourceInstallId: item.sourceInstallId || installId,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

async function loadSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: settings });
  settings = { ...settings, ...data[SETTINGS_KEY] };
  if (!settings.surfaceWidthsSeparated) {
    if (Number(settings.uiWidths?.category) <= 48) {
      settings.uiWidths = { ...(settings.uiWidths || {}), category: DEFAULT_UI_WIDTHS.category };
    }
    settings.surfaceWidthsSeparated = true;
    await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  }
  if (!settings.sidepanelTextWidthCompactedV2) {
    settings.sidepanelUiWidths = {
      ...(settings.sidepanelUiWidths || {}),
      category: SIDEPANEL_TEXT_CATEGORY_WIDTH
    };
    settings.sidepanelTextWidthCompactedV2 = true;
    await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  }
  settings.categories = normalizeCategories(settings.categories);
  applyTheme(settings.themeMode);
  updateSyncStatus();
}

function nextPromptOrder() {
  const values = prompts.map((item) => Number(item.order)).filter((value) => Number.isSafeInteger(value) && value < Number.MAX_SAFE_INTEGER);
  return values.length ? Math.max(...values) + 1 : 0;
}

function normalizePromptOrders(items) {
  const validOrders = items
    .map((item) => Number(item.order))
    .filter((value) => Number.isSafeInteger(value) && value < Number.MAX_SAFE_INTEGER);
  let nextOrder = validOrders.length ? Math.max(...validOrders) + 1 : 0;
  return items.map((item) => {
    const order = Number(item.order);
    return Number.isSafeInteger(order) && order < Number.MAX_SAFE_INTEGER
      ? item
      : { ...item, order: nextOrder++ };
  });
}

const IMPORT_COMPARE_KEYS = [
  "title", "project", "scene", "genre", "type", "prompt", "promptEn", "negative", "favorite",
  "tags", "image", "references", "sourceUrl", "rating", "usageCount", "lastUsedAt", "order"
];

function importFingerprint(item) {
  const clean = sanitizePrompt(item);
  return JSON.stringify(Object.fromEntries(IMPORT_COMPARE_KEYS.map((key) => [key, clean[key]])));
}

const SYNC_CONFLICT_SUFFIX = "\uFF08\u540C\u6B65\u51B2\u7A81\u526F\u672C\uFF09";

function syncConflictBaseTitle(title) {
  return String(title || "\u672A\u547D\u540D Prompt").replace(/(?:\s*\uFF08\u540C\u6B65\u51B2\u7A81\u526F\u672C\uFF09)+$/u, "").trim();
}

function syncConflictFingerprint(item) {
  return importFingerprint({ ...item, title: syncConflictBaseTitle(item.title) });
}

function stableSyncHash(text) {
  let hash = 5381;
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash) ^ text.charCodeAt(index);
  }
  return (hash >>> 0).toString(36);
}

function dedupeSyncConflictCopies(items) {
  const result = [];
  const seen = new Map();
  for (const item of items) {
    if (!String(item.title || "").endsWith(SYNC_CONFLICT_SUFFIX)) {
      result.push(item);
      continue;
    }
    const fingerprint = syncConflictFingerprint(item);
    const existingIndex = seen.get(fingerprint);
    if (existingIndex === undefined) {
      seen.set(fingerprint, result.length);
      result.push(item);
      continue;
    }
    const existing = result[existingIndex];
    const existingIsStable = String(existing.id).startsWith("sync-conflict-");
    const itemIsStable = String(item.id).startsWith("sync-conflict-");
    if ((itemIsStable && !existingIsStable) || (itemIsStable === existingIsStable && String(item.id) < String(existing.id))) {
      result[existingIndex] = item;
    }
  }
  return result;
}

function analyzeImportItem(raw, index, typeMap) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { key: `invalid-${index}`, status: "invalid", reason: "\u6761\u76ee\u4e0d\u662f\u6709\u6548\u5bf9\u8c61", item: null, action: "skip" };
  }
  const item = sanitizePrompt(raw);
  item.type = typeMap.get(item.type) || normalizeCategory(item.type);
  const existingById = prompts.find((current) => current.id === item.id);
  const fingerprint = importFingerprint(item);
  const identical = existingById && importFingerprint(existingById) === fingerprint
    ? existingById
    : prompts.find((current) => importFingerprint(current) === fingerprint);

  if (identical) return { key: `import-${index}`, status: "duplicate", item, existing: identical, action: "skip" };
  if (existingById) return { key: `import-${index}`, status: "conflict", item, existing: existingById, action: "keep-local" };
  return { key: `import-${index}`, status: "new", item, existing: null, action: "add" };
}

async function saveSettings() {
  settings.categories = normalizeCategories(settings.categories);
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  scheduleAutomaticBackup();
  scheduleSharedSync();
}

function updateSyncStatus(extra = "") {
  const base = IS_SIDEPANEL ? "" : "\u672C\u673A\u4FDD\u5B58";
  if (els.syncStatus) els.syncStatus.textContent = extra ? (base ? `${base} · ${extra}` : extra) : base;
}

async function saveAll() {
  await chrome.storage.local.set({ [LOCAL_KEY]: prompts });
  scheduleAutomaticBackup();
  scheduleSharedSync();
}

async function loadAll() {
  await loadSettings();

  const result = await chrome.storage.local.get({ [LOCAL_KEY]: null });
  if (result[LOCAL_KEY]) {
    prompts = normalizePromptOrders(result[LOCAL_KEY].map(sanitizePrompt).map((item) => ({
      ...item,
      type: normalizeCategory(item.type)
    })));
    selectedId = prompts[0]?.id || null;
    scheduleAutomaticBackup();
    return;
  }

  prompts = [];
  scheduleAutomaticBackup();
}

function clampNumber(value, minimum, maximum) {
  return Math.min(Math.max(value, minimum), Math.max(minimum, maximum));
}

function surfaceUiWidths() {
  const key = document.body.classList.contains("sidepanel-surface") ? "sidepanelUiWidths" : "uiWidths";
  return { key, values: settings[key] || {} };
}

function columnWidthLimits(type) {
  if (type === "category") {
    const available = els.libraryAside?.clientWidth || DEFAULT_UI_WIDTHS.library;
    return { minimum: 38, maximum: Math.min(210, Math.max(38, available - 150)) };
  }
  const available = els.layout?.clientWidth || 760;
  const categoryWidth = Number(surfaceUiWidths().values.category) || DEFAULT_UI_WIDTHS.category;
  const minimumPreviewWidth = document.body.classList.contains("sidepanel-surface") ? 250 : 420;
  return { minimum: Math.max(230, categoryWidth + 150), maximum: Math.max(230, available - minimumPreviewWidth) };
}

function updateCompactPreviewActions(libraryWidth) {
  if (document.body.classList.contains("sidepanel-surface")) return;
  const available = els.layout?.clientWidth || 760;
  document.body.classList.toggle("compact-preview-actions", available - libraryWidth < 420);
}

function applyColumnWidth(type, value) {
  const limits = columnWidthLimits(type);
  const width = Math.round(clampNumber(Number(value) || DEFAULT_UI_WIDTHS[type], limits.minimum, limits.maximum));
  const property = type === "category" ? "--category-column-width" : "--library-column-width";
  document.documentElement.style.setProperty(property, `${width}px`);
  if (type === "category") els.categoryTabsContainer?.classList.toggle("is-icon-only", width <= 48);
  if (type === "library") updateCompactPreviewActions(width);
  const widths = surfaceUiWidths();
  settings[widths.key] = { ...widths.values, [type]: width };
  return width;
}

function applyStoredColumnWidths() {
  const widths = surfaceUiWidths().values;
  applyColumnWidth("library", widths.library || DEFAULT_UI_WIDTHS.library);
  applyColumnWidth("category", widths.category || DEFAULT_UI_WIDTHS.category);
}

function applyCategoryButtonHeight(value) {
  const height = Math.round(clampNumber(Number(value) || 24, 20, 36));
  document.documentElement.style.setProperty("--category-button-height", `${height}px`);
  settings.categoryButtonHeight = height;
  return height;
}

function bindCategoryHeightResize(handle, buttonCount) {
  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    const startY = event.clientY;
    const startHeight = Number(settings.categoryButtonHeight) || 24;
    const count = Math.max(1, buttonCount);
    handle.classList.add("is-active");
    handle.setPointerCapture?.(event.pointerId);
    const move = (moveEvent) => applyCategoryButtonHeight(startHeight + (moveEvent.clientY - startY) / count);
    const finish = async () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", finish);
      document.removeEventListener("pointercancel", finish);
      handle.classList.remove("is-active");
      await persistColumnWidths();
    };
    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", finish, { once: true });
    document.addEventListener("pointercancel", finish, { once: true });
  });
  handle.addEventListener("dblclick", async () => {
    applyCategoryButtonHeight(24);
    await persistColumnWidths();
  });
}

async function persistColumnWidths() {
  await chrome.storage.local.set({ [SETTINGS_KEY]: { ...settings, categories: categoryList() } });
}

function bindColumnResize(handle, type) {
  if (!handle) return;
  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    const startX = event.clientX;
    const startWidth = Number(surfaceUiWidths().values[type]) || DEFAULT_UI_WIDTHS[type];
    handle.classList.add("is-active");
    document.body.classList.add("is-resizing-columns");
    handle.setPointerCapture?.(event.pointerId);

    const move = (moveEvent) => applyColumnWidth(type, startWidth + moveEvent.clientX - startX);
    const finish = async () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", finish);
      document.removeEventListener("pointercancel", finish);
      handle.classList.remove("is-active");
      document.body.classList.remove("is-resizing-columns");
      await persistColumnWidths();
    };
    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", finish, { once: true });
    document.addEventListener("pointercancel", finish, { once: true });
  });
  handle.addEventListener("dblclick", async () => {
    applyColumnWidth(type, DEFAULT_UI_WIDTHS[type]);
    await persistColumnWidths();
  });
}

bindColumnResize(els.categoryResizeHandle, "category");
bindColumnResize(els.libraryResizeHandle, "library");

function openBackupDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(BACKUP_DB_NAME, 2);
    request.addEventListener("upgradeneeded", () => {
      if (!request.result.objectStoreNames.contains(BACKUP_STORE_NAME)) {
        request.result.createObjectStore(BACKUP_STORE_NAME);
      }
      if (!request.result.objectStoreNames.contains(INTERNAL_BACKUP_STORE_NAME)) {
        request.result.createObjectStore(INTERNAL_BACKUP_STORE_NAME, { keyPath: "filename" });
      }
    });
    request.addEventListener("success", () => resolve(request.result));
    request.addEventListener("error", () => reject(request.error));
  });
}

async function storeBackupDirectoryHandle(handle, key = BACKUP_HANDLE_KEY) {
  const database = await openBackupDatabase();
  await new Promise((resolve, reject) => {
    const transaction = database.transaction(BACKUP_STORE_NAME, "readwrite");
    transaction.objectStore(BACKUP_STORE_NAME).put(handle, key);
    transaction.addEventListener("complete", resolve);
    transaction.addEventListener("error", () => reject(transaction.error));
  });
  database.close();
  if (key === BACKUP_HANDLE_KEY) backupDirectoryHandleCache = handle;
  if (key === SHARED_SYNC_HANDLE_KEY) sharedSyncDirectoryHandleCache = handle;
}

async function getBackupDirectoryHandle(key = BACKUP_HANDLE_KEY) {
  if (key === BACKUP_HANDLE_KEY && backupDirectoryHandleCache) return backupDirectoryHandleCache;
  if (key === SHARED_SYNC_HANDLE_KEY && sharedSyncDirectoryHandleCache) return sharedSyncDirectoryHandleCache;
  const database = await openBackupDatabase();
  const handle = await new Promise((resolve, reject) => {
    const transaction = database.transaction(BACKUP_STORE_NAME, "readonly");
    const request = transaction.objectStore(BACKUP_STORE_NAME).get(key);
    request.addEventListener("success", () => resolve(request.result || null));
    request.addEventListener("error", () => reject(request.error));
  });
  database.close();
  if (key === BACKUP_HANDLE_KEY) backupDirectoryHandleCache = handle;
  if (key === SHARED_SYNC_HANDLE_KEY) sharedSyncDirectoryHandleCache = handle;
  return handle;
}

async function internalBackupEntries() {
  const database = await openBackupDatabase();
  const entries = await new Promise((resolve, reject) => {
    const transaction = database.transaction(INTERNAL_BACKUP_STORE_NAME, "readonly");
    const request = transaction.objectStore(INTERNAL_BACKUP_STORE_NAME).getAll();
    request.addEventListener("success", () => resolve(request.result || []));
    request.addEventListener("error", () => reject(request.error));
  });
  database.close();
  return entries.sort((a, b) => Number(b.modifiedAt) - Number(a.modifiedAt));
}

async function storeInternalBackup(filename, payload) {
  const database = await openBackupDatabase();
  const entries = await internalBackupEntries();
  await new Promise((resolve, reject) => {
    const transaction = database.transaction(INTERNAL_BACKUP_STORE_NAME, "readwrite");
    const store = transaction.objectStore(INTERNAL_BACKUP_STORE_NAME);
    store.put({ filename, modifiedAt: Date.now(), payload });
    for (const entry of entries.slice(BACKUP_HISTORY_LIMIT - 1)) store.delete(entry.filename);
    transaction.addEventListener("complete", resolve);
    transaction.addEventListener("error", () => reject(transaction.error));
  });
  database.close();
}

async function ensureBackupDirectory({ requestPermission = false } = {}) {
  const handle = await getBackupDirectoryHandle();
  if (!handle) return null;
  const options = { mode: "readwrite" };
  let permission = await handle.queryPermission(options);
  if (permission !== "granted" && requestPermission) permission = await handle.requestPermission(options);
  return permission === "granted" ? handle : null;
}

async function backupAccessState() {
  const handle = await getBackupDirectoryHandle();
  if (!handle) return { handle: null, permission: "missing" };
  return { handle, permission: await handle.queryPermission({ mode: "readwrite" }) };
}

function backupPayload(reason = "automatic") {
  return {
    app: "Prompt Vault",
    version: 6,
    backupReason: reason,
    backedUpAt: new Date().toISOString(),
    categories: categoryList(),
    settings: { ...settings, categories: categoryList() },
    prompts: prompts.map(sanitizePrompt)
  };
}

function backupSignature(payload) {
  const text = JSON.stringify({ categories: payload.categories, settings: payload.settings, prompts: payload.prompts });
  let hash = 5381;
  for (let index = 0; index < text.length; index += 1) hash = ((hash << 5) + hash) ^ text.charCodeAt(index);
  return `${text.length}-${hash >>> 0}`;
}

function backupFilename(date = new Date(), reason = "automatic") {
  const stamp = date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  return `prompt-vault-backup-${stamp}-${reason}.json`;
}

async function backupFiles(directory) {
  const files = [];
  for await (const [name, handle] of directory.entries()) {
    if (handle.kind !== "file" || !/^prompt-vault-backup-.*\.json$/i.test(name)) continue;
    const file = await handle.getFile();
    files.push({ name, handle, file, modifiedAt: file.lastModified });
  }
  return files.sort((a, b) => b.modifiedAt - a.modifiedAt);
}

async function trimBackupHistory(directory) {
  const files = await backupFiles(directory);
  for (const entry of files.slice(BACKUP_HISTORY_LIMIT)) await directory.removeEntry(entry.name);
}

async function writeBackupSnapshot({ reason = "automatic", force = false, requestPermission = false } = {}) {
  if (backupWriteInProgress) return false;
  const payload = backupPayload(reason);
  const signature = backupSignature(payload);
  const meta = await chrome.storage.local.get({ [BACKUP_META_KEY]: {} });
  if (!force && meta[BACKUP_META_KEY]?.signature === signature) return false;
  backupWriteInProgress = true;
  try {
    const filename = backupFilename(new Date(), reason);
    await storeInternalBackup(filename, payload);
    try {
      const directory = await ensureBackupDirectory({ requestPermission });
      if (directory) {
        const fileHandle = await directory.getFileHandle(filename, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(JSON.stringify(payload, null, 2));
        await writable.close();
        await trimBackupHistory(directory);
      }
    } catch (_externalBackupError) {
      // Internal history remains available when a browser cannot persist folder permissions.
    }
    await chrome.storage.local.set({
      [BACKUP_META_KEY]: { signature, filename, backedUpAt: payload.backedUpAt }
    });
    return true;
  } finally {
    backupWriteInProgress = false;
  }
}

function scheduleAutomaticBackup() {
  clearTimeout(backupTimer);
  backupTimer = setTimeout(() => {
    writeBackupSnapshot().catch(() => updateSyncStatus("\u5185\u90E8\u81EA\u52A8\u5907\u4EFD\u5931\u8D25"));
  }, 700);
}

async function chooseBackupDirectory(reason = "setup") {
  if (typeof window.showDirectoryPicker !== "function") throw new Error("\u5F53\u524D Chrome \u7248\u672C\u4E0D\u652F\u6301\u6587\u4EF6\u5939\u5907\u4EFD");
  const handle = await window.showDirectoryPicker({ mode: "readwrite", id: "prompt-vault-backup" });
  await storeBackupDirectoryHandle(handle);
  settings.backupFolderName = handle.name;
  await saveSettings();
  await writeBackupSnapshot({ reason, force: true, requestPermission: true });
  updateSyncStatus(`\u5DF2\u542F\u7528\u81EA\u52A8\u5907\u4EFD\uFF1A${handle.name}`);
  return handle;
}

async function performManualBackup() {
  const handle = backupDirectoryHandleCache || await getBackupDirectoryHandle();
  let externalBackedUp = false;
  if (handle) {
    const permission = await handle.requestPermission({ mode: "readwrite" });
    if (permission === "granted") {
      settings.backupFolderName = handle.name;
      await saveSettings();
      externalBackedUp = true;
    }
  }
  await writeBackupSnapshot({ reason: "manual", force: true });
  updateSyncStatus(externalBackedUp ? "\u5DF2\u751F\u6210\u5185\u90E8\u4E0E\u6587\u4EF6\u5939\u5907\u4EFD" : "\u5DF2\u751F\u6210\u5185\u90E8\u5907\u4EFD");
  if (els.backupHistoryDialog.open) await renderBackupHistory();
}

async function downloadLatestInternalBackup() {
  const entry = (await internalBackupEntries())[0];
  if (!entry) throw new Error("\u8FD8\u6CA1\u6709\u53EF\u4E0B\u8F7D\u7684\u5907\u4EFD");
  const blob = new Blob([JSON.stringify(entry.payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = entry.filename;
  link.click();
  URL.revokeObjectURL(url);
}

function formatBackupTime(value) {
  return new Intl.DateTimeFormat("zh-CN", { dateStyle: "medium", timeStyle: "short" }).format(value);
}

async function renderBackupHistory() {
  els.backupHistoryList.innerHTML = "";
  els.backupPermissionActions.hidden = true;
  const access = await backupAccessState();
  if (!access.handle) {
    els.backupFolderStatus.textContent = settings.backupFolderName
      ? `\u5185\u90E8\u5907\u4EFD\u6B63\u5E38\u3002\u5916\u90E8\u6587\u4EF6\u5939\u201C${settings.backupFolderName}\u201D\u9700\u91CD\u65B0\u9009\u62E9\u540E\u624D\u80FD\u7EE7\u7EED\u5199\u5165\u3002`
      : "\u5185\u90E8\u5907\u4EFD\u6B63\u5E38\u3002\u5C1A\u672A\u8BBE\u7F6E\u53EF\u9009\u7684\u5916\u90E8\u5907\u4EFD\u6587\u4EF6\u5939\u3002";
    els.backupPermissionActions.hidden = false;
    els.reauthorizeBackup.hidden = true;
    els.reselectBackup.hidden = false;
    els.reselectBackup.textContent = settings.backupFolderName ? "\u91CD\u65B0\u9009\u62E9\u6587\u4EF6\u5939" : "\u9009\u62E9\u5907\u4EFD\u6587\u4EF6\u5939";
  } else if (access.permission !== "granted") {
    els.backupFolderStatus.textContent = `\u5DF2\u8BBE\u7F6E\u5907\u4EFD\u6587\u4EF6\u5939\u201C${settings.backupFolderName || access.handle.name}\u201D\uFF0C\u4F46 Chrome \u9700\u8981\u91CD\u65B0\u6388\u6743\u624D\u80FD\u8BFB\u53D6\u5907\u4EFD\u3002`;
    els.backupPermissionActions.hidden = false;
    els.reauthorizeBackup.hidden = false;
    els.reselectBackup.hidden = false;
    els.reselectBackup.textContent = "\u91CD\u65B0\u9009\u62E9\u6587\u4EF6\u5939";
  } else {
    els.backupFolderStatus.textContent = `\u5185\u90E8\u5907\u4EFD + \u5916\u90E8\u6587\u4EF6\u5939\uFF1A${access.handle.name}\uFF08\u6700\u8FD1 ${BACKUP_HISTORY_LIMIT} \u4EFD\uFF09`;
  }

  const internalEntries = await internalBackupEntries();
  if (!internalEntries.length) {
    els.backupHistoryList.textContent = "\u8FD8\u6CA1\u6709\u5185\u90E8\u5907\u4EFD\uFF0C\u70B9\u51FB\u201C\u7ACB\u5373\u5907\u4EFD\u201D\u5373\u53EF\u521B\u5EFA\u3002";
    return;
  }
  for (const entry of internalEntries) {
    const row = document.createElement("div");
    row.className = "backup-history-item";
    const info = document.createElement("span");
    const title = document.createElement("strong");
    title.textContent = formatBackupTime(Number(entry.modifiedAt));
    const detail = document.createElement("small");
    detail.textContent = "\u5185\u90E8\u5907\u4EFD";
    info.append(title, detail);
    const restore = document.createElement("button");
    restore.type = "button";
    restore.textContent = "\u6062\u590D";
    restore.addEventListener("click", async () => {
      restore.disabled = true;
      try {
        await restoreBackupPayload(entry.payload);
      } catch (error) {
        updateSyncStatus(error.message || "\u5907\u4EFD\u6062\u590D\u5931\u8D25");
      } finally {
        restore.disabled = false;
      }
    });
    row.append(info, restore);
    els.backupHistoryList.append(row);
  }
}

async function restoreBackupPayload(payload) {
  if (!confirm("\u6062\u590D\u540E\u5C06\u4F7F\u7528\u8BE5\u5907\u4EFD\u66FF\u6362\u5F53\u524D\u6570\u636E\u3002\u5F53\u524D\u6570\u636E\u4F1A\u5148\u81EA\u52A8\u5907\u4EFD\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F")) return;
  if (!Array.isArray(payload.prompts)) throw new Error("\u8BE5\u5907\u4EFD\u6587\u4EF6\u65E0\u6548");
  await writeBackupSnapshot({ reason: "before-restore", force: true });
  const backupFolderName = settings.backupFolderName || "";
  settings = { ...(payload.settings || {}), backupFolderName, categories: normalizeCategories(payload.categories || payload.settings?.categories) };
  prompts = normalizePromptOrders(payload.prompts.map(sanitizePrompt).map((item) => ({
    ...item,
    type: normalizeCategory(item.type)
  })));
  selectedId = prompts[0]?.id || null;
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings, [LOCAL_KEY]: prompts });
  await writeBackupSnapshot({ reason: "restored", force: true });
  render();
  await renderBackupHistory();
  updateSyncStatus("\u5DF2\u6062\u590D\u5907\u4EFD\uFF0C\u6062\u590D\u524D\u6570\u636E\u4E5F\u5DF2\u4FDD\u5B58");
}

function syncTombstones(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? { ...value } : {};
}

function mergeTombstones(localValue, remoteValue) {
  const merged = syncTombstones(localValue);
  for (const [id, timestamp] of Object.entries(syncTombstones(remoteValue))) {
    merged[id] = Math.max(Number(merged[id]) || 0, Number(timestamp) || 0);
  }
  return merged;
}

function sharedSyncPayload() {
  return {
    app: "Prompt Vault Shared Sync",
    version: 1,
    deviceId: installId,
    syncedAt: new Date().toISOString(),
    categories: categoryList(),
    prompts: prompts.map(sanitizePrompt),
    settings: {
      sortMode: settings.sortMode || "updated",
      categoryOrderUpdatedAt: Number(settings.categoryOrderUpdatedAt) || 0
    },
    promptTombstones: syncTombstones(settings.syncPromptTombstones),
    categoryTombstones: syncTombstones(settings.syncCategoryTombstones)
  };
}

async function readSharedSyncFile(directory) {
  try {
    const handle = await directory.getFileHandle(SHARED_SYNC_FILENAME);
    const file = await handle.getFile();
    const payload = JSON.parse(await file.text());
    return payload && Array.isArray(payload.prompts) ? payload : null;
  } catch (error) {
    if (error?.name === "NotFoundError") return null;
    throw error;
  }
}

async function writeSharedSyncFile(directory, payload) {
  const handle = await directory.getFileHandle(SHARED_SYNC_FILENAME, { create: true });
  const writable = await handle.createWritable();
  await writable.write(JSON.stringify(payload, null, 2));
  await writable.close();
}

function mergeSharedCategories(remotePayload, categoryTombstones) {
  const byId = new Map();
  for (const raw of [...categoryList(), ...normalizeCategories(remotePayload?.categories)]) {
    const category = { ...raw, updatedAt: Number(raw.updatedAt) || 0 };
    const current = byId.get(category.id);
    if (!current || category.updatedAt >= current.updatedAt) byId.set(category.id, category);
  }
  const available = [...byId.values()].filter((category) => {
    if (category.id === UNCATEGORIZED_CATEGORY.id) return true;
    return (Number(categoryTombstones[category.id]) || 0) < (Number(category.updatedAt) || 0);
  });
  const remoteOrderIsNewer = Number(remotePayload?.settings?.categoryOrderUpdatedAt) > Number(settings.categoryOrderUpdatedAt || 0);
  const orderSource = remoteOrderIsNewer ? (remotePayload?.categories || []) : categoryList();
  const rank = new Map(orderSource.map((category, index) => [category.id, index]));
  available.sort((a, b) => (rank.get(a.id) ?? Number.MAX_SAFE_INTEGER) - (rank.get(b.id) ?? Number.MAX_SAFE_INTEGER));
  return normalizeCategories(available);
}

function mergeSharedPrompts(remotePayload, promptTombstones) {
  const localById = new Map(prompts.map((item) => [item.id, sanitizePrompt(item)]));
  const remoteById = new Map((remotePayload?.prompts || []).map((item) => {
    const clean = sanitizePrompt(item);
    return [clean.id, clean];
  }));
  const merged = [];
  for (const id of new Set([...localById.keys(), ...remoteById.keys()])) {
    const local = localById.get(id);
    const remote = remoteById.get(id);
    const newest = !local ? remote : !remote ? local : (Number(remote.updatedAt) > Number(local.updatedAt) ? remote : local);
    if ((Number(promptTombstones[id]) || 0) >= (Number(newest?.updatedAt) || 0)) continue;
    if (local && remote && Number(local.updatedAt) === Number(remote.updatedAt) && importFingerprint(local) !== importFingerprint(remote)) {
      const localFingerprint = importFingerprint(local);
      const remoteFingerprint = importFingerprint(remote);
      const winner = localFingerprint <= remoteFingerprint ? local : remote;
      const conflict = winner === local ? remote : local;
      const conflictFingerprint = syncConflictFingerprint(conflict);
      merged.push(winner);
      merged.push({
        ...conflict,
        id: `sync-conflict-${stableSyncHash(`${id}|${conflictFingerprint}`)}`,
        title: `${syncConflictBaseTitle(conflict.title)} ${SYNC_CONFLICT_SUFFIX}`,
        updatedAt: Number(conflict.updatedAt) || 0,
        order: Number.MAX_SAFE_INTEGER
      });
    } else if (newest) {
      merged.push(newest);
    }
  }
  return normalizePromptOrders(dedupeSyncConflictCopies(merged));
}

function updateSharedSyncStatus(message = "") {
  if (!els.sharedSyncStatus) return;
  if (message) {
    els.sharedSyncStatus.textContent = message;
    return;
  }
  els.sharedSyncStatus.textContent = settings.sharedSyncEnabled
    ? `\u5DF2\u542F\u7528\uFF1A${settings.sharedSyncFolderName || "\u5171\u4EAB\u6587\u4EF6\u5939"}${settings.lastSharedSyncAt ? `\uFF0C${formatBackupTime(new Date(settings.lastSharedSyncAt).getTime())}` : ""}`
    : "\u5171\u4EAB\u540C\u6B65\u672A\u542F\u7528";
}

async function sharedSyncDirectory({ requestPermission = false } = {}) {
  const handle = sharedSyncDirectoryHandleCache || await getBackupDirectoryHandle(SHARED_SYNC_HANDLE_KEY);
  if (!handle) return null;
  let permission = await handle.queryPermission({ mode: "readwrite" });
  if (permission !== "granted" && requestPermission) permission = await handle.requestPermission({ mode: "readwrite" });
  return permission === "granted" ? handle : null;
}

async function syncSharedFolder({ requestPermission = false, automatic = false } = {}) {
  if (!settings.sharedSyncEnabled || sharedSyncInProgress || (automatic && editorMode !== "view")) return false;
  const directory = await sharedSyncDirectory({ requestPermission });
  if (!directory) {
    updateSharedSyncStatus("\u5171\u4EAB\u6587\u4EF6\u5939\u9700\u91CD\u65B0\u6388\u6743");
    return false;
  }
  sharedSyncInProgress = true;
  updateSharedSyncStatus("\u6B63\u5728\u540C\u6B65\u2026");
  try {
    const remote = await readSharedSyncFile(directory);
    if (remote) {
      const promptTombstones = mergeTombstones(settings.syncPromptTombstones, remote.promptTombstones);
      const categoryTombstones = mergeTombstones(settings.syncCategoryTombstones, remote.categoryTombstones);
      const mergedCategories = mergeSharedCategories(remote, categoryTombstones);
      const previousSignature = backupSignature(backupPayload("compare-sync"));
      settings.categories = mergedCategories;
      const mergedPrompts = mergeSharedPrompts(remote, promptTombstones).map((item) => ({ ...item, type: normalizeCategory(item.type) }));
      const nextSignature = backupSignature({ categories: mergedCategories, settings, prompts: mergedPrompts });
      if (previousSignature !== nextSignature) await writeBackupSnapshot({ reason: "before-sync", force: true }).catch(() => false);
      prompts = mergedPrompts;
      settings.syncPromptTombstones = promptTombstones;
      settings.syncCategoryTombstones = categoryTombstones;
      settings.categoryOrderUpdatedAt = Math.max(Number(settings.categoryOrderUpdatedAt) || 0, Number(remote.settings?.categoryOrderUpdatedAt) || 0);
      if (remote.settings?.sortMode) settings.sortMode = remote.settings.sortMode;
    }
    settings.lastSharedSyncAt = new Date().toISOString();
    await chrome.storage.local.set({ [LOCAL_KEY]: prompts, [SETTINGS_KEY]: settings });
    await writeSharedSyncFile(directory, sharedSyncPayload());
    render();
    updateSharedSyncStatus();
    return true;
  } finally {
    sharedSyncInProgress = false;
  }
}

function scheduleSharedSync() {
  if (!settings.sharedSyncEnabled || sharedSyncInProgress) return;
  clearTimeout(sharedSyncTimer);
  sharedSyncTimer = setTimeout(() => {
    syncSharedFolder({ automatic: true }).catch((error) => updateSharedSyncStatus(error.message || "\u540C\u6B65\u5931\u8D25"));
  }, 1800);
}

async function enableSharedSync() {
  if (typeof window.showDirectoryPicker !== "function") throw new Error("\u5F53\u524D Chrome \u7248\u672C\u4E0D\u652F\u6301\u5171\u4EAB\u6587\u4EF6\u5939\u540C\u6B65");
  const directory = await window.showDirectoryPicker({ mode: "readwrite", id: "prompt-vault-shared-sync" });
  await storeBackupDirectoryHandle(directory, SHARED_SYNC_HANDLE_KEY);
  const remote = await readSharedSyncFile(directory);
  if (remote && !confirm(`\u8BE5\u6587\u4EF6\u5939\u5DF2\u6709 ${remote.prompts.length} \u6761 Prompt\uFF0C\u672C\u5730\u6709 ${prompts.length} \u6761\u3002\u5C06\u5728\u5907\u4EFD\u540E\u5408\u5E76\uFF0C\u662F\u5426\u7EE7\u7EED\uFF1F`)) return false;
  settings.sharedSyncEnabled = true;
  settings.sharedSyncFolderName = directory.name;
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  await syncSharedFolder({ requestPermission: true });
  return true;
}

function selectedPrompt() {
  return prompts.find((item) => item.id === selectedId) || prompts[0] || null;
}

const taxonomyCollator = new Intl.Collator("zh-Hans-u-co-pinyin", {
  numeric: true,
  sensitivity: "base"
});

function taxonomyRank(value) {
  const first = String(value || "").trim().charAt(0);
  if (/^[A-Za-z]$/.test(first)) return 0;
  if (/^[0-9]$/.test(first)) return 1;
  if (/[\u4e00-\u9fff]/.test(first)) return 2;
  return 3;
}

function compareTaxonomy(a, b) {
  return taxonomyRank(a) - taxonomyRank(b) || taxonomyCollator.compare(a, b);
}

function uniqueValues(values) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))].sort(compareTaxonomy);
}

function frequentValues(values, limit = 3) {
  const scores = new Map();
  values
    .map((value) => String(value || "").trim())
    .filter(Boolean)
    .forEach((value) => scores.set(value, (scores.get(value) || 0) + 1));

  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1] || compareTaxonomy(a[0], b[0]))
    .slice(0, limit)
    .map(([value]) => value);
}

function rankedValues(values, commonValues = []) {
  const common = uniqueValues(commonValues).slice(0, 3);
  const rest = uniqueValues(values).filter((value) => !common.includes(value));
  return [...common, ...rest];
}

function uniqueProjects() {
  const values = prompts.map((item) => item.project);
  return rankedValues(values, frequentValues(values));
}

function uniqueGenres() {
  return uniqueValues(prompts.map((item) => item.genre));
}

function uniqueScenes(project = "") {
  const values = prompts.filter((item) => !project || item.project === project).map((item) => item.scene);
  return rankedValues(values, frequentValues(values));
}

function editorSceneOptions(project = "") {
  const allScenes = prompts.map((item) => item.scene);
  const projectScenes = prompts.filter((item) => project && item.project === project).map((item) => item.scene);
  return rankedValues([...projectScenes, ...allScenes], frequentValues(allScenes));
}

function uniqueTags() {
  return uniqueValues(prompts.flatMap((item) => item.tags || []));
}

function splitNegativeTerms(value) {
  return String(value || "")
    .split(/[,\uFF0C\u3001\n\r]+/)
    .map((term) => term.replace(/^\u7981\u6B62\uFF1A\s*/i, "").trim())
    .filter((term) => term.length >= 2 && term.length <= 24);
}

function frequentNegativeTerms() {
  const scores = new Map();
  for (const item of prompts) {
    for (const term of splitNegativeTerms(item.negative)) {
      scores.set(term, (scores.get(term) || 0) + 1);
    }
  }

  for (const term of DEFAULT_NEGATIVE_TERMS) {
    if (!scores.has(term)) scores.set(term, 0);
  }

  return [...scores.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "zh-CN"))
    .map(([term]) => term)
    .slice(0, 24);
}

function hasPromptImage(value) {
  const image = String(value || "").trim();
  return /^(data:image\/|blob:|https?:\/\/|file:\/\/)/i.test(image);
}

function matches(item) {
  const query = els.search.value.trim().toLowerCase();
  const project = els.projectFilter.value;
  const scene = els.sceneFilter.value;
  const genre = els.genreFilter.value;
  const tag = els.tagFilter.value;
  const haystack = [item.title, item.project, item.scene, item.genre, item.type, item.prompt, item.promptEn, item.negative, ...(item.tags || [])].join(" ").toLowerCase();
  const categoryMatches = activeCategory === "all" || item.type === activeCategory;
  const favoriteMatches = !favoriteOnly || item.favorite;
  return (!query || haystack.includes(query)) && categoryMatches &&
    favoriteMatches &&
    (project === "all" || (item.project || "") === project) &&
    (scene === "all" || (item.scene || "") === scene) &&
    (genre === "all" || (item.genre || "") === genre) &&
    (tag === "all" || (item.tags || []).includes(tag));
}

function replaceOptions(select, firstLabel, values) {
  const current = select.value;
  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "all";
  all.textContent = firstLabel;
  select.append(all);
  for (const value of values) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.append(option);
  }
  select.value = values.includes(current) ? current : "all";
}

function renderTaxonomy() {
  const projects = uniqueProjects();
  const filteredProject = els.projectFilter.value === "all" ? "" : els.projectFilter.value;
  const scenes = uniqueScenes(filteredProject);
  const editorScenes = editorSceneOptions(els.project.value.trim());
  const genres = uniqueGenres();
  const tags = uniqueTags();

  replaceOptions(els.projectFilter, "\u9879\u76EE", projects);
  replaceOptions(els.sceneFilter, "\u573A\u666F", scenes);
  replaceOptions(els.genreFilter, "\u7C7B\u578B", genres);
  replaceOptions(els.tagFilter, "\u6807\u7B7E", tags);

  els.projectOptions.innerHTML = "";
  for (const project of projects) {
    const option = document.createElement("option");
    option.value = project;
    els.projectOptions.append(option);
  }
  renderTaxonomyDropdown(els.projectDropdown, projects, addProject);

  els.sceneOptions.innerHTML = "";
  for (const scene of editorScenes) {
    const option = document.createElement("option");
    option.value = scene;
    els.sceneOptions.append(option);
  }

  renderTaxonomyDropdown(els.sceneDropdown, editorScenes, addScene);

  els.genreOptions.innerHTML = "";
  for (const genre of genres) {
    const option = document.createElement("option");
    option.value = genre;
    els.genreOptions.append(option);
  }
  renderTaxonomyDropdown(els.genreDropdown, genres, addGenre);
  renderTaxonomyDropdown(els.tagDropdown, tags, addTag);

  if (els.tagSuggestions) {
    els.tagSuggestions.innerHTML = "";
    for (const tag of tags.slice(0, 24)) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = tag;
      button.addEventListener("click", () => addTag(tag));
      els.tagSuggestions.append(button);
    }
  }

  if (els.negativeSuggestions) {
    els.negativeSuggestions.innerHTML = "";
    for (const term of frequentNegativeTerms()) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = term;
      button.addEventListener("click", () => addNegativeTerm(term));
      els.negativeSuggestions.append(button);
    }
    updateNegativeSuggestionsVisibility();
  }
}

function addTag(tag) {
  const tags = normalizeTags(els.tags.value);
  if (!tags.includes(tag)) tags.push(tag);
  els.tags.value = tags.join(", ");
  hideTaxonomyDropdowns();
  scheduleAutoSave();
}

function addProject(project) {
  els.project.value = project;
  hideTaxonomyDropdowns();
  renderTaxonomy();
  scheduleAutoSave();
}

function addScene(scene) {
  els.scene.value = scene;
  hideTaxonomyDropdowns();
  renderTaxonomy();
  scheduleAutoSave();
}

function addGenre(genre) {
  els.genre.value = genre;
  hideTaxonomyDropdowns();
  scheduleAutoSave();
}

function addModel(model) {
  els.model.value = model;
  hideTaxonomyDropdowns();
  scheduleAutoSave();
}

function renderTaxonomyDropdown(dropdown, values, onSelect) {
  if (!dropdown) return;
  dropdown.innerHTML = "";
  dropdown.hidden = true;
  for (const value of values) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = value;
    button.addEventListener("click", () => onSelect(value));
    dropdown.append(button);
  }
}

function showTaxonomyDropdown(dropdown) {
  renderTaxonomy();
  hideTaxonomyDropdowns(dropdown);
  if (dropdown?.children.length) dropdown.hidden = false;
}

function hideTaxonomyDropdowns(except = null) {
  [els.projectDropdown, els.sceneDropdown, els.genreDropdown, els.tagDropdown, els.modelDropdown].forEach((dropdown) => {
    if (dropdown && dropdown !== except) dropdown.hidden = true;
  });
}

function addNegativeTerm(term) {
  const terms = splitNegativeTerms(els.negative.value);
  if (!terms.includes(term)) terms.push(term);
  els.negative.value = terms.join("\u3001");
  els.negative.focus();
  scheduleAutoSave();
}

function renderCategoryTabs() {
  if (!els.categoryTabsContainer) return;
  const categories = categoryList();
  if (activeCategory !== "all" && !categories.some((item) => item.id === activeCategory)) {
    activeCategory = "all";
  }
  els.categoryTabsContainer.innerHTML = "";
  const tabs = [
    { id: "all", label: "\u5168\u90E8", fixed: true },
    ...categories.map((item) => ({
      ...item,
      label: COMPACT_CATEGORY_IDS.has(item.id) ? item.label.slice(0, 2) : item.label
    }))
  ];
  els.favoriteFilter?.setAttribute("aria-pressed", String(favoriteOnly));

  for (const tab of tabs) {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.category = tab.id;
    const iconLabel = String(tab.label || tab.short || "");
    button.dataset.categoryIcon = tab.id === UNCATEGORIZED_CATEGORY.id
      ? "none"
      : tab.icon || (iconLabel.includes("\u9053\u5177")
        ? "archive"
        : iconLabel.includes("\u7279\u6548")
          ? "sparkles"
          : iconLabel.includes("\u518d\u91ce")
            ? "eye"
            : "default");
    button.textContent = tab.label;
    if (tab.title) button.title = tab.title;
    button.setAttribute("aria-pressed", String(tab.id === activeCategory));
    if (!tab.fixed && tab.id !== UNCATEGORIZED_CATEGORY.id) {
      button.draggable = true;
      button.addEventListener("dragstart", (event) => {
        event.dataTransfer.setData("text/plain", tab.id);
      });
      button.addEventListener("dragover", (event) => event.preventDefault());
      button.addEventListener("drop", async (event) => {
        event.preventDefault();
        const draggedId = event.dataTransfer.getData("text/plain");
        if (!draggedId || draggedId === tab.id) return;
        const next = [...categoryList()];
        const from = next.findIndex((item) => item.id === draggedId);
        const to = next.findIndex((item) => item.id === tab.id);
        if (from < 0 || to < 0) return;
        const [dragged] = next.splice(from, 1);
        next.splice(to, 0, dragged);
        settings.categories = next;
        settings.categoryOrderUpdatedAt = now();
        await saveSettings();
        render();
      });
    }
    button.addEventListener("click", () => {
      activeCategory = tab.id;
      if (activeCategory === "constraint") clearTopFilters();
      renderList();
    });
    if (!tab.fixed && tab.id !== UNCATEGORIZED_CATEGORY.id) {
      button.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        showCategoryContextMenu(tab.id, event.clientX, event.clientY);
      });
    }
    els.categoryTabsContainer.append(button);
  }
  const heightHandle = document.createElement("div");
  heightHandle.className = "category-height-resize-handle";
  heightHandle.setAttribute("role", "separator");
  heightHandle.setAttribute("aria-orientation", "horizontal");
  heightHandle.title = "拖动调整类别按钮高度；双击恢复默认";
  bindCategoryHeightResize(heightHandle, tabs.length);
  els.categoryTabsContainer.append(heightHandle);
  const addButton = document.createElement("button");
  addButton.type = "button";
  addButton.className = "category-add";
  addButton.textContent = "\uff0b \u6dfb\u52a0";
  addButton.addEventListener("click", addCategoryFromSidebar);
  els.categoryTabsContainer.append(addButton);
  els.categoryTabs = [...els.categoryTabsContainer.querySelectorAll("[data-category]")];
}

function chooseCategoryIcon() {
  const choices = [
    ["default", "\u6587\u4ef6\u5939", "all"],
    ["archive", "\u6536\u7eb3\u76d2", "archive"],
    ["scene", "\u573a\u666f", "scene"],
    ["character", "\u4eba\u7269", "character"],
    ["video", "\u89c6\u9891", "video"],
    ["constraint", "\u7ea6\u675f", "constraint"],
    ["task", "\u4efb\u52a1", "task"],
    ["sparkles", "\u7279\u6548", "sparkles"],
    ["eye", "\u773c\u775b", "eye"],
    ["download", "\u4e0b\u8f7d", "download"],
    ["layout", "\u5e03\u5c40", "layout"],
    ["zoom", "\u653e\u5927", "zoom"],
    ["book", "\u4e66\u672c", "book"],
    ["layers", "\u56fe\u5c42", "layers"],
    ["heart", "\u7231\u5fc3", "heart"],
    ["chat", "\u5bf9\u8bdd", "chat"],
    ["grid", "\u56db\u5bab\u683c", "grid"],
    ["status", "\u72b6\u6001", "status"],
    ["document", "\u6587\u6863", "document"],
    ["location", "\u4f4d\u7f6e", "location"],
    ["play", "\u64ad\u653e", "play"],
    ["table", "\u8868\u683c", "table"],
    ["none", "\u65e0\u56fe\u6807", "none"]
  ];
  const dialog = document.createElement("dialog");
  dialog.className = "category-icon-dialog";
  const section = document.createElement("section");
  const title = document.createElement("strong");
  title.textContent = "\u9009\u62e9\u7c7b\u522b\u56fe\u6807";
  const options = document.createElement("div");
  options.className = "category-tabs category-icon-options";
  for (const [value, label, iconCategory] of choices) {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.iconValue = value;
    button.dataset.category = iconCategory;
    button.dataset.categoryIcon = value;
    button.textContent = value === "none" ? label : "";
    button.title = label;
    button.setAttribute("aria-label", label);
    options.append(button);
  }
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.textContent = "\u53d6\u6d88";
  cancel.className = "category-icon-cancel";
  section.append(title, options, cancel);
  dialog.append(section);
  document.body.append(dialog);
  dialog.showModal();
  return new Promise((resolve) => {
    const finish = (value) => {
      dialog.close();
      dialog.remove();
      resolve(value);
    };
    options.addEventListener("click", (event) => {
      const button = event.target.closest("[data-icon-value]");
      if (button) finish(button.dataset.iconValue);
    });
    cancel.addEventListener("click", () => finish(null));
    dialog.addEventListener("cancel", (event) => {
      event.preventDefault();
      finish(null);
    });
  });
}

async function addCategoryFromSidebar({ activate = true, selectInEditor = false } = {}) {
  const label = window.prompt("\u8bf7\u8f93\u5165\u65b0\u7c7b\u522b\u540d\u79f0");
  const trimmed = String(label || "").trim();
  if (!trimmed) return;
  const existing = categoryList().find((item) => item.label === trimmed || item.short === trimmed);
  if (existing) {
    if (activate) activeCategory = existing.id;
    if (selectInEditor) els.category.value = existing.id;
    render();
    updateSyncStatus("\u8be5\u7c7b\u522b\u5df2\u5b58\u5728");
    return existing;
  }
  const icon = await chooseCategoryIcon();
  if (icon === null) return;
  const next = [...categoryList()];
  const category = {
    id: categoryIdFromLabel(trimmed, next),
    label: trimmed,
    short: shortCategoryLabel(trimmed),
    icon,
    updatedAt: now()
  };
  next.push(category);
  settings.categories = next;
  settings.categoryOrderUpdatedAt = now();
  if (activate) activeCategory = category.id;
  await saveSettings();
  render();
  if (selectInEditor) els.category.value = category.id;
  updateSyncStatus(`\u5df2\u6dfb\u52a0\u7c7b\u522b\uff1a${trimmed}`);
  return category;
}

function closeCategoryContextMenu() {
  document.querySelector(".category-context-menu")?.remove();
}

function showCategoryContextMenu(categoryId, x, y) {
  closeCategoryContextMenu();
  const category = categoryList().find((item) => item.id === categoryId);
  if (!category || category.id === UNCATEGORIZED_CATEGORY.id) return;
  const menu = document.createElement("div");
  menu.className = "category-context-menu";
  const rename = document.createElement("button");
  rename.type = "button";
  rename.textContent = "\u91CD\u547D\u540D";
  rename.addEventListener("click", async () => {
    closeCategoryContextMenu();
    await renameCategory(category.id);
  });
  const changeIcon = document.createElement("button");
  changeIcon.type = "button";
  changeIcon.textContent = "\u6362\u56fe\u6807";
  changeIcon.addEventListener("click", async () => {
    closeCategoryContextMenu();
    await changeCategoryIcon(category.id);
  });
  const remove = document.createElement("button");
  remove.type = "button";
  remove.textContent = "\u5220\u9664";
  remove.className = "danger";
  remove.addEventListener("click", async () => {
    closeCategoryContextMenu();
    await deleteCategory(category.id);
  });
  menu.append(rename, changeIcon, remove);
  document.body.append(menu);
  const width = menu.offsetWidth;
  const height = menu.offsetHeight;
  menu.style.left = `${Math.min(x, window.innerWidth - width - 8)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - height - 8)}px`;
}

async function changeCategoryIcon(categoryId) {
  const category = categoryList().find((item) => item.id === categoryId);
  if (!category || category.id === UNCATEGORIZED_CATEGORY.id) return;
  const icon = await chooseCategoryIcon();
  if (icon === null || icon === category.icon) return;
  settings.categories = categoryList().map((item) => item.id === categoryId
    ? { ...item, icon, updatedAt: now() }
    : item);
  await saveSettings();
  render();
}

async function renameCategory(categoryId) {
  const category = categoryList().find((item) => item.id === categoryId);
  if (!category || category.id === UNCATEGORIZED_CATEGORY.id) return;
  const label = window.prompt("\u91CD\u547D\u540D\u7C7B\u522B", category.label);
  const trimmed = String(label || "").trim();
  if (!trimmed || trimmed === category.label) return;
  if (categoryList().some((item) => item.id !== categoryId && (item.label === trimmed || item.short === trimmed))) {
    updateSyncStatus("\u8BE5\u7C7B\u522B\u540D\u79F0\u5DF2\u5B58\u5728");
    return;
  }
  settings.categories = categoryList().map((item) => item.id === categoryId
    ? { ...item, label: trimmed, short: shortCategoryLabel(trimmed), updatedAt: now() }
    : item);
  await saveSettings();
  render();
  updateSyncStatus(`\u5DF2\u91CD\u547D\u540D\u7C7B\u522B\uFF1A${trimmed}`);
}

async function deleteCategory(categoryId) {
  const category = categoryList().find((item) => item.id === categoryId);
  if (!category || category.id === UNCATEGORIZED_CATEGORY.id) return;
  const nextCategories = categoryList().filter((item) => item.id !== categoryId);
  const count = prompts.filter((item) => item.type === categoryId).length;
  let migrateTo = "";
  if (count > 0) {
    migrateTo = await requestCategoryMigration([{ ...category, count }], nextCategories);
    if (!migrateTo) return;
  } else if (!confirm(`\u786E\u5B9A\u5220\u9664\u7C7B\u522B\u201C${category.label}\u201D\u5417\uFF1F`)) {
    return;
  }
  if (migrateTo) {
    prompts = prompts.map((item) => item.type === categoryId
      ? { ...item, type: migrateTo, updatedAt: now() }
      : item);
  }
  settings.categories = nextCategories;
  settings.categoryOrderUpdatedAt = now();
  settings.syncCategoryTombstones = { ...syncTombstones(settings.syncCategoryTombstones), [categoryId]: now() };
  if (activeCategory === categoryId) activeCategory = migrateTo || "all";
  await saveSettings();
  if (count > 0) await saveAll();
  render();
  updateSyncStatus(`\u5DF2\u5220\u9664\u7C7B\u522B\uFF1A${category.label}`);
}

async function applyPendingOpen() {
  const params = new URLSearchParams(window.location.search);
  const stored = await chrome.storage.local.get({ [PENDING_OPEN_KEY]: null });
  const pending = stored[PENDING_OPEN_KEY];
  const id = params.get("promptId") || pending?.id || "";
  if (id && prompts.some((item) => item.id === id)) {
    selectedId = id;
    editorMode = params.get("edit") === "1" || pending?.mode === "edit" ? "edit" : "view";
    clearFilters();
  }
  if (pending) await chrome.storage.local.remove(PENDING_OPEN_KEY);
}

function categorySummaryLabel() {
  const base = activeCategory === "all" ? "\u5168\u90E8" : categoryShortLabel(activeCategory) || "Prompt";
  return favoriteOnly ? `${base}\u6536\u85CF` : base;
}

function hidePreviewCategoryMenu() {
  if (els.previewCategoryMenu) els.previewCategoryMenu.hidden = true;
}

let previewTaxonomyMenu = null;

function hidePreviewTaxonomyMenu() {
  previewTaxonomyMenu?.remove();
  previewTaxonomyMenu = null;
}

function previewTaxonomyOptions(field, item) {
  if (field === "project") return uniqueProjects();
  if (field === "scene") return editorSceneOptions(item.project);
  if (field === "model") return modelList();
  return uniqueGenres();
}

function showPreviewTaxonomyMenu(field, anchor) {
  hidePreviewTaxonomyMenu();
  const item = selectedPrompt();
  if (!item) return;
  const values = previewTaxonomyOptions(field, item);
  if (!values.length) return;

  const menu = document.createElement("div");
  menu.className = "preview-taxonomy-menu";
  menu.setAttribute("role", "menu");
  for (const value of values) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = value;
    button.setAttribute("aria-pressed", String(value === item[field]));
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      if (item[field] !== value) {
        item[field] = value;
        selectedId = item.id;
        await saveAll();
      }
      hidePreviewTaxonomyMenu();
      render();
    });
    menu.append(button);
  }
  document.body.append(menu);
  previewTaxonomyMenu = menu;
  const rect = anchor.getBoundingClientRect();
  const left = Math.min(rect.left, window.innerWidth - menu.offsetWidth - 8);
  const below = rect.bottom + 5;
  const top = below + menu.offsetHeight <= window.innerHeight - 8
    ? below
    : Math.max(8, rect.top - menu.offsetHeight - 5);
  menu.style.left = `${Math.max(8, left)}px`;
  menu.style.top = `${top}px`;
}

function renderPreviewCategoryMenu() {
  if (!els.previewCategoryMenu) return;
  const item = selectedPrompt();
  els.previewCategoryMenu.innerHTML = "";
  if (!item) {
    els.previewCategoryMenu.hidden = true;
    return;
  }
  for (const category of categoryList()) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = category.label;
    button.setAttribute("aria-pressed", String(category.id === item.type));
    button.addEventListener("click", async () => {
      if (item.type !== category.id) {
        item.type = category.id;
        item.updatedAt = now();
        selectedId = item.id;
        await saveAll();
      }
      hidePreviewCategoryMenu();
      render();
    });
    els.previewCategoryMenu.append(button);
  }
}

function sortVisibleItems(items) {
  const mode = els.sortMode?.value || "updated";
  return [...items].sort((a, b) => {
    if (mode === "custom") {
      const orderDifference = Number(a.order || 0) - Number(b.order || 0);
      if (orderDifference) return orderDifference;
      return (a.createdAt || 0) - (b.createdAt || 0);
    }
    if (mode === "usage") {
      const bUsage = Number(b.usageCount || 0);
      const aUsage = Number(a.usageCount || 0);
      if (bUsage !== aUsage) return bUsage - aUsage;
      const bLastUsed = Number(b.lastUsedAt || 0);
      const aLastUsed = Number(a.lastUsedAt || 0);
      if (bLastUsed !== aLastUsed) return bLastUsed - aLastUsed;
    }
    return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0);
  });
}

async function reorderPromptById(draggedId, targetId) {
  if (!draggedId || draggedId === targetId) return;
  const ordered = [...prompts].sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
  const from = ordered.findIndex((item) => item.id === draggedId);
  const to = ordered.findIndex((item) => item.id === targetId);
  if (from < 0 || to < 0) return;
  const [dragged] = ordered.splice(from, 1);
  ordered.splice(to, 0, dragged);
  const orderById = new Map(ordered.map((item, index) => [item.id, index]));
  const reorderedAt = now();
  prompts = prompts.map((item) => {
    const order = orderById.get(item.id);
    return order === item.order ? item : { ...item, order, updatedAt: reorderedAt };
  });
  await saveAll();
  renderList();
}

async function saveBulkUndoHistory() {
  try {
    await chrome.storage.session?.set({
      [BULK_UNDO_KEY]: {
        undo: bulkUndoStack.slice(-BULK_UNDO_LIMIT),
        redo: bulkRedoStack.slice(-BULK_UNDO_LIMIT)
      }
    });
    bulkUndoSessionDirty = false;
  } catch {
    // Keep the in-memory history when session storage cannot fit image-heavy entries.
    bulkUndoSessionDirty = true;
  }
}

async function loadBulkUndoHistory() {
  if (bulkUndoSessionDirty) return;
  try {
    const result = await chrome.storage.session?.get({ [BULK_UNDO_KEY]: [] });
    const history = result?.[BULK_UNDO_KEY];
    bulkUndoStack = Array.isArray(history)
      ? history.slice(-BULK_UNDO_LIMIT)
      : Array.isArray(history?.undo) ? history.undo.slice(-BULK_UNDO_LIMIT) : [];
    bulkRedoStack = Array.isArray(history?.redo) ? history.redo.slice(-BULK_UNDO_LIMIT) : [];
  } catch {
    bulkUndoStack = [];
    bulkRedoStack = [];
  }
}

function renderBulkControls(visible) {
  if (!els.bulkEditBar) return;
  bulkSelectedIds = new Set([...bulkSelectedIds].filter((id) => prompts.some((item) => item.id === id)));
  els.bulkEditBar.hidden = !bulkEditMode;
  els.toggleBulkEdit.textContent = bulkEditMode ? "完成" : "批量";
  els.toggleBulkEdit.setAttribute("aria-pressed", String(bulkEditMode));
  els.bulkSelectionSummary.textContent = `已选 ${bulkSelectedIds.size} 条`;
  const allVisibleSelected = visible.length > 0 && visible.every((item) => bulkSelectedIds.has(item.id));
  els.selectAllBulk.textContent = allVisibleSelected ? "取消全选" : "全选当前";
  els.applyBulkEdit.disabled = bulkSelectedIds.size === 0;
  els.bulkDelete.disabled = bulkSelectedIds.size === 0;
  els.undoBulkEdit.disabled = bulkUndoStack.length === 0;
  els.redoBulkEdit.disabled = bulkRedoStack.length === 0;
  els.previewUndoPrompt.disabled = bulkUndoStack.length === 0;
  els.previewRedoPrompt.disabled = bulkRedoStack.length === 0;
  if (els.editorUndoPrompt) els.editorUndoPrompt.disabled = bulkUndoStack.length === 0;
  if (els.editorRedoPrompt) els.editorRedoPrompt.disabled = bulkRedoStack.length === 0;

  const currentCategory = els.bulkCategory.value;
  els.bulkCategory.innerHTML = '<option value="">类别不变</option>';
  for (const category of categoryList()) {
    const option = document.createElement("option");
    option.value = category.id;
    option.textContent = category.label;
    els.bulkCategory.append(option);
  }
  if ([...els.bulkCategory.options].some((option) => option.value === currentCategory)) {
    els.bulkCategory.value = currentCategory;
  }
  const currentProject = els.bulkProject.value;
  els.bulkProject.innerHTML = '<option value="">项目不变</option>';
  for (const project of uniqueProjects()) {
    const option = document.createElement("option");
    option.value = project;
    option.textContent = project;
    els.bulkProject.append(option);
  }
  if ([...els.bulkProject.options].some((option) => option.value === currentProject)) {
    els.bulkProject.value = currentProject;
  }
  const currentScene = els.bulkScene.value;
  els.bulkScene.innerHTML = '<option value="">场景不变</option>';
  for (const scene of uniqueScenes()) {
    const option = document.createElement("option");
    option.value = scene;
    option.textContent = scene;
    els.bulkScene.append(option);
  }
  if ([...els.bulkScene.options].some((option) => option.value === currentScene)) {
    els.bulkScene.value = currentScene;
  }
}

async function commitBulkMutation({ changes = null, remove = false, label = "批量修改" } = {}) {
  const ids = [...bulkSelectedIds].filter((id) => prompts.some((item) => item.id === id));
  if (!ids.length) return;
  clearTimeout(autoSaveTimer);
  if (editorMode !== "view") await persistCurrentForm();
  const affected = new Set(ids);
  const tombstones = syncTombstones(settings.syncPromptTombstones);
  const history = {
    label,
    affectedIds: ids,
    beforeItems: prompts
      .map((item, index) => affected.has(item.id) ? { index, item: structuredClone(item) } : null)
      .filter(Boolean),
    tombstonesBefore: Object.fromEntries(ids.map((id) => [id, Object.prototype.hasOwnProperty.call(tombstones, id) ? tombstones[id] : null])),
    selectedIdBefore: selectedId
  };
  const changedAt = now();
  if (remove) {
    prompts = prompts.filter((item) => !affected.has(item.id));
    for (const id of ids) tombstones[id] = changedAt;
    settings.syncPromptTombstones = tombstones;
    if (affected.has(selectedId)) selectedId = prompts[0]?.id || null;
  } else {
    prompts = prompts.map((item) => affected.has(item.id) ? { ...item, ...changes, updatedAt: changedAt } : item);
  }
  history.afterItems = prompts
    .map((item, index) => affected.has(item.id) ? { index, item: structuredClone(item) } : null)
    .filter(Boolean);
  history.tombstonesAfter = Object.fromEntries(ids.map((id) => [id, Object.prototype.hasOwnProperty.call(tombstones, id) ? tombstones[id] : null]));
  history.selectedIdAfter = selectedId;
  bulkUndoStack.push(history);
  bulkUndoStack = bulkUndoStack.slice(-BULK_UNDO_LIMIT);
  bulkRedoStack = [];
  bulkSelectedIds.clear();
  await saveBulkUndoHistory();
  if (remove) await saveSettings();
  await saveAll();
  render();
  updateSyncStatus(`${label} ${ids.length} 条`);
}

async function restoreBulkHistory(history, direction) {
  clearTimeout(autoSaveTimer);
  if (editorMode !== "view") await persistCurrentForm();
  const affected = new Set(history.affectedIds || []);
  prompts = prompts.filter((item) => !affected.has(item.id));
  const restoredAt = now();
  const entries = direction === "undo" ? history.beforeItems : history.afterItems;
  for (const entry of [...(entries || [])].sort((a, b) => a.index - b.index)) {
    const index = Math.min(Math.max(0, entry.index), prompts.length);
    prompts.splice(index, 0, { ...entry.item, updatedAt: restoredAt });
  }
  const tombstones = syncTombstones(settings.syncPromptTombstones);
  const targetTombstones = direction === "undo" ? history.tombstonesBefore : history.tombstonesAfter;
  const restoredIds = new Set((entries || []).map((entry) => entry.item.id));
  for (const id of affected) {
    const target = targetTombstones?.[id];
    if (restoredIds.has(id) && (target === null || target === undefined)) delete tombstones[id];
    else tombstones[id] = restoredIds.has(id) ? target : restoredAt;
  }
  settings.syncPromptTombstones = tombstones;
  const targetSelectedId = direction === "undo" ? history.selectedIdBefore : history.selectedIdAfter;
  selectedId = prompts.some((item) => item.id === targetSelectedId) ? targetSelectedId : prompts[0]?.id || null;
  bulkSelectedIds = new Set([...affected].filter((id) => prompts.some((item) => item.id === id)));
  await saveSettings();
  await saveAll();
}

async function undoBulkMutation() {
  await loadBulkUndoHistory();
  const history = bulkUndoStack.pop();
  if (!history) return;
  await restoreBulkHistory(history, "undo");
  if (Array.isArray(history.afterItems)) {
    bulkRedoStack.push(history);
    bulkRedoStack = bulkRedoStack.slice(-BULK_UNDO_LIMIT);
  }
  await saveBulkUndoHistory();
  render();
  updateSyncStatus(`已撤回：${history.label}`);
}

async function redoBulkMutation() {
  await loadBulkUndoHistory();
  const history = bulkRedoStack.pop();
  if (!history) return;
  await restoreBulkHistory(history, "redo");
  bulkUndoStack.push(history);
  bulkUndoStack = bulkUndoStack.slice(-BULK_UNDO_LIMIT);
  await saveBulkUndoHistory();
  render();
  updateSyncStatus(`已取消撤回：${history.label}`);
}

function renderList() {
  renderCategoryTabs();
  const visible = sortVisibleItems(prompts.filter(matches));
  renderBulkControls(visible);
  if (els.listSummary) els.listSummary.textContent = `${categorySummaryLabel()} ${visible.length} \u6761`;
  els.list.innerHTML = "";

  if (!visible.length) {
    els.list.append(els.emptyTemplate.content.cloneNode(true));
    return;
  }

  for (const item of visible) {
    const card = document.createElement(IS_SIDEPANEL || bulkEditMode ? "article" : "button");
    if (!IS_SIDEPANEL && !bulkEditMode) card.type = "button";
    card.className = `prompt-card${item.favorite ? " is-favorite" : ""}${hasPromptImage(item.image) ? " has-image" : ""}${bulkSelectedIds.has(item.id) ? " is-bulk-selected" : ""}`;
    card.setAttribute("aria-selected", String(bulkEditMode ? bulkSelectedIds.has(item.id) : item.id === selectedId));

    const thumb = hasPromptImage(item.image)
      ? `<img class="thumb" alt="" src="${item.image}">`
      : "";

    card.innerHTML = `
      <div class="prompt-card-top">
        <div class="prompt-card-main">
          <div class="prompt-card-title-row">
            <h2></h2>
          </div>
          <div class="meta">
            <span class="chip" data-project></span>
            <span class="chip" data-scene></span>
            <span class="chip" data-genre></span>
          </div>
          <div class="excerpt"></div>
        </div>
        <div class="prompt-card-side">
          <span class="chip prompt-card-type" data-category></span>
          ${item.favorite ? `<span class="favorite-mark" aria-label="\u5DF2\u6536\u85CF">\u2605</span>` : ""}
          ${thumb}
        </div>
        ${IS_SIDEPANEL && !bulkEditMode ? `
          <div class="sidepanel-card-actions">
            <button type="button" data-side-action="insert">\u63D2\u5165</button>
            <button type="button" data-side-action="copy">\u590D\u5236</button>
            <button type="button" data-side-action="view">\u67E5\u770B</button>
            <button type="button" data-side-action="edit">\u7F16\u8F91</button>
          </div>
        ` : ""}
      </div>
    `;
    if (bulkEditMode) {
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "bulk-select";
      checkbox.checked = bulkSelectedIds.has(item.id);
      checkbox.setAttribute("aria-label", `选择 ${item.title || "Prompt"}`);
      checkbox.addEventListener("click", (event) => {
        event.stopPropagation();
        if (checkbox.checked) bulkSelectedIds.add(item.id);
        else bulkSelectedIds.delete(item.id);
        renderList();
      });
      card.prepend(checkbox);
    }
    const cardTitle = String(item.title || "").trim();
    card.querySelector("h2").textContent = !cardTitle || cardTitle === "\u672A\u547D\u540D Prompt" ? "\u672A\u547D\u540D" : cardTitle;
    card.querySelector("[data-category]").textContent = categoryShortLabel(item.type);
    const metaValues = [
      [card.querySelector("[data-project]"), item.project],
      [card.querySelector("[data-scene]"), item.scene],
      [card.querySelector("[data-genre]"), item.genre]
    ];
    for (const [element, value] of metaValues) {
      const text = String(value || "").trim();
      if (text) {
        element.textContent = text;
      } else {
        element.remove();
      }
    }
    card.querySelector(".excerpt").textContent = composePrompt(item);
    card.addEventListener("click", async (event) => {
      if (bulkEditMode) {
        if (bulkSelectedIds.has(item.id)) bulkSelectedIds.delete(item.id);
        else bulkSelectedIds.add(item.id);
        renderList();
        return;
      }
      if (event.target.closest("[data-side-action]")) return;
      if (IS_SIDEPANEL) return;
      if (editorMode !== "view") await persistCurrentForm();
      selectedId = item.id;
      editorMode = "view";
      if (IS_SIDEPANEL) sidepanelPreviewOpen = true;
      render();
    });
    if (!bulkEditMode && (els.sortMode?.value || "updated") === "custom") {
      card.draggable = true;
      card.addEventListener("dragstart", (event) => {
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/prompt-vault-id", item.id);
      });
      card.addEventListener("dragover", (event) => {
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
        card.classList.add("is-drag-target");
      });
      card.addEventListener("dragleave", () => card.classList.remove("is-drag-target"));
      card.addEventListener("drop", async (event) => {
        event.preventDefault();
        card.classList.remove("is-drag-target");
        await reorderPromptById(event.dataTransfer.getData("text/prompt-vault-id"), item.id);
      });
    }
    if (IS_SIDEPANEL && !bulkEditMode) {
      card.querySelector('[data-side-action="insert"]').addEventListener("click", () => insertFromSidepanel(item));
      card.querySelector('[data-side-action="copy"]').addEventListener("click", async () => {
        await navigator.clipboard.writeText(composePrompt(item));
        updateSyncStatus("\u5DF2\u590D\u5236 Prompt");
      });
      card.querySelector('[data-side-action="view"]').addEventListener("click", () => {
        selectedId = item.id;
        editorMode = "view";
        sidepanelPreviewOpen = true;
        render();
      });
      card.querySelector('[data-side-action="edit"]').addEventListener("click", () => {
        selectedId = item.id;
        editorMode = "edit";
        sidepanelPreviewOpen = true;
        render();
      });
    }
    els.list.append(card);
    if (card.classList.contains("has-image")) {
      const meta = card.querySelector(".meta");
      requestAnimationFrame(() => {
        if (!card.isConnected || !meta) return;
        const lineHeight = Number.parseFloat(getComputedStyle(meta).lineHeight) || 12;
        const metaRows = Math.max(1, Math.round(meta.getBoundingClientRect().height / lineHeight));
        card.style.setProperty("--image-excerpt-lines", metaRows > 1 ? "2" : "3");
      });
    }
  }
}

function fillEditor(item) {
  isHydrating = true;
  if (!item) {
    els.form.reset();
    els.preview.removeAttribute("src");
    currentReferences = [];
    renderReferenceGallery();
    isHydrating = false;
    return;
  }
  els.title.value = item.title || "";
  els.project.value = item.project || "";
  els.scene.value = item.scene || "";
  els.genre.value = item.genre || "";
  els.category.value = normalizeCategory(item.type);
  if (els.model) els.model.value = item.model || "";
  els.prompt.value = item.prompt || "";
  els.promptEn.value = item.promptEn || "";
  els.negative.value = item.negative || "";
  els.tags.value = (item.tags || []).join(", ");
  els.imageUrl.value = item.image || "";
  els.sourceUrl.value = item.sourceUrl || "";
  if (item.image) els.preview.src = item.image;
  else els.preview.removeAttribute("src");
  currentReferences = [...(item.references || [])];
  renderReferenceGallery();
  isHydrating = false;
}

function renderPreview(item) {
  const hasItem = Boolean(item);
  els.previewPanel.hidden = !hasItem || editorMode !== "view";
  els.form.hidden = editorMode === "view";
  els.editorModeLabel.textContent = editorMode === "create" ? "\u65B0\u5EFA Prompt" : "\u7F16\u8F91 Prompt";
  els.cancelEdit.hidden = editorMode === "create" && !prompts.length;
  if (!hasItem) return;
  els.previewCategory.textContent = categoryShortLabel(item.type) || "Prompt";
  els.previewCategory.title = "\u70B9\u51FB\u8C03\u6574\u7C7B\u522B";
  els.previewTitle.textContent = item.title || "\u672A\u547D\u540D Prompt";
  els.toggleFavorite.textContent = item.favorite ? "\u5DF2\u6536\u85CF" : "\u6536\u85CF";
  els.toggleFavorite.classList.toggle("is-active", Boolean(item.favorite));
  els.previewMeta.innerHTML = "";
  const editableMeta = [
    ["project", item.project],
    ["scene", item.scene],
    ["genre", item.genre],
    ["model", item.model]
  ];
  for (const [field, rawValue] of editableMeta) {
    const value = String(rawValue || "").trim();
    if (!value) continue;
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip preview-meta-chip";
    chip.textContent = value;
    chip.addEventListener("click", (event) => {
      event.stopPropagation();
      showPreviewTaxonomyMenu(field, chip);
    });
    els.previewMeta.append(chip);
  }
  for (const rawValue of item.tags || []) {
    const value = String(rawValue || "").trim();
    if (!value) continue;
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = value;
    els.previewMeta.append(chip);
  }
  els.previewPromptLabel.textContent = "\u4E2D\u6587 PROMPT";
  els.previewPromptEnLabel.textContent = "English Prompt";
  els.previewNegativeLabel.textContent = "\u7981\u6B62";
  const previewFields = [
    [els.previewPromptSection, els.previewPrompt, item.prompt],
    [els.previewPromptEnSection, els.previewPromptEn, item.promptEn],
    [els.previewNegativeSection, els.previewNegative, item.negative]
  ];
  const firstVisibleIndex = previewFields.findIndex(([, , value]) => String(value || "").trim());
  const previewBackground = hasPromptImage(item.image) ? item.image : "";
  for (const [index, [section, content, value]] of previewFields.entries()) {
    const text = String(value || "").trim();
    section.hidden = !text;
    section.classList.toggle("is-primary", Boolean(text) && index === firstVisibleIndex);
    section.classList.toggle("is-secondary", Boolean(text) && index !== firstVisibleIndex);
    const hasBackground = Boolean(text) && index === firstVisibleIndex && Boolean(previewBackground);
    section.classList.toggle("has-preview-background", hasBackground);
    if (hasBackground) section.style.setProperty("--preview-background-image", `url(${JSON.stringify(previewBackground)})`);
    else section.style.removeProperty("--preview-background-image");
    section.querySelector(".inline-preview-editor")?.remove();
    section.querySelector(".inline-edit-trigger")?.removeAttribute("hidden");
    content.hidden = false;
    content.textContent = text;
  }

  const appendPreviewImage = (container, image) => {
    const img = document.createElement("img");
    img.src = image;
    img.alt = "";
    img.tabIndex = 0;
    img.setAttribute("role", "button");
    img.setAttribute("aria-label", "放大查看图片");
    img.addEventListener("click", () => openImageLightbox(image));
    img.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") openImageLightbox(image);
    });
    container.append(img);
  };
  els.previewImages.innerHTML = "";
  const resultImage = hasPromptImage(item.image) ? item.image : "";
  els.previewPanel.classList.toggle("has-preview-images", Boolean(resultImage));
  if (resultImage) appendPreviewImage(els.previewImages, resultImage);
  els.previewReferences.innerHTML = "";
  for (const reference of (item.references || []).filter(hasPromptImage)) {
    appendPreviewImage(els.previewReferences, reference);
  }
}

function openImageLightbox(src) {
  if (!hasPromptImage(src)) return;
  let lightbox = document.getElementById("imageLightbox");
  if (!lightbox) {
    lightbox = document.createElement("div");
    lightbox.id = "imageLightbox";
    lightbox.className = "image-lightbox";
    lightbox.hidden = true;

    const image = document.createElement("img");
    image.alt = "";
    const close = document.createElement("button");
    close.type = "button";
    close.className = "image-lightbox-close";
    close.setAttribute("aria-label", "关闭大图");
    close.textContent = "×";
    const closeLightbox = () => {
      lightbox.hidden = true;
      image.removeAttribute("src");
    };
    close.addEventListener("click", closeLightbox);
    lightbox.addEventListener("click", (event) => {
      if (event.target === lightbox) closeLightbox();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !lightbox.hidden) closeLightbox();
    });
    lightbox.append(image, close);
    document.body.append(lightbox);
  }
  lightbox.querySelector("img").src = src;
  lightbox.hidden = false;
  lightbox.querySelector("button").focus();
}

function render() {
  if (selectedId && !prompts.some((item) => item.id === selectedId)) selectedId = null;
  if (!selectedId) selectedId = prompts[0]?.id || null;
  const item = selectedPrompt();
  renderCategoryOptions(item?.type);
  renderModelOptions(item?.model);
  renderTaxonomy();
  renderList();
  fillEditor(item);
  renderPreview(item);
  if (IS_SIDEPANEL) {
    document.body.classList.toggle("sidepanel-overlay-open", sidepanelPreviewOpen || editorMode !== "view");
  }
}

function startInlinePreviewEdit(field) {
  const item = selectedPrompt();
  const fieldMap = {
    prompt: [els.previewPromptSection, els.previewPrompt],
    promptEn: [els.previewPromptEnSection, els.previewPromptEn],
    negative: [els.previewNegativeSection, els.previewNegative]
  };
  const [section, content] = fieldMap[field] || [];
  if (!item || !section || section.querySelector(".inline-preview-editor")) return;
  const trigger = section.querySelector(".inline-edit-trigger");
  const editor = document.createElement("div");
  editor.className = "inline-preview-editor";
  const textarea = document.createElement("textarea");
  textarea.value = String(item[field] || "");
  textarea.setAttribute("aria-label", trigger?.getAttribute("aria-label") || "\u7F16\u8F91 Prompt");
  const actions = document.createElement("div");
  actions.className = "inline-preview-actions";
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.textContent = "\u53D6\u6D88";
  const save = document.createElement("button");
  save.type = "button";
  save.textContent = "\u4FDD\u5B58";
  actions.append(cancel, save);
  editor.append(textarea, actions);
  content.hidden = true;
  trigger?.setAttribute("hidden", "");
  section.append(editor);
  textarea.focus();

  cancel.addEventListener("click", () => renderPreview(item));
  save.addEventListener("click", async () => {
    const nextValue = textarea.value.trim();
    if (nextValue === String(item[field] || "").trim()) {
      renderPreview(item);
      return;
    }
    const previous = { prompt: item.prompt || "", promptEn: item.promptEn || "", negative: item.negative || "" };
    item[field] = nextValue;
    item.updatedAt = now();
    item.versions = [{ ...previous, savedAt: now() }, ...(item.versions || [])].slice(0, 20);
    await saveAll();
    updateSyncStatus("\u5DF2\u4FDD\u5B58");
    render();
  });
}

function clearFilters() {
  activeCategory = "all";
  favoriteOnly = false;
  els.search.value = "";
  clearTopFilters();
}

function clearTopFilters() {
  els.projectFilter.value = "all";
  els.sceneFilter.value = "all";
  els.genreFilter.value = "all";
  els.tagFilter.value = "all";
  renderTaxonomy();
}

function revealItem(item) {
  if (!item || matches(item)) return;
  clearFilters();
}

function formValue() {
  const current = selectedPrompt();
  return {
    title: els.title.value.trim() || "\u672A\u547D\u540D Prompt",
    project: els.project.value.trim(),
    scene: els.scene.value.trim(),
    genre: els.genre.value.trim(),
    type: els.category.value,
    model: els.model ? els.model.value : (current?.model || ""),
    prompt: els.prompt.value.trim(),
    promptEn: els.promptEn.value.trim(),
    negative: els.negative.value.trim(),
    favorite: Boolean(current?.favorite),
    tags: normalizeTags(els.tags.value),
    rating: Number(current?.rating) || 0,
    image: els.imageUrl.value.trim(),
    references: [...currentReferences],
    sourceUrl: els.sourceUrl.value.trim()
  };
}


function promptDataChanged(previous, data) {
  const keys = ["title", "project", "scene", "genre", "type", "model", "prompt", "promptEn", "negative", "tags", "rating", "image", "references", "sourceUrl"];
  return keys.some((key) => JSON.stringify(previous?.[key] ?? (Array.isArray(data[key]) ? [] : "")) !== JSON.stringify(data[key]));
}

async function saveDraft() {
  if (isHydrating || !selectedId) return;
  await chrome.storage.local.set({
    [DRAFT_KEY]: {
      selectedId,
      savedAt: now(),
      data: formValue()
    }
  });
}

async function persistCurrentForm({ withVersion = false, redraw = false } = {}) {
  const current = selectedPrompt();
  if (!current) return;
  const data = formValue();
  const previous = { ...current };
  if (!promptDataChanged(previous, data)) {
    await chrome.storage.local.remove(DRAFT_KEY);
    return;
  }
  Object.assign(current, data, { updatedAt: now() });
  if (withVersion && (previous.prompt !== data.prompt || previous.promptEn !== data.promptEn || previous.negative !== data.negative)) {
    current.versions = [{ prompt: previous.prompt, promptEn: previous.promptEn || "", negative: previous.negative, savedAt: now() }, ...(current.versions || [])].slice(0, 20);
  }
  await saveAll();
  await chrome.storage.local.remove(DRAFT_KEY);
  updateSyncStatus(withVersion ? "\u5DF2\u4FDD\u5B58" : "\u5DF2\u81EA\u52A8\u4FDD\u5B58");
  if (redraw) {
    render();
  }
}

function scheduleAutoSave() {
  if (isHydrating || !selectedId) return;
  saveDraft();
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(() => {
    persistCurrentForm({ redraw: true });
  }, 450);
}

function normalizeUrl(value) {
  const url = value.trim();
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  return `https://${url}`;
}

async function extensionVersion() {
  return chrome.runtime.getManifest().version || "";
}

function loadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.addEventListener("load", () => {
      URL.revokeObjectURL(url);
      resolve(image);
    });
    image.addEventListener("error", () => {
      URL.revokeObjectURL(url);
      reject(new Error("\u56FE\u7247\u52A0\u8F7D\u5931\u8D25"));
    });
    image.src = url;
  });
}

async function compressImageFile(file) {
  const image = await loadImageFromFile(file);
  const scale = Math.min(1, IMAGE_MAX_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * scale));
  const height = Math.max(1, Math.round(image.naturalHeight * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(image, 0, 0, width, height);

  const webp = canvas.toDataURL("image/webp", IMAGE_QUALITY);
  if (webp.startsWith("data:image/webp")) return webp;
  return canvas.toDataURL("image/jpeg", IMAGE_QUALITY);
}

async function getActiveTabUrl() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0]?.url || "";
}

function currentExportScope(mode) {
  return {
    mode,
    category: activeCategory,
    search: els.search.value.trim(),
    project: els.projectFilter.value,
    scene: els.sceneFilter.value,
    genre: els.genreFilter.value,
    tag: els.tagFilter.value
  };
}

function portableSettings() {
  const {
    backupFolderName: _localBackupFolder,
    sharedSyncFolderName: _localSharedSyncFolder,
    sharedSyncEnabled: _localSharedSyncEnabled,
    lastSharedSyncAt: _localSharedSyncTime,
    ...portable
  } = settings;
  return portable;
}

function exportLibrary(items = prompts, scope = currentExportScope("all")) {
  const payload = {
    app: "Prompt Vault",
    version: 6,
    owner: PRODUCT_OWNER,
    release: OFFICIAL_RELEASE,
    installId,
    provenance: {
      exportedBy: "Prompt Vault",
      studio: PRODUCT_OWNER.studio,
      creator: PRODUCT_OWNER.creator,
      releaseId: OFFICIAL_RELEASE.releaseId,
      officialSite: OFFICIAL_RELEASE.officialSite,
      notice: "This export contains creator attribution, official release metadata, and anonymous install provenance for anti-rebranding and source tracing."
    },
    exportScope: scope,
    count: items.length,
    exportedAt: new Date().toISOString(),
    categories: categoryList(),
    settings: { ...portableSettings(), categories: categoryList() },
    prompts: items.map(sanitizePrompt)
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  const suffix = scope.mode === "filtered" ? "filtered" : "all";
  link.download = `prompt-vault-${suffix}-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  updateSyncStatus(`\u5DF2\u5BFC\u51FA ${items.length} \u6761 Prompt`);
}

function exportFilteredLibrary() {
  const visible = prompts.filter(matches);
  exportLibrary(visible, currentExportScope("filtered"));
}

function buildAiImportInstruction() {
  const categories = categoryList().map((item) => ({ id: item.id, label: item.label, short: item.short, icon: item.icon }));
  return `\u4F60\u662F Prompt Vault \u8D44\u6599\u6574\u7406\u52A9\u624B\u3002\u8BF7\u628A\u6211\u63D0\u4F9B\u7684\u6587\u4EF6\u3001\u7F51\u9875\u3001\u804A\u5929\u8BB0\u5F55\u6216\u7EAF\u6587\u672C\uFF0C\u6574\u7406\u6210\u53EF\u76F4\u63A5\u5BFC\u5165 Prompt Vault \u7684 JSON\u3002

\u6574\u7406\u89C4\u5219\uFF1A
1. \u53EA\u63D0\u53D6\u771F\u6B63\u53EF\u590D\u7528\u7684\u63D0\u793A\u8BCD\uFF0C\u4E0D\u8981\u628A\u5E7F\u544A\u3001\u76EE\u5F55\u6216\u666E\u901A\u8BF4\u660E\u5F53\u6210\u63D0\u793A\u8BCD\u3002
2. \u4F18\u5148\u6CBF\u7528\u7D20\u6750\u4E2D\u7684\u7C7B\u522B\uFF1B\u65E0\u6CD5\u786E\u5B9A\u65F6\u4F7F\u7528 uncategorized\uFF08\u65E0\u7C7B\u522B\uFF09\u3002
3. \u9AD8\u5EA6\u91CD\u590D\u7684\u5185\u5BB9\u53EA\u4FDD\u7559\u66F4\u5B8C\u6574\u3001\u66F4\u901A\u7528\u7684\u4E00\u6761\u3002
4. \u4FDD\u7559\u53D8\u91CF\u3001\u5360\u4F4D\u7B26\u3001\u6362\u884C\u3001\u4E2D\u82F1\u6587\u548C\u8D1F\u9762\u63D0\u793A\u8BCD\u3002
5. favorite \u53EA\u5728\u7D20\u6750\u660E\u786E\u6807\u8BB0\u6536\u85CF\u65F6\u8BBE\u4E3A true\u3002
6. \u4E0D\u8981\u7F16\u9020\u56FE\u7247\u6570\u636E\uFF1Bimage \u548C references \u6CA1\u6709\u65F6\u4F7F\u7528\u7A7A\u503C\u3002
7. \u5148\u8BF4\u660E\u63D0\u53D6\u4E86\u591A\u5C11\u4E2A\u7C7B\u522B\u548C\u591A\u5C11\u6761 Prompt\uFF0C\u5E76\u7ED9\u51FA JSON \u9884\u89C8\uFF1B\u7B49\u6211\u786E\u8BA4\u540E\uFF0C\u6700\u7EC8\u7B54\u6848\u53EA\u8F93\u51FA\u4E00\u4E2A\u53EF\u89E3\u6790\u7684 JSON \u5BF9\u8C61\u3002

\u5F53\u524D\u7C7B\u522B\uFF1A
${JSON.stringify(categories, null, 2)}

\u8F93\u51FA\u683C\u5F0F\uFF1A
{
  "app": "Prompt Vault",
  "version": 6,
  "categories": [{ "id": "\u552F\u4E00\u5B57\u7B26\u4E32", "label": "\u7C7B\u522B\u540D", "short": "\u7B80\u79F0" }],
  "settings": { "categories": [] },
  "prompts": [{
    "id": "UUID",
    "title": "\u63D0\u793A\u8BCD\u540D\u79F0",
    "project": "",
    "scene": "",
    "genre": "",
    "type": "\u5BF9\u5E94\u7C7B\u522B id\uFF0C\u4E0D\u786E\u5B9A\u65F6\u4E3A uncategorized",
    "prompt": "\u4E2D\u6587\u6216\u4E3B\u63D0\u793A\u8BCD",
    "promptEn": "\u82F1\u6587\u63D0\u793A\u8BCD\uFF0C\u6CA1\u6709\u5219\u7559\u7A7A",
    "negative": "\u8D1F\u9762\u63D0\u793A\u8BCD\uFF0C\u6CA1\u6709\u5219\u7559\u7A7A",
    "favorite": false,
    "tags": ["\u6807\u7B7E"],
    "image": "",
    "references": [],
    "sourceUrl": "",
    "order": 0
  }]
}

\u4E0D\u8981\u8986\u76D6\u6211\u672C\u5730\u5DF2\u6709\u6570\u636E\uFF1BPrompt Vault \u5BFC\u5165\u65F6\u4F1A\u8FDB\u884C\u9884\u89C8\u548C\u51B2\u7A81\u5904\u7406\u3002`;
}

async function importLibrary(file) {
  const text = await file.text();
  const payload = JSON.parse(text);
  const incoming = Array.isArray(payload) ? payload : payload.prompts;
  if (!Array.isArray(incoming)) throw new Error("\u8FD9\u4E0D\u662F Prompt Vault \u53EF\u8BC6\u522B\u7684 JSON");

  const importedCategoryValue = Array.isArray(payload)
    ? []
    : payload.categories || payload.settings?.categories || [];
  const mergedCategories = mergeImportedCategories(importedCategoryValue);
  pendingImportCategories = mergedCategories.categories;
  pendingImportCategoryConflicts = mergedCategories.conflicts;
  pendingImport = incoming.map((item, index) => analyzeImportItem(item, index, mergedCategories.typeMap));
  pendingImportSettings = !Array.isArray(payload) && (payload.settings || payload.categories)
    ? { ...(payload.settings || {}), categories: payload.categories || payload.settings?.categories }
    : null;
  renderImportPreview();
  updateSyncStatus(`\u5DF2\u8BFB\u53D6 ${pendingImport.length} \u6761\u5F85\u5BFC\u5165 Prompt`);
}

function renderImportPreview() {
  els.importList.innerHTML = "";
  els.importPanel.hidden = pendingImport.length === 0;
  const counts = { new: 0, duplicate: 0, conflict: 0, invalid: 0 };
  pendingImport.forEach((entry) => { counts[entry.status] += 1; });
  const categoryConflictText = pendingImportCategoryConflicts
    ? `\uff0c\u7c7b\u522b\u51b2\u7a81 ${pendingImportCategoryConflicts}`
    : "";
  els.importSummary.textContent = `\u65b0\u589e ${counts.new}\uff0c\u91cd\u590d ${counts.duplicate}\uff0c\u51b2\u7a81 ${counts.conflict}\uff0c\u5f02\u5e38 ${counts.invalid}${categoryConflictText}`;
  els.bulkConflictAction.value = "";
  els.bulkConflictAction.disabled = counts.conflict === 0;

  for (const entry of pendingImport) {
    const row = document.createElement("label");
    row.className = `import-row is-${entry.status}`;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = entry.status === "new" || entry.status === "conflict";
    checkbox.disabled = entry.status === "duplicate" || entry.status === "invalid";
    checkbox.dataset.key = entry.key;

    const body = document.createElement("span");
    body.className = "import-row-body";

    const title = document.createElement("strong");
    title.textContent = entry.item?.title || "\u65e0\u6548\u6761\u76ee";

    const meta = document.createElement("span");
    meta.className = "import-row-meta";
    meta.textContent = entry.item
      ? [categoryShortLabel(entry.item.type), entry.item.project, entry.item.scene, entry.item.genre, ...(entry.item.tags || [])]
        .filter(Boolean)
        .join(" / ")
      : entry.reason;

    const status = document.createElement("span");
    status.className = `import-status is-${entry.status}`;
    status.textContent = ({ new: "\u65b0\u589e", duplicate: "\u5b8c\u5168\u76f8\u540c", conflict: "\u5185\u5bb9\u51b2\u7a81", invalid: "\u683c\u5f0f\u5f02\u5e38" })[entry.status];

    body.append(title, meta, status);
    if (entry.status === "conflict") {
      const action = document.createElement("select");
      action.className = "import-conflict-action";
      action.innerHTML = `
        <option value="keep-local">\u4fdd\u7559\u672c\u5730\u7248\u672c</option>
        <option value="overwrite">\u7528\u5bfc\u5165\u7248\u672c\u8986\u76d6</option>
        <option value="keep-both">\u4e24\u4e2a\u90fd\u4fdd\u7559</option>
      `;
      action.value = entry.action;
      action.addEventListener("change", () => { entry.action = action.value; });
      body.append(action);
    }
    row.append(checkbox, body);
    els.importList.append(row);
  }
}

function selectedImportItems() {
  const selected = new Set(
    [...els.importList.querySelectorAll("input[type='checkbox']:checked")].map((input) => input.dataset.key)
  );
  return pendingImport.filter((entry) => selected.has(entry.key));
}

async function activeWebTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs.find((tab) => /^https?:|^file:/.test(tab.url || "")) || tabs[0] || null;
}

async function openSidepanelFromPopup() {
  const tab = await activeWebTab();
  if (!tab?.id) {
    updateSyncStatus("\u672A\u627E\u5230\u5F53\u524D\u7F51\u9875");
    return;
  }
  const result = await chrome.runtime.sendMessage({ type: "prompt-vault-open-sidepanel", tabId: tab.id });
  if (!result?.ok) {
    updateSyncStatus(result?.error || "\u4FA7\u8FB9\u680F\u6253\u5F00\u5931\u8D25");
    return;
  }
  window.close();
}

async function insertFromSidepanel(item) {
  const tab = await activeWebTab();
  if (!tab?.id) {
    updateSyncStatus("\u8BF7\u5148\u6253\u5F00\u9700\u8981\u63D2\u5165\u7684\u7F51\u9875");
    return;
  }
  try {
    const result = await chrome.tabs.sendMessage(tab.id, {
      type: "prompt-vault-insert",
      text: composePrompt(item),
      promptId: item.id
    });
    updateSyncStatus(result?.ok ? "\u5DF2\u63D2\u5165 Prompt" : "\u8BF7\u5148\u70B9\u51FB\u7F51\u9875\u8F93\u5165\u6846");
  } catch {
    updateSyncStatus("\u5F53\u524D\u9875\u9762\u6682\u4E0D\u652F\u6301\u63D2\u5165");
  }
}

async function confirmImportSelected() {
  const selectedEntries = selectedImportItems();
  if (!selectedEntries.length) {
    updateSyncStatus("\u8FD8\u6CA1\u6709\u9009\u62E9\u8981\u5BFC\u5165\u7684 Prompt");
    return;
  }

  const byId = new Map(prompts.map((item) => [item.id, item]));
  const revivedIds = new Set();
  let importedCount = 0;
  for (const entry of selectedEntries) {
    if (!entry.item || entry.status === "duplicate" || entry.status === "invalid") continue;
    if (entry.status === "new") {
      byId.set(entry.item.id, { ...entry.item, updatedAt: now() });
      revivedIds.add(entry.item.id);
      importedCount += 1;
      continue;
    }
    if (entry.action === "overwrite") {
      byId.set(entry.item.id, { ...entry.item, updatedAt: now() });
      revivedIds.add(entry.item.id);
      importedCount += 1;
    } else if (entry.action === "keep-both") {
      const copy = { ...entry.item, id: uid(), updatedAt: now() };
      byId.set(copy.id, copy);
      importedCount += 1;
    }
  }
  prompts = normalizePromptOrders(Array.from(byId.values()).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)));
  selectedId = selectedEntries.find((entry) => entry.item)?.item?.id || prompts[0]?.id || null;
  pendingImport = [];
  els.importPanel.hidden = true;
  if (pendingImportSettings) {
    const { categories: _importedCategoryValue, backupFolderName: _importedBackupFolder, ...importedSettings } = pendingImportSettings;
    settings = { ...settings, ...importedSettings };
  }
  if (pendingImportCategories.length) settings.categories = pendingImportCategories;
  if (revivedIds.size) {
    const tombstones = syncTombstones(settings.syncPromptTombstones);
    revivedIds.forEach((id) => { delete tombstones[id]; });
    settings.syncPromptTombstones = tombstones;
  }
  await saveSettings();
  await saveAll();
  pendingImportSettings = null;
  pendingImportCategories = [];
  pendingImportCategoryConflicts = 0;
  clearFilters();
  render();
  updateSyncStatus(`\u5DF2\u5BFC\u5165 ${importedCount} \u6761 Prompt`);
}

async function renameField(field, select, input) {
  await persistCurrentForm();
  const oldValue = select.value;
  const newValue = input.value.trim();
  if (!oldValue || !newValue || oldValue === newValue) return;
  prompts = prompts.map((item) => (item[field] === oldValue ? { ...item, [field]: newValue, updatedAt: now() } : item));
  input.value = "";
  await saveAll();
  render();
}

async function renameTaxonomyValue(field, oldValue, newValue) {
  if (!oldValue || oldValue === "all" || !newValue || oldValue === newValue) return;
  await persistCurrentForm();
  if (field === "tags") {
    prompts = prompts.map((item) => ({
      ...item,
      tags: (item.tags || []).map((tag) => (tag === oldValue ? newValue : tag)),
      updatedAt: (item.tags || []).includes(oldValue) ? now() : item.updatedAt
    }));
  } else if (field === "scene") {
    const project = els.projectFilter.value === "all" ? "" : els.projectFilter.value;
    prompts = prompts.map((item) => {
      const projectMatches = !project || item.project === project;
      return projectMatches && item.scene === oldValue ? { ...item, scene: newValue, updatedAt: now() } : item;
    });
  } else {
    prompts = prompts.map((item) => (item[field] === oldValue ? { ...item, [field]: newValue, updatedAt: now() } : item));
  }
  await saveAll();
  renderTaxonomy();
  if (field === "project") els.projectFilter.value = newValue;
  if (field === "scene") els.sceneFilter.value = newValue;
  if (field === "genre") els.genreFilter.value = newValue;
  if (field === "tags") els.tagFilter.value = newValue;
  renderList();
  updateSyncStatus(`\u5DF2\u91CD\u547D\u540D\uFF1A${oldValue} \u2192 ${newValue}`);
}

function bindRenameOnContext(select, field, label) {
  select.addEventListener("contextmenu", async (event) => {
    event.preventDefault();
    const oldValue = select.value;
    if (!oldValue || oldValue === "all") {
      updateSyncStatus(`\u8BF7\u5148\u9009\u4E2D\u8981\u91CD\u547D\u540D\u7684${label}`);
      return;
    }
    const next = prompt(`\u91CD\u547D\u540D${label}`, oldValue);
    if (!next) return;
    await renameTaxonomyValue(field, oldValue, next.trim());
  });
}

els.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearTimeout(autoSaveTimer);
  await persistCurrentForm({ withVersion: true });
  editorMode = "view";
  if (IS_SIDEPANEL) sidepanelPreviewOpen = false;
  render();
});

async function createPrompt() {
  clearTimeout(autoSaveTimer);
  await persistCurrentForm();
  await chrome.storage.local.remove(DRAFT_KEY);
  const selectedCategory = activeCategory !== "all" && categoryList().some((item) => item.id === activeCategory)
    ? activeCategory
    : UNCATEGORIZED_CATEGORY.id;
  const item = draftPrompt({ type: selectedCategory, sourceUrl: await getActiveTabUrl(), order: nextPromptOrder() });
  prompts.unshift(item);
  selectedId = item.id;
  editorMode = "create";
  clearFilters();
  await saveAll();
  render();
  els.title.focus();
  els.title.select();
}

function renderCategoryOptions(selectedValue = els.category?.value) {
  if (!els.category) return;
  const current = categoryList().some((item) => item.id === selectedValue) ? selectedValue : defaultCategoryId();
  els.category.innerHTML = "";
  for (const category of categoryList()) {
    const option = document.createElement("option");
    option.value = category.id;
    option.textContent = category.label;
    els.category.append(option);
  }
  const addOption = document.createElement("option");
  addOption.value = "__add_category__";
  addOption.textContent = "\uFF0B \u6DFB\u52A0\u7C7B\u522B";
  els.category.append(addOption);
  els.category.value = current;
}

function modelList() {
  const source = [...DEFAULT_MODELS, ...prompts.map((item) => item.model)];
  return [...new Set(source.map((value) => String(value || "").trim()).filter(Boolean))];
}

function renderModelOptions(selectedValue = els.model?.value) {
  if (!els.model) return;
  const current = String(selectedValue || "");
  const models = [...new Set([...modelList(), current.trim()].filter(Boolean))];
  renderTaxonomyDropdown(els.modelDropdown, models, addModel);
  els.model.value = current;
}

function requestCategoryMigration(removedWithPrompts, nextCategories) {
  return new Promise((resolve) => {
    const removedText = removedWithPrompts.map((item) => `${item.label}\uFF08${item.count} \u6761\uFF09`).join("\u3001");
    els.categoryMigrationMessage.textContent = `删除的类别里还有 Prompt：${removedText}。请选择迁移到哪个类别。`;
    els.categoryMigrationSelect.innerHTML = "";
    for (const category of nextCategories) {
      const option = document.createElement("option");
      option.value = category.id;
      option.textContent = category.label;
      els.categoryMigrationSelect.append(option);
    }
    const closeHandler = () => {
      els.categoryMigrationDialog.removeEventListener("close", closeHandler);
      resolve(els.categoryMigrationDialog.returnValue === "confirm" ? els.categoryMigrationSelect.value : "");
    };
    els.categoryMigrationDialog.addEventListener("close", closeHandler);
    els.categoryMigrationDialog.showModal();
  });
}


if (els.newPrompt) {
  els.newPrompt.addEventListener("click", () => createPrompt());
}

if (IS_SIDEPANEL) {
  const dataMenuLabel = document.querySelector("#dataMenu > summary");
  if (dataMenuLabel) dataMenuLabel.textContent = "\u5BFC\u5165/\u5BFC\u51FA";
  if (els.resetFilters) els.resetFilters.textContent = "\u6E05\u7406\u7B5B\u9009";
}

if (els.themeMenuButton && els.themeMenu) {
  els.themeMenuButton.addEventListener("click", (event) => {
    event.stopPropagation();
    els.themeMenu.hidden = !els.themeMenu.hidden;
    els.themeMenuButton.setAttribute("aria-expanded", String(!els.themeMenu.hidden));
  });
  els.themeMenu.addEventListener("click", (event) => event.stopPropagation());
  for (const option of els.themeOptions) {
    option.addEventListener("click", async () => {
      settings.themeMode = option.dataset.themeValue === "dark" ? "dark" : "light";
      applyTheme(settings.themeMode);
      els.themeMenu.hidden = true;
      els.themeMenuButton.setAttribute("aria-expanded", "false");
      await saveSettings();
    });
  }
}

if (els.openSidepanel) {
  if (IS_SIDEPANEL) els.openSidepanel.hidden = true;
  else els.openSidepanel.addEventListener("click", openSidepanelFromPopup);
}

if (els.closeSidepanelPreview) {
  els.closeSidepanelPreview.addEventListener("click", () => {
    sidepanelPreviewOpen = false;
    editorMode = "view";
    render();
  });
}

els.category.addEventListener("change", async (event) => {
  if (els.category.value !== "__add_category__") return;
  event.stopPropagation();
  const fallback = selectedPrompt()?.type || defaultCategoryId();
  els.category.value = fallback;
  const category = await addCategoryFromSidebar({ activate: false, selectInEditor: true });
  if (!category) els.category.value = fallback;
  scheduleAutoSave();
});

if (els.model) {
  els.model.addEventListener("change", () => {
    els.model.value = els.model.value.trim();
    renderModelOptions(els.model.value);
    scheduleAutoSave();
  });
}

els.previewCategory.addEventListener("click", (event) => {
  event.stopPropagation();
  renderPreviewCategoryMenu();
  els.previewCategoryMenu.hidden = !els.previewCategoryMenu.hidden;
});

for (const trigger of document.querySelectorAll("[data-inline-edit]")) {
  trigger.addEventListener("click", () => startInlinePreviewEdit(trigger.dataset.inlineEdit));
}

document.addEventListener("click", (event) => {
  if (!event.target.closest(".category-context-menu")) closeCategoryContextMenu();
  if (!event.target.closest(".preview-category-picker")) hidePreviewCategoryMenu();
  if (!event.target.closest(".preview-taxonomy-menu") && !event.target.closest(".preview-meta-chip")) hidePreviewTaxonomyMenu();
  if (!event.target.closest(".theme-control") && els.themeMenu) {
    els.themeMenu.hidden = true;
    els.themeMenuButton?.setAttribute("aria-expanded", "false");
  }
});

els.editPrompt.addEventListener("click", () => {
  if (!selectedPrompt()) return;
  editorMode = "edit";
  if (IS_SIDEPANEL) sidepanelPreviewOpen = true;
  render();
  els.prompt.focus();
});

els.cancelEdit.addEventListener("click", async () => {
  clearTimeout(autoSaveTimer);
  if (editorMode === "create") {
    const title = els.title.value.trim();
    const hasTitle = Boolean(title && title !== "未命名 Prompt");
    const hasPrompt = Boolean(els.prompt.value.trim() || els.promptEn.value.trim() || els.negative.value.trim());
    if (hasTitle || hasPrompt) {
      await persistCurrentForm({ withVersion: true });
    } else {
      prompts = prompts.filter((item) => item.id !== selectedId);
      selectedId = prompts[0]?.id || null;
      await saveAll();
    }
  }
  await chrome.storage.local.remove(DRAFT_KEY);
  editorMode = "view";
  if (IS_SIDEPANEL) sidepanelPreviewOpen = false;
  render();
});

if (IS_SIDEPANEL) {
  window.addEventListener("pagehide", () => {
    if (editorMode !== "create") return;
    clearTimeout(autoSaveTimer);
    const title = els.title.value.trim();
    const hasTitle = Boolean(title && title !== "未命名 Prompt");
    const hasPrompt = Boolean(els.prompt.value.trim() || els.promptEn.value.trim() || els.negative.value.trim());
    if (hasTitle || hasPrompt) {
      persistCurrentForm({ withVersion: true });
      return;
    }
    prompts = prompts.filter((item) => item.id !== selectedId);
    chrome.storage.local.set({ [LOCAL_KEY]: prompts });
    chrome.storage.local.remove(DRAFT_KEY);
  });
}

els.toggleFavorite.addEventListener("click", async () => {
  const item = selectedPrompt();
  if (!item) return;
  item.favorite = !item.favorite;
  item.updatedAt = now();
  await saveAll();
  render();
});

els.copyPrompt.addEventListener("click", async () => {
  await persistCurrentForm();
  const item = selectedPrompt();
  if (item) await navigator.clipboard.writeText(composePrompt(editorMode === "view" ? item : { ...item, ...formValue() }));
});

els.previewCopyPrompt.addEventListener("click", async () => {
  const item = selectedPrompt();
  if (item) await navigator.clipboard.writeText(composePrompt(item));
});

async function duplicateSelectedPrompt() {
  await persistCurrentForm();
  const item = selectedPrompt();
  if (!item) return;
  const source = editorMode === "view" ? item : { ...item, ...formValue() };
  const copy = draftPrompt({ ...source, id: uid(), title: `${source.title || "\u672A\u547D\u540D Prompt"} \u526F\u672C`, favorite: false, order: nextPromptOrder(), createdAt: now(), updatedAt: now() });
  prompts.unshift(copy);
  selectedId = copy.id;
  editorMode = "edit";
  await saveAll();
  render();
  els.title.focus();
}

els.duplicatePrompt.addEventListener("click", duplicateSelectedPrompt);

els.previewDuplicatePrompt.addEventListener("click", duplicateSelectedPrompt);

els.deletePrompt.addEventListener("click", async () => {
  if (!selectedId) return;
  bulkSelectedIds.clear();
  bulkSelectedIds.add(selectedId);
  await commitBulkMutation({ remove: true, label: "删除" });
});

els.previewDeletePrompt.addEventListener("click", () => els.deletePrompt.click());
els.previewUndoPrompt.addEventListener("click", undoBulkMutation);
els.previewRedoPrompt.addEventListener("click", redoBulkMutation);
els.editorUndoPrompt?.addEventListener("click", undoBulkMutation);
els.editorRedoPrompt?.addEventListener("click", redoBulkMutation);

els.exportPrompts.addEventListener("click", () => {
  exportLibrary();
  els.dataMenu.open = false;
});
els.exportFilteredPrompts.addEventListener("click", () => {
  exportFilteredLibrary();
  els.dataMenu.open = false;
});
els.importPrompts.addEventListener("click", () => {
  els.dataMenu.open = false;
  els.importFile.click();
});
els.setupBackup.addEventListener("click", async () => {
  els.dataMenu.open = false;
  try {
    await chooseBackupDirectory();
  } catch (error) {
    if (error?.name !== "AbortError") updateSyncStatus(error.message || "\u5907\u4EFD\u6587\u4EF6\u5939\u8BBE\u7F6E\u5931\u8D25");
  }
});
async function runManualBackup(button) {
  button.disabled = true;
  els.dataMenu.open = false;
  try {
    await performManualBackup();
  } catch (error) {
    if (error?.name !== "AbortError") {
      updateSyncStatus(error.message || "\u624B\u52A8\u5907\u4EFD\u5931\u8D25");
      if (els.backupHistoryDialog.open) els.backupFolderStatus.textContent = error.message || "\u624B\u52A8\u5907\u4EFD\u5931\u8D25";
    }
  } finally {
    button.disabled = false;
  }
}
els.manualBackup.addEventListener("click", () => runManualBackup(els.manualBackup));
els.manualBackupFromHistory.addEventListener("click", () => runManualBackup(els.manualBackupFromHistory));
els.downloadLatestBackup.addEventListener("click", async () => {
  els.downloadLatestBackup.disabled = true;
  try {
    await downloadLatestInternalBackup();
  } catch (error) {
    els.backupFolderStatus.textContent = error.message || "\u5907\u4EFD\u4E0B\u8F7D\u5931\u8D25";
  } finally {
    els.downloadLatestBackup.disabled = false;
  }
});
els.enableSharedSync.addEventListener("click", async () => {
  els.dataMenu.open = false;
  els.enableSharedSync.disabled = true;
  try {
    await enableSharedSync();
    updateSharedSyncStatus();
  } catch (error) {
    if (error?.name !== "AbortError") updateSharedSyncStatus(error.message || "\u5171\u4EAB\u540C\u6B65\u542F\u7528\u5931\u8D25");
  } finally {
    els.enableSharedSync.disabled = false;
  }
});
els.syncNow.addEventListener("click", async () => {
  els.dataMenu.open = false;
  els.syncNow.disabled = true;
  try {
    if (!settings.sharedSyncEnabled || !sharedSyncDirectoryHandleCache) {
      await enableSharedSync();
    } else {
      const permission = await sharedSyncDirectoryHandleCache.requestPermission({ mode: "readwrite" });
      if (permission !== "granted") throw new Error("\u672A\u83B7\u5F97\u5171\u4EAB\u540C\u6B65\u6587\u4EF6\u5939\u6743\u9650");
      await syncSharedFolder();
    }
    updateSharedSyncStatus();
  } catch (error) {
    if (error?.name !== "AbortError") updateSharedSyncStatus(error.message || "\u540C\u6B65\u5931\u8D25");
  } finally {
    els.syncNow.disabled = false;
  }
});
els.disableSharedSync.addEventListener("click", async () => {
  settings.sharedSyncEnabled = false;
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  updateSharedSyncStatus();
  els.dataMenu.open = false;
});
els.backupHistory.addEventListener("click", async () => {
  els.dataMenu.open = false;
  els.backupHistoryDialog.showModal();
  try {
    await renderBackupHistory();
  } catch (error) {
    els.backupFolderStatus.textContent = error.message || "\u5907\u4EFD\u5386\u53F2\u8BFB\u53D6\u5931\u8D25";
  }
});
els.closeBackupHistory.addEventListener("click", () => els.backupHistoryDialog.close());
els.reauthorizeBackup.addEventListener("click", async () => {
  els.reauthorizeBackup.disabled = true;
  try {
    const handle = backupDirectoryHandleCache || await getBackupDirectoryHandle();
    if (!handle) throw new Error("\u5907\u4EFD\u6587\u4EF6\u5939\u53E5\u67C4\u5DF2\u4E22\u5931\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u6587\u4EF6\u5939");
    const permission = await handle.requestPermission({ mode: "readwrite" });
    if (permission !== "granted") throw new Error("\u672A\u83B7\u5F97\u5907\u4EFD\u6587\u4EF6\u5939\u6743\u9650");
    settings.backupFolderName = handle.name;
    await saveSettings();
    await writeBackupSnapshot({ reason: "reauthorized", force: true });
    await renderBackupHistory();
    updateSyncStatus("\u5907\u4EFD\u6587\u4EF6\u5939\u5DF2\u91CD\u65B0\u6388\u6743\u5E76\u9A8C\u8BC1\u5199\u5165");
  } catch (error) {
    els.backupFolderStatus.textContent = error.message || "\u91CD\u65B0\u6388\u6743\u5931\u8D25";
  } finally {
    els.reauthorizeBackup.disabled = false;
  }
});
els.reselectBackup.addEventListener("click", async () => {
  els.reselectBackup.disabled = true;
  try {
    await chooseBackupDirectory();
    await renderBackupHistory();
  } catch (error) {
    if (error?.name !== "AbortError") els.backupFolderStatus.textContent = error.message || "\u5907\u4EFD\u6587\u4EF6\u5939\u8BBE\u7F6E\u5931\u8D25";
  } finally {
    els.reselectBackup.disabled = false;
  }
});
els.aiImportGuide.addEventListener("click", () => {
  els.dataMenu.open = false;
  els.aiImportInstruction.value = buildAiImportInstruction();
  els.aiImportDialog.showModal();
});
els.closeAiImportGuide.addEventListener("click", () => els.aiImportDialog.close());
els.copyAiImportGuide.addEventListener("click", async () => {
  await navigator.clipboard.writeText(els.aiImportInstruction.value);
  updateSyncStatus("\u5DF2\u590D\u5236 AI \u6574\u7406\u6307\u4EE4");
});
els.importFile.addEventListener("change", async () => {
  const file = els.importFile.files?.[0];
  if (!file) return;
  try {
    await importLibrary(file);
  } catch (error) {
    updateSyncStatus(error.message);
  } finally {
    els.importFile.value = "";
  }
});

els.refreshLibrary.addEventListener("click", async () => {
  await loadAll();
  render();
});

els.selectAllImport.addEventListener("click", () => {
  els.importList.querySelectorAll("input[type='checkbox']:not(:disabled)").forEach((input) => {
    input.checked = true;
  });
});

els.invertImport.addEventListener("click", () => {
  els.importList.querySelectorAll("input[type='checkbox']:not(:disabled)").forEach((input) => {
    input.checked = !input.checked;
  });
});

els.bulkConflictAction.addEventListener("change", () => {
  const action = els.bulkConflictAction.value;
  if (!action) return;
  pendingImport.forEach((entry) => {
    if (entry.status === "conflict") entry.action = action;
  });
  els.importList.querySelectorAll(".import-conflict-action").forEach((select) => {
    select.value = action;
  });
});

els.clearAllPrompts.addEventListener("click", async () => {
  if (!prompts.length) {
    updateSyncStatus("\u5F53\u524D\u5DF2\u6CA1\u6709 Prompt");
    return;
  }
  if (!confirm(`\u786E\u5B9A\u6E05\u7A7A\u5168\u90E8 ${prompts.length} \u6761 Prompt \u5417\uFF1F\u7C7B\u522B\u4F1A\u4FDD\u7559\uFF0C\u6E05\u7A7A\u524D\u4F1A\u81EA\u52A8\u521B\u5EFA\u5185\u90E8\u5907\u4EFD\u3002`)) return;
  els.clearAllPrompts.disabled = true;
  try {
    await writeBackupSnapshot({ reason: "before-clear-all", force: true });
    const deletedAt = now();
    const tombstones = syncTombstones(settings.syncPromptTombstones);
    prompts.forEach((item) => { tombstones[item.id] = deletedAt; });
    settings.syncPromptTombstones = tombstones;
    prompts = [];
    selectedId = null;
    await saveSettings();
    await saveAll();
    pendingImport = pendingImport.map((entry, index) => entry.item
      ? analyzeImportItem(entry.item, index, new Map())
      : entry);
    clearFilters();
    render();
    renderImportPreview();
    updateSyncStatus("\u5DF2\u6E05\u7A7A\u5168\u90E8 Prompt\uFF0C\u7C7B\u522B\u5DF2\u4FDD\u7559");
  } catch (error) {
    updateSyncStatus(error.message || "\u6E05\u7A7A Prompt \u5931\u8D25");
  } finally {
    els.clearAllPrompts.disabled = false;
  }
});

els.confirmImport.addEventListener("click", confirmImportSelected);

els.cancelImport.addEventListener("click", () => {
  pendingImport = [];
  pendingImportSettings = null;
  pendingImportCategories = [];
  pendingImportCategoryConflicts = 0;
  els.importPanel.hidden = true;
  els.importList.innerHTML = "";
  updateSyncStatus("\u5DF2\u53D6\u6D88\u5BFC\u5165");
});

els.openSource.addEventListener("click", async () => {
  await persistCurrentForm();
  const url = normalizeUrl(els.sourceUrl.value);
  if (url) await chrome.tabs.create({ url });
});

els.officialSite.addEventListener("click", async () => {
  await chrome.tabs.create({ url: "https://zaiye.art/prompt-vault.html" });
});

function orderedPromptSites() {
  const byName = new Map(PROMPT_SITES.map((site) => [site.name, site]));
  const saved = Array.isArray(settings.promptSiteOrder) ? settings.promptSiteOrder : [];
  return [...saved, ...PROMPT_SITES.map((site) => site.name)]
    .filter((name, index, names) => byName.has(name) && names.indexOf(name) === index)
    .map((name) => byName.get(name));
}

function renderPromptSites() {
  if (!els.promptSiteList) return;
  els.promptSiteList.innerHTML = "";
  let draggedName = "";
  for (const site of orderedPromptSites()) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = site.name;
    button.draggable = true;
    const showDescription = () => {
      els.promptSiteDescription.textContent = site.description;
      els.promptSiteDescription.classList.add("is-visible");
      requestAnimationFrame(() => {
        const menuHeight = els.promptSiteMenu.clientHeight;
        const descriptionHeight = els.promptSiteDescription.offsetHeight;
        const buttonCenter = button.offsetTop - els.promptSiteList.scrollTop + (button.offsetHeight / 2);
        const top = Math.max(6, Math.min(buttonCenter - (descriptionHeight / 2), menuHeight - descriptionHeight - 6));
        els.promptSiteDescription.style.top = `${top}px`;
      });
    };
    button.addEventListener("mouseenter", () => {
      showDescription();
    });
    button.addEventListener("mouseleave", () => els.promptSiteDescription.classList.remove("is-visible"));
    button.addEventListener("focus", () => {
      showDescription();
    });
    button.addEventListener("blur", () => els.promptSiteDescription.classList.remove("is-visible"));
    button.addEventListener("click", async () => {
      await chrome.tabs.create({ url: site.url });
    });
    button.addEventListener("dragstart", () => {
      draggedName = site.name;
    });
    button.addEventListener("dragover", (event) => event.preventDefault());
    button.addEventListener("drop", async (event) => {
      event.preventDefault();
      if (!draggedName || draggedName === site.name) return;
      const order = orderedPromptSites().map((item) => item.name);
      const from = order.indexOf(draggedName);
      const to = order.indexOf(site.name);
      const [dragged] = order.splice(from, 1);
      order.splice(to, 0, dragged);
      settings.promptSiteOrder = order;
      await saveSettings();
      renderPromptSites();
    });
    els.promptSiteList.append(button);
  }
}

els.promptSite.addEventListener("click", (event) => {
  event.stopPropagation();
  renderPromptSites();
  els.promptSiteMenu.hidden = !els.promptSiteMenu.hidden;
  if (els.promptSiteMenu.hidden) els.promptSiteDescription.classList.remove("is-visible");
});

document.addEventListener("click", (event) => {
  if (!event.target.closest(".data-menu")) els.dataMenu.open = false;
});

els.promptSiteMenu.addEventListener("click", (event) => event.stopPropagation());
document.addEventListener("click", () => {
  els.promptSiteMenu.hidden = true;
  els.promptSiteDescription.classList.remove("is-visible");
});

bindRenameOnContext(els.projectFilter, "project", "\u9879\u76EE");
bindRenameOnContext(els.sceneFilter, "scene", "\u573A\u666F");
bindRenameOnContext(els.genreFilter, "genre", "\u7C7B\u578B");
bindRenameOnContext(els.tagFilter, "tags", "\u6807\u7B7E");

els.search.addEventListener("input", renderList);
els.favoriteFilter.addEventListener("click", () => {
  favoriteOnly = !favoriteOnly;
  renderList();
});
els.resetFilters.addEventListener("click", () => {
  clearFilters();
  render();
});
els.projectFilter.addEventListener("change", () => {
  renderTaxonomy();
  renderList();
});
els.sceneFilter.addEventListener("change", renderList);
els.genreFilter.addEventListener("change", renderList);
els.tagFilter.addEventListener("change", renderList);
els.sortMode.addEventListener("change", async () => {
  settings.sortMode = els.sortMode.value;
  await saveSettings();
  renderList();
});
els.toggleBulkEdit.addEventListener("click", () => {
  bulkEditMode = !bulkEditMode;
  if (!bulkEditMode) bulkSelectedIds.clear();
  renderList();
});
els.selectAllBulk.addEventListener("click", () => {
  const visible = sortVisibleItems(prompts.filter(matches));
  const allSelected = visible.length > 0 && visible.every((item) => bulkSelectedIds.has(item.id));
  for (const item of visible) {
    if (allSelected) bulkSelectedIds.delete(item.id);
    else bulkSelectedIds.add(item.id);
  }
  renderList();
});
els.applyBulkEdit.addEventListener("click", async () => {
  const changes = {};
  if (els.bulkCategory.value) changes.type = normalizeCategory(els.bulkCategory.value);
  if (els.bulkProject.value.trim()) changes.project = els.bulkProject.value.trim();
  if (els.bulkScene.value.trim()) changes.scene = els.bulkScene.value.trim();
  if (!Object.keys(changes).length) {
    updateSyncStatus("请选择要批量修改的类别、项目或场景");
    return;
  }
  els.bulkCategory.value = "";
  els.bulkProject.value = "";
  els.bulkScene.value = "";
  await commitBulkMutation({ changes, label: "批量修改" });
});
els.bulkDelete.addEventListener("click", async () => {
  await commitBulkMutation({ remove: true, label: "批量删除" });
});
els.undoBulkEdit.addEventListener("click", undoBulkMutation);
els.redoBulkEdit.addEventListener("click", redoBulkMutation);
els.title.addEventListener("focus", () => {
  if (els.title.value === "未命名 Prompt") els.title.value = "";
});
els.form.addEventListener("input", scheduleAutoSave);
els.form.addEventListener("change", scheduleAutoSave);
els.project.addEventListener("input", () => {
  renderTaxonomy();
});
[
  [els.project, els.projectDropdown],
  [els.scene, els.sceneDropdown],
  [els.genre, els.genreDropdown],
  [els.tags, els.tagDropdown],
  [els.model, els.modelDropdown]
].forEach(([input, dropdown]) => {
  input.addEventListener("focus", () => showTaxonomyDropdown(dropdown));
  input.addEventListener("click", () => showTaxonomyDropdown(dropdown));
  input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") hideTaxonomyDropdowns();
  });
});
document.addEventListener("pointerdown", (event) => {
  if (!event.target.closest(".taxonomy-picker")) hideTaxonomyDropdowns();
});
els.imageUrl.addEventListener("input", () => {
  if (els.imageUrl.value.trim()) els.preview.src = els.imageUrl.value.trim();
  else els.preview.removeAttribute("src");
});
els.preview.addEventListener("click", () => {
  const src = els.preview.getAttribute("src") || "";
  if (src) openImageLightbox(src);
});

function setMediaStatus(message) {
  if (els.mediaStatus) els.mediaStatus.textContent = message || "";
}

function setImageFromUrl(url, message = "\u56FE\u7247\u5DF2\u6DFB\u52A0") {
  const value = (url || "").trim();
  if (!value) return false;
  els.imageUrl.value = value;
  els.preview.src = value;
  scheduleAutoSave();
  setMediaStatus(message);
  return true;
}

function clearImage() {
  els.imageUrl.value = "";
  els.preview.removeAttribute("src");
  if (els.imageFile) els.imageFile.value = "";
  setMediaStatus("\u793A\u4F8B\u56FE\u5DF2\u6E05\u9664");
  scheduleAutoSave();
}

function renderReferenceGallery() {
  if (!els.referenceGallery) return;
  els.referenceGallery.innerHTML = "";

  if (!currentReferences.length) {
    const empty = document.createElement("div");
    empty.className = "reference-empty";
    empty.textContent = "\u8FD8\u6CA1\u6709\u53C2\u8003\u56FE";
    els.referenceGallery.append(empty);
    return;
  }

  currentReferences.forEach((src, index) => {
    const item = document.createElement("div");
    item.className = "reference-item";

    const image = document.createElement("img");
    image.src = src;
    image.alt = "";
    image.tabIndex = 0;
    image.setAttribute("role", "button");
    image.setAttribute("aria-label", "放大查看图片");
    image.addEventListener("click", () => openImageLightbox(src));
    image.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") openImageLightbox(src);
    });

    const tools = document.createElement("div");
    tools.className = "reference-tools";

    const copy = document.createElement("button");
    copy.type = "button";
    copy.textContent = "\u590D\u5236";
    copy.addEventListener("click", () => copyReferenceImage(index));

    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "\u5220";
    remove.addEventListener("click", () => removeReferenceImage(index));

    tools.append(copy, remove);
    item.append(image, tools);
    els.referenceGallery.append(item);
  });
}

async function addReferenceImage(src, message = "\u53C2\u8003\u56FE\u5DF2\u6DFB\u52A0") {
  const value = String(src || "").trim();
  if (!value) return false;
  currentReferences.push(value);
  renderReferenceGallery();
  scheduleAutoSave();
  setMediaStatus(message);
  return true;
}

async function addReferenceFiles(files) {
  const images = [...(files || [])].filter((file) => file.type.startsWith("image/"));
  if (!images.length) return;
  for (const file of images) {
    currentReferences.push(await compressImageFile(file));
  }
  renderReferenceGallery();
  scheduleAutoSave();
  setMediaStatus(`\u5DF2\u6DFB\u52A0 ${images.length} \u5F20\u53C2\u8003\u56FE`);
}

function removeReferenceImage(index) {
  currentReferences.splice(index, 1);
  renderReferenceGallery();
  scheduleAutoSave();
  setMediaStatus("\u53C2\u8003\u56FE\u5DF2\u5220\u9664");
}

async function dataUrlToBlob(url) {
  const response = await fetch(url);
  return response.blob();
}

async function copyReferenceImage(index) {
  const src = currentReferences[index];
  if (!src) return;

  try {
    if (src.startsWith("data:image/") && navigator.clipboard?.write && window.ClipboardItem) {
      const blob = await dataUrlToBlob(src);
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      setMediaStatus("\u53C2\u8003\u56FE\u5DF2\u590D\u5236");
      return;
    }
    await navigator.clipboard.writeText(src);
    setMediaStatus("\u5DF2\u590D\u5236\u53C2\u8003\u56FE\u94FE\u63A5");
  } catch (error) {
    await navigator.clipboard.writeText(src);
    setMediaStatus("\u5DF2\u590D\u5236\u53C2\u8003\u56FE\u6570\u636E");
  }
}

async function pasteReferenceImageFromClipboard() {
  const previousLabel = els.pasteReferenceImage.textContent;
  els.pasteReferenceImage.disabled = true;
  els.pasteReferenceImage.textContent = "\u7C98\u8D34\u4E2D...";
  setMediaStatus("\u6B63\u5728\u8BFB\u53D6\u526A\u8D34\u677F\u53C2\u8003\u56FE...");

  try {
    if (navigator.clipboard?.read) {
      const items = await navigator.clipboard.read();
      for (const item of items) {
        const imageType = item.types.find((type) => type.startsWith("image/"));
        if (imageType) {
          const blob = await item.getType(imageType);
          const file = new File([blob], "reference-image", { type: imageType });
          await addReferenceFiles([file]);
          return;
        }

        if (item.types.includes("text/html")) {
          const html = await (await item.getType("text/html")).text();
          const url = imageUrlFromHtml(html);
          if (url && await addReferenceImage(url, "\u53C2\u8003\u56FE\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
        }

        if (item.types.includes("text/plain")) {
          const text = await (await item.getType("text/plain")).text();
          const url = imageUrlFromText(text);
          if (url && await addReferenceImage(url, "\u53C2\u8003\u56FE\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
        }
      }
    }

    if (navigator.clipboard?.readText) {
      const url = imageUrlFromText(await navigator.clipboard.readText());
      if (url && await addReferenceImage(url, "\u53C2\u8003\u56FE\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
    }

    setMediaStatus("\u526A\u8D34\u677F\u6CA1\u6709\u53EF\u8BC6\u522B\u56FE\u7247");
  } catch (error) {
    setMediaStatus("\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\u56FE\u7247");
  } finally {
    els.pasteReferenceImage.disabled = false;
    els.pasteReferenceImage.textContent = previousLabel;
  }
}

function shouldShowNegativeSuggestions() {
  return document.activeElement === els.negative && els.category.value !== "negative";
}

function updateNegativeSuggestionsVisibility() {
  if (!els.negativeSuggestions) return;
  els.negativeSuggestions.classList.toggle("is-open", shouldShowNegativeSuggestions());
}

els.negative.addEventListener("focus", updateNegativeSuggestionsVisibility);
els.negative.addEventListener("blur", () => {
  setTimeout(updateNegativeSuggestionsVisibility, 120);
});
els.category.addEventListener("change", updateNegativeSuggestionsVisibility);

async function setImageFromFile(file) {
  if (!file) return;
  try {
    const compressed = await compressImageFile(file);
    setImageFromUrl(compressed, "\u56FE\u7247\u5DF2\u6DFB\u52A0\u5E76\u538B\u7F29");
  } catch (error) {
    setMediaStatus(error.message || "\u56FE\u7247\u5904\u7406\u5931\u8D25");
    updateSyncStatus(error.message || "\u56FE\u7247\u5904\u7406\u5931\u8D25");
  }
}

async function handleClipboardImage(data, message = "\u56FE\u7247\u5DF2\u7C98\u8D34") {
  const file = imageFileFromClipboard(data);
  if (file) {
    await setImageFromFile(file);
    setMediaStatus(message);
    return true;
  }

  const url = imageUrlFromClipboard(data);
  return url ? setImageFromUrl(url, message) : false;
}

function imageUrlFromPasteCatcher() {
  if (!els.pasteCatcher) return "";
  const img = els.pasteCatcher.querySelector("img");
  return img?.src || "";
}

function pasteImageViaPasteCommand() {
  if (!els.pasteCatcher) return Promise.resolve(false);

  return new Promise((resolve) => {
    let finished = false;
    const finish = (success) => {
      if (finished) return;
      finished = true;
      document.removeEventListener("paste", onPaste, true);
      els.pasteCatcher.innerHTML = "";
      resolve(success);
    };
    const onPaste = async (event) => {
      event.preventDefault();
      const success = await handleClipboardImage(event.clipboardData, "\u56FE\u7247\u5DF2\u7C98\u8D34");
      if (success) finish(true);
    };

    document.addEventListener("paste", onPaste, true);
    els.pasteCatcher.innerHTML = "";
    els.pasteCatcher.focus();

    let commandWorked = false;
    try {
      commandWorked = document.execCommand("paste");
    } catch (error) {
      commandWorked = false;
    }

    setTimeout(() => {
      const url = imageUrlFromPasteCatcher();
      if (url && setImageFromUrl(url, "\u56FE\u7247\u5DF2\u7C98\u8D34")) {
        finish(true);
        return;
      }
      finish(false);
    }, commandWorked ? 160 : 20);
  });
}

async function pasteImageFromClipboard() {
  const previousLabel = els.pasteImage.textContent;
  els.pasteImage.disabled = true;
  els.pasteImage.textContent = "\u7C98\u8D34\u4E2D...";
  setMediaStatus("\u6B63\u5728\u8BFB\u53D6\u526A\u8D34\u677F\u56FE\u7247...");

  try {
    if (await pasteImageViaPasteCommand()) return;

    if (!navigator.clipboard?.read && !navigator.clipboard?.readText) {
      setMediaStatus("\u5F53\u524D\u6D4F\u89C8\u5668\u4E0D\u5141\u8BB8\u76F4\u63A5\u8BFB\u53D6\u526A\u8D34\u677F\u56FE\u7247\uFF0C\u53EF\u4EE5\u62D6\u56FE\u6216\u9009\u62E9\u6587\u4EF6");
      return;
    }

    if (navigator.clipboard?.read) {
      const items = await navigator.clipboard.read();
      for (const item of items) {
        const imageType = item.types.find((type) => type.startsWith("image/"));
        if (imageType) {
          const blob = await item.getType(imageType);
          await setImageFromFile(new File([blob], "clipboard-image", { type: imageType }));
          setMediaStatus("\u56FE\u7247\u5DF2\u7C98\u8D34\u5E76\u538B\u7F29");
          return;
        }

        if (item.types.includes("text/html")) {
          const html = await (await item.getType("text/html")).text();
          const url = imageUrlFromHtml(html);
          if (url && setImageFromUrl(url, "\u56FE\u7247\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
        }

        if (item.types.includes("text/plain")) {
          const text = await (await item.getType("text/plain")).text();
          const url = imageUrlFromText(text);
          if (url && setImageFromUrl(url, "\u56FE\u7247\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
        }
      }
    }

    if (navigator.clipboard?.readText) {
      const url = imageUrlFromText(await navigator.clipboard.readText());
      if (url && setImageFromUrl(url, "\u56FE\u7247\u5DF2\u4ECE\u94FE\u63A5\u6DFB\u52A0")) return;
    }

    setMediaStatus("\u526A\u8D34\u677F\u6CA1\u6709\u53EF\u8BC6\u522B\u56FE\u7247\uFF0C\u53EF\u4EE5\u62D6\u56FE\u6216\u9009\u62E9\u6587\u4EF6");
  } catch (error) {
    setMediaStatus("\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\u56FE\u7247");
    updateSyncStatus("\u65E0\u6CD5\u8BFB\u53D6\u526A\u8D34\u677F\u56FE\u7247");
  } finally {
    els.pasteImage.disabled = false;
    els.pasteImage.textContent = previousLabel;
  }
}

function imageFileFromClipboard(data) {
  const file = [...(data?.files || [])].find((item) => item.type.startsWith("image/"));
  if (file) return file;
  const item = [...(data?.items || [])].find((entry) => entry.type.startsWith("image/"));
  return item?.getAsFile() || null;
}

function imageUrlFromClipboard(data) {
  return imageUrlFromHtml(data?.getData("text/html") || "") || imageUrlFromText(data?.getData("text/plain") || "");
}

function imageUrlFromHtml(html) {
  if (!html) return "";
  const doc = new DOMParser().parseFromString(html, "text/html");
  return doc.querySelector("img")?.src || "";
}

function imageUrlFromText(text) {
  text = (text || "").trim();
  if (/^data:image\//i.test(text)) return text;
  return /^https?:\/\/.+\.(png|jpe?g|webp|gif|avif)(\?.*)?$/i.test(text) ? text : "";
}

els.imageFile.addEventListener("change", async () => {
  await setImageFromFile(els.imageFile.files?.[0]);
  els.imageFile.value = "";
});

els.pasteImage.addEventListener("click", pasteImageFromClipboard);
els.clearImage.addEventListener("click", clearImage);

els.referenceFiles.addEventListener("change", async () => {
  await addReferenceFiles(els.referenceFiles.files);
  els.referenceFiles.value = "";
});

els.pasteReferenceImage.addEventListener("click", pasteReferenceImageFromClipboard);

function bindReferenceDropTarget(target) {
  if (!target) return;
  target.addEventListener("dragover", (event) => {
    event.preventDefault();
    els.referenceField?.classList.add("is-dragging");
  });
  target.addEventListener("dragleave", (event) => {
    if (!els.referenceField?.contains(event.relatedTarget)) els.referenceField?.classList.remove("is-dragging");
  });
  target.addEventListener("drop", async (event) => {
    event.preventDefault();
    els.referenceField?.classList.remove("is-dragging");
    await addReferenceFiles(event.dataTransfer?.files);
  });
}

bindReferenceDropTarget(els.referenceField);
els.referenceDrop.addEventListener("dragover", (event) => {
  event.preventDefault();
  els.referenceDrop.classList.add("is-dragging");
});

els.referenceDrop.addEventListener("dragleave", () => {
  els.referenceDrop.classList.remove("is-dragging");
});

els.referenceDrop.addEventListener("drop", async (event) => {
  event.preventDefault();
  els.referenceDrop.classList.remove("is-dragging");
  await addReferenceFiles(event.dataTransfer?.files);
});

if (els.exampleField) {
  els.exampleField.addEventListener("dragover", (event) => {
    event.preventDefault();
    els.exampleField.classList.add("is-dragging");
  });
  els.exampleField.addEventListener("dragleave", (event) => {
    if (!els.exampleField.contains(event.relatedTarget)) els.exampleField.classList.remove("is-dragging");
  });
  els.exampleField.addEventListener("drop", async (event) => {
    event.preventDefault();
    els.exampleField.classList.remove("is-dragging");
    const file = [...(event.dataTransfer?.files || [])].find((item) => item.type.startsWith("image/"));
    if (file) await setImageFromFile(file);
  });
}

document.addEventListener("paste", async (event) => {
  const file = imageFileFromClipboard(event.clipboardData);
  if (file) {
    event.preventDefault();
    await setImageFromFile(file);
    return;
  }

  const url = imageUrlFromClipboard(event.clipboardData);
  if (url) {
    event.preventDefault();
    setImageFromUrl(url, "\u56FE\u7247\u5DF2\u7C98\u8D34");
  }
});

ensureInstallId()
  .then(loadAll)
  .then(async () => {
    await loadBulkUndoHistory();
    const [backupHandle] = await Promise.all([
      getBackupDirectoryHandle().catch(() => null),
      getBackupDirectoryHandle(SHARED_SYNC_HANDLE_KEY).catch(() => null)
    ]);
    if (backupHandle && !settings.backupFolderName) {
      settings.backupFolderName = backupHandle.name;
      await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
    }
    applyStoredColumnWidths();
    applyCategoryButtonHeight(settings.categoryButtonHeight);
    updateSharedSyncStatus();
    if (["updated", "usage", "custom"].includes(settings.sortMode)) els.sortMode.value = settings.sortMode;
  })
  .then(applyPendingOpen)
  .then(render)
  .then(() => {
    if (editorMode === "edit") els.prompt.focus();
    syncSharedFolder({ automatic: true }).catch((error) => updateSharedSyncStatus(error.message || "\u540C\u6B65\u5931\u8D25"));
  });

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "session" || !changes[BULK_UNDO_KEY]) return;
  if (bulkUndoSessionDirty) return;
  const history = changes[BULK_UNDO_KEY].newValue;
  bulkUndoStack = Array.isArray(history)
    ? history.slice(-BULK_UNDO_LIMIT)
    : Array.isArray(history?.undo) ? history.undo.slice(-BULK_UNDO_LIMIT) : [];
  bulkRedoStack = Array.isArray(history?.redo) ? history.redo.slice(-BULK_UNDO_LIMIT) : [];
  els.previewUndoPrompt.disabled = bulkUndoStack.length === 0;
  els.previewRedoPrompt.disabled = bulkRedoStack.length === 0;
  if (bulkEditMode) renderList();
});

setInterval(() => {
  syncSharedFolder({ automatic: true }).catch((error) => updateSharedSyncStatus(error.message || "\u540C\u6B65\u5931\u8D25"));
}, SHARED_SYNC_INTERVAL);
