const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const SYNC_META_KEY = "promptVaultSyncMeta";
const SYNC_CHUNK_PREFIX = "promptVaultChunk";
const FAB_POSITION_KEY = "promptVaultFabPosition";
const FAB_HIDDEN_DATE_KEY = "promptVaultFabHiddenDate";
const UNCATEGORIZED_CATEGORY = { id: "uncategorized", label: "\u65E0\u7C7B\u522B", short: "\u65E0\u7C7B\u522B" };
const DEFAULT_CATEGORIES = [
  { id: "scene", label: "场景", short: "场景" },
  { id: "character", label: "\u89D2\u8272\u8BBE\u8BA1", short: "\u89D2\u8272" },
  { id: "video", label: "\u89C6\u9891\u63A7\u5236", short: "\u89C6\u9891" },
  { id: "constraint", label: "\u7EA6\u675F\u6A21\u5757", short: "\u7EA6\u675F" },
  { id: "task", label: "\u4EFB\u52A1\u6307\u4EE4", short: "\u6307\u4EE4" },
  UNCATEGORIZED_CATEGORY
];
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "再野文化工作室",
  creator: "田田田野里"
};

let promptVaultTarget = null;
let promptVaultSelection = null;

function isTextTarget(element) {
  if (!element) return false;
  const tag = element.tagName?.toLowerCase();
  if (element.isContentEditable) return element.isConnected && !element.closest("[contenteditable='false']");
  if (tag === "textarea") return element.isConnected && !element.disabled && !element.readOnly;
  if (tag !== "input") return false;
  const blockedTypes = new Set(["button", "checkbox", "color", "file", "hidden", "image", "radio", "range", "reset", "submit"]);
  return element.isConnected && !element.disabled && !element.readOnly && !blockedTypes.has(element.type);
}

function isPromptComposeTarget(element) {
  if (!isTextTarget(element)) return false;
  if (element.isContentEditable || element.tagName?.toLowerCase() === "textarea") return true;
  const hint = [element.placeholder, element.getAttribute("aria-label"), element.name, element.id].filter(Boolean).join(" ");
  return /prompt|message|chat|ask|query|输入|提问|消息|描述/i.test(hint);
}

function isInsidePromptVault(element) {
  return Boolean(element?.closest?.(".prompt-vault-panel, .prompt-vault-fab, .prompt-vault-input-trigger"));
}

function getPromptVaultTodayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

async function isPromptVaultFabHiddenToday() {
  const today = getPromptVaultTodayKey();
  const data = await chrome.storage.local.get({ [FAB_HIDDEN_DATE_KEY]: "" });
  const hiddenDate = data[FAB_HIDDEN_DATE_KEY];
  if (hiddenDate && hiddenDate !== today) {
    await chrome.storage.local.remove(FAB_HIDDEN_DATE_KEY);
    return false;
  }
  return hiddenDate === today;
}

async function setPromptVaultFabHiddenToday(hidden) {
  if (hidden) {
    await chrome.storage.local.set({ [FAB_HIDDEN_DATE_KEY]: getPromptVaultTodayKey() });
    return;
  }
  await chrome.storage.local.remove(FAB_HIDDEN_DATE_KEY);
}

function rememberPromptVaultSelection(element = promptVaultTarget) {
  if (!isTextTarget(element) || isInsidePromptVault(element)) return;
  promptVaultTarget = element;

  if (element.isContentEditable) {
    const selection = document.getSelection();
    if (!selection?.rangeCount) return;
    const range = selection.getRangeAt(0);
    if (!element.contains(range.commonAncestorContainer)) return;
    promptVaultSelection = { target: element, range: range.cloneRange() };
    return;
  }

  promptVaultSelection = {
    target: element,
    start: element.selectionStart ?? element.value.length,
    end: element.selectionEnd ?? element.value.length
  };
}

document.addEventListener("focusin", (event) => {
  rememberPromptVaultSelection(event.target);
});

document.addEventListener("focusout", (event) => {
  rememberPromptVaultSelection(event.target);
}, true);

function insertText(target, text) {
  if (!target) return false;
  target.focus({ preventScroll: true });
  const saved = promptVaultSelection?.target === target ? promptVaultSelection : null;

  if (target.isContentEditable) {
    if (saved?.range) {
      const selection = document.getSelection();
      selection.removeAllRanges();
      selection.addRange(saved.range);
    }
    document.execCommand("insertText", false, text);
    target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    rememberPromptVaultSelection(target);
    return true;
  }

  const start = Math.min(saved?.start ?? target.selectionStart ?? target.value.length, target.value.length);
  const end = Math.min(saved?.end ?? target.selectionEnd ?? target.value.length, target.value.length);
  const next = start + text.length;
  if (typeof target.setRangeText === "function") {
    target.setSelectionRange(start, end);
    target.setRangeText(text, start, end, "end");
  } else {
    target.value = `${target.value.slice(0, start)}${text}${target.value.slice(end)}`;
    target.setSelectionRange(next, next);
  }
  target.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
  target.dispatchEvent(new Event("change", { bubbles: true }));
  rememberPromptVaultSelection(target);
  return true;
}

function currentTextTarget() {
  const active = document.activeElement;
  if (isTextTarget(active) && !isInsidePromptVault(active)) return active;
  if (isTextTarget(promptVaultTarget) && !isInsidePromptVault(promptVaultTarget)) return promptVaultTarget;
  return null;
}

document.addEventListener("selectionchange", () => {
  rememberPromptVaultSelection(document.activeElement);
});

["click", "keyup", "input", "select", "mouseup"].forEach((eventName) => {
  document.addEventListener(eventName, (event) => rememberPromptVaultSelection(event.target), true);
});

function composePrompt(item) {
  const parts = [];
  if (item.prompt?.trim()) parts.push(item.prompt.trim());
  if (item.promptEn?.trim()) parts.push(item.promptEn.trim());
  if (item.negative?.trim()) parts.push(`禁止：${item.negative.trim()}`);
  const text = parts.join("\n\n");
  const mjSuffix = "--ar 21:9 --v 7 --stylize 750";
  if (String(item.model || "").trim().toUpperCase() === "MJ" && text && !text.endsWith(mjSuffix)) {
    return `${text} ${mjSuffix}`;
  }
  return text;
}

function hasPromptImage(value) {
  const image = String(value || "").trim();
  return /^(data:image\/|blob:|https?:\/\/|file:\/\/)/i.test(image);
}

function normalizeCategories(value) {
  const source = Array.isArray(value) && value.length ? value : DEFAULT_CATEGORIES;
  const seen = new Set();
  const categories = [];
  for (const item of source) {
    const id = String(item?.id || "").trim();
    const label = String(item?.label || item?.short || "").trim();
    if (!id || !label || seen.has(id)) continue;
    seen.add(id);
    categories.push({ id, label, short: String(item?.short || label).trim(), icon: String(item?.icon || "").trim() });
  }
  const normalized = categories.filter((item) => item.id !== UNCATEGORIZED_CATEGORY.id);
  normalized.push({ ...UNCATEGORIZED_CATEGORY });
  return normalized.length ? normalized : DEFAULT_CATEGORIES;
}

function categoryLabel(id, categories) {
  const category = categories.find((item) => item.id === id);
  const fallback = categories[0] || DEFAULT_CATEGORIES[0];
  return category?.short || category?.label || fallback?.short || fallback?.label || "Prompt";
}

function defaultCategoryId(categories) {
  return categories[0]?.id || DEFAULT_CATEGORIES[0].id;
}

function matches(item, query) {
  const haystack = [item.title, item.project, item.scene, item.genre, item.type, item.prompt, item.promptEn, item.negative, ...(item.tags || [])].join(" ").toLowerCase();
  return haystack.includes(query.toLowerCase());
}

function sanitizePrompt(item, categories = DEFAULT_CATEGORIES) {
  return {
    ...item,
    id: item.id || crypto.randomUUID(),
    title: item.title || "\u672A\u547D\u540D Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || item.customType || "",
    type: categories.some((category) => category.id === item.type) ? item.type : UNCATEGORIZED_CATEGORY.id,
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    favorite: Boolean(item.favorite),
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    usageCount: Object.prototype.hasOwnProperty.call(item, "usageCount") ? Number(item.usageCount) || 0 : 0,
    lastUsedAt: Object.prototype.hasOwnProperty.call(item, "lastUsedAt") ? Number(item.lastUsedAt) || 0 : 0,
    order: Number.isFinite(Number(item.order)) ? Number(item.order) : Number.MAX_SAFE_INTEGER,
    createdAt: Number(item.createdAt) || Date.now(),
    updatedAt: Number(item.updatedAt) || Date.now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

async function getSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: { storageMode: "local" } });
  return { ...data[SETTINGS_KEY], categories: normalizeCategories(data[SETTINGS_KEY]?.categories) };
}

async function readSyncPrompts(categories) {
  const metaData = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const count = metaData[SYNC_META_KEY]?.count || 0;
  if (!count) return [];
  const keys = Array.from({ length: count }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  const chunks = await chrome.storage.sync.get(keys);
  const json = keys.map((key) => chunks[key] || "").join("");
  return json ? JSON.parse(json).map((item) => sanitizePrompt(item, categories)) : [];
}

async function getPrompts() {
  const settings = await getSettings();
  const categories = settings.categories;
  const data = await chrome.storage.local.get({ [LOCAL_KEY]: [] });
  const localPrompts = Array.isArray(data[LOCAL_KEY]) ? data[LOCAL_KEY].map((item) => sanitizePrompt(item, categories)) : [];
  if (localPrompts.length) return localPrompts;

  if (settings.storageMode === "sync") {
    const synced = await readSyncPrompts(categories);
    if (synced.length) return synced;
  }
  return [];
}

async function recordPromptUsage(id) {
  const data = await chrome.storage.local.get({ [LOCAL_KEY]: [] });
  if (!Array.isArray(data[LOCAL_KEY])) return;
  const index = data[LOCAL_KEY].findIndex((item) => item?.id === id);
  if (index < 0) return;
  const next = [...data[LOCAL_KEY]];
  const current = next[index];
  next[index] = {
    ...current,
    usageCount: (Number(current.usageCount) || 0) + 1,
    lastUsedAt: Date.now()
  };
  await chrome.storage.local.set({ [LOCAL_KEY]: next });
}

function buildPanel() {
  const fab = document.createElement("button");
  fab.className = "prompt-vault-fab";
  fab.type = "button";
  fab.title = "语藏 Prompt Vault";
  const fabIcon = document.createElement("img");
  fabIcon.src = chrome.runtime.getURL("assets/archive-spine.png");
  fabIcon.alt = "";
  fab.append(fabIcon);

  const inputTrigger = document.createElement("button");
  inputTrigger.className = "prompt-vault-input-trigger";
  inputTrigger.type = "button";
  inputTrigger.title = "打开 Prompt Vault";
  inputTrigger.setAttribute("aria-label", "打开 Prompt Vault");
  inputTrigger.hidden = true;
  const inputTriggerIcon = document.createElement("img");
  inputTriggerIcon.src = chrome.runtime.getURL("assets/archive-spine.png");
  inputTriggerIcon.alt = "";
  inputTrigger.append(inputTriggerIcon);

  const fabMenu = document.createElement("div");
  fabMenu.className = "prompt-vault-fab-menu";
  fabMenu.setAttribute("role", "menu");
  fabMenu.hidden = true;
  const fabMenuExpand = document.createElement("button");
  fabMenuExpand.type = "button";
  fabMenuExpand.textContent = "展开";
  const fabMenuHide = document.createElement("button");
  fabMenuHide.type = "button";
  fabMenuHide.textContent = "今天隐藏";
  const fabMenuCancel = document.createElement("button");
  fabMenuCancel.type = "button";
  fabMenuCancel.textContent = "取消";
  fabMenu.append(fabMenuExpand, fabMenuHide, fabMenuCancel);

  const panel = document.createElement("section");
  panel.className = "prompt-vault-panel";
  panel.innerHTML = `
    <div class="prompt-vault-header">
      <div class="prompt-vault-title">PROMPT VAULT</div>
      <button class="prompt-vault-refresh" type="button" title="\u5237\u65B0\u63D0\u793A\u8BCD">\u5237\u65B0</button>
      <button class="prompt-vault-sidepanel" type="button" title="\u6253\u5F00\u4FA7\u8FB9\u680F">\u4FA7</button>
      <button class="prompt-vault-close" type="button" title="\u5173\u95ED">&times;</button>
    </div>
    <div class="prompt-vault-search">
      <input type="search" placeholder="搜索 Prompt、标签、负面词" />
    </div>
    <div class="prompt-vault-filterbar">
      <button class="prompt-vault-favorite-filter" type="button" title="收藏" aria-label="只看收藏" aria-pressed="false">★</button>
      <select data-filter="project" aria-label="项目筛选"><option value="all">项目</option></select>
      <select data-filter="scene" aria-label="场景筛选"><option value="all">场景</option></select>
      <select data-filter="genre" aria-label="类型筛选"><option value="all">类型</option></select>
      <select data-filter="tag" aria-label="标签筛选"><option value="all">标签</option></select>
    </div>
    <div class="prompt-vault-shell">
      <div class="prompt-vault-tabs" role="tablist" aria-label="?????"></div>
    <div class="prompt-vault-list"></div>
    </div>
    <div class="prompt-vault-detail" hidden>
      <div class="prompt-vault-detail-card">
        <div class="prompt-vault-detail-head">
          <strong></strong>
          <button type="button" data-detail-close>&times;</button>
        </div>
        <pre></pre>
      </div>
    </div>
  `;

  document.documentElement.append(fab, panel, inputTrigger, fabMenu);

  async function applyFabVisibility() {
    const hiddenToday = await isPromptVaultFabHiddenToday();
    fab.hidden = hiddenToday;
    fab.setAttribute("aria-hidden", hiddenToday ? "true" : "false");
    if (hiddenToday) panel.dataset.open = "false";
  }

  fab.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();
    showFabMenu(event.clientX, event.clientY);
  });

  const input = panel.querySelector("input");
  const list = panel.querySelector(".prompt-vault-list");
  const refreshButton = panel.querySelector(".prompt-vault-refresh");
  const sidepanelButton = panel.querySelector(".prompt-vault-sidepanel");
  const closeButton = panel.querySelector(".prompt-vault-close");
  const detail = panel.querySelector(".prompt-vault-detail");
  const detailTitle = detail.querySelector("strong");
  const detailText = detail.querySelector("pre");
  const detailClose = detail.querySelector("[data-detail-close]");
  const filterSelects = {
    project: panel.querySelector('[data-filter="project"]'),
    scene: panel.querySelector('[data-filter="scene"]'),
    genre: panel.querySelector('[data-filter="genre"]'),
    tag: panel.querySelector('[data-filter="tag"]')
  };
  const favoriteFilterButton = panel.querySelector(".prompt-vault-favorite-filter");
  const categoryTabsContainer = panel.querySelector(".prompt-vault-tabs");
  let categoryTabs = [];
  let activeCategory = "all";
  let favoriteOnly = false;

  function renderCategoryTabs(categories) {
    if (activeCategory !== "all" && !categories.some((item) => item.id === activeCategory)) activeCategory = "all";
    categoryTabsContainer.innerHTML = "";
    const tabs = [
      { id: "all", label: "\u5168\u90E8" },
      ...categories.map((item) => ({ id: item.id, label: item.short || item.label }))
    ];
    for (const tab of tabs) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.category = tab.id;
      button.textContent = tab.label;
      if (tab.title) button.title = tab.title;
      button.setAttribute("aria-pressed", String(tab.id === "favorite" ? favoriteOnly : tab.id === activeCategory));
      button.addEventListener("click", () => {
        if (tab.id === "favorite") {
          favoriteOnly = !favoriteOnly;
          render();
          return;
        }
        activeCategory = tab.id;
        render();
      });
      categoryTabsContainer.append(button);
    }
    categoryTabs = [...categoryTabsContainer.querySelectorAll("[data-category]")];
  }
  let currentFabPosition = null;
  let inputTriggerTarget = null;
  let hideInputTriggerTimer = null;

  function hideFabMenu() {
    fabMenu.hidden = true;
  }

  function showFabMenu(x, y) {
    const width = 84;
    const height = 102;
    fabMenu.style.left = `${Math.round(Math.min(window.innerWidth - width - 8, Math.max(8, x)))}px`;
    fabMenu.style.top = `${Math.round(Math.min(window.innerHeight - height - 8, Math.max(8, y)))}px`;
    fabMenu.hidden = false;
  }

  function hideInputTrigger() {
    clearTimeout(hideInputTriggerTimer);
    inputTrigger.hidden = true;
    inputTriggerTarget = null;
  }

  function placeInputTrigger(target = inputTriggerTarget) {
    if (!isPromptComposeTarget(target) || !target.isConnected) {
      hideInputTrigger();
      return;
    }
    const rect = target.getBoundingClientRect();
    if (rect.width < 24 || rect.height < 20 || rect.bottom < 0 || rect.top > window.innerHeight) {
      hideInputTrigger();
      return;
    }
    const size = 28;
    const inset = 6;
    const outsideLeft = rect.left - size - inset;
    const below = rect.bottom + inset;
    const above = rect.top - size - inset;
    let left = outsideLeft;
    let top = rect.bottom - size;
    if (outsideLeft < inset && below <= window.innerHeight - size - inset) {
      left = rect.left;
      top = below;
    } else if (outsideLeft < inset && above >= inset) {
      left = rect.left;
      top = above;
    }
    inputTrigger.style.left = `${Math.round(left)}px`;
    inputTrigger.style.top = `${Math.round(top)}px`;
    inputTrigger.hidden = false;
  }

  function showInputTrigger(target) {
    clearTimeout(hideInputTriggerTimer);
    inputTriggerTarget = target;
    placeInputTrigger(target);
  }

  function scheduleInputTriggerHide() {
    clearTimeout(hideInputTriggerTimer);
    hideInputTriggerTimer = setTimeout(() => {
      const active = document.activeElement;
      if (active === inputTrigger || panel.contains(active)) return;
      if (!isPromptComposeTarget(active)) hideInputTrigger();
    }, 0);
  }

  const taxonomyCollator = new Intl.Collator("zh-Hans-u-co-pinyin", {
    numeric: true,
    sensitivity: "base"
  });

  function taxonomyRank(value) {
    const first = String(value || "").trim().charAt(0);
    if (/^[A-Za-z]$/.test(first)) return 0;
    if (/^[0-9]$/.test(first)) return 1;
    if (/[\u4e00-\u9fff]/.test(first)) return 2;
    return 3;
  }

  function compareTaxonomy(a, b) {
    return taxonomyRank(a) - taxonomyRank(b) || taxonomyCollator.compare(a, b);
  }

  function uniqueValues(values) {
    return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))].sort(compareTaxonomy);
  }

  function frequentValues(values, limit = 3) {
    const scores = new Map();
    values
      .map((value) => String(value || "").trim())
      .filter(Boolean)
      .forEach((value) => scores.set(value, (scores.get(value) || 0) + 1));

    return [...scores.entries()]
      .sort((a, b) => b[1] - a[1] || compareTaxonomy(a[0], b[0]))
      .slice(0, limit)
      .map(([value]) => value);
  }

  function rankedValues(values, commonValues = []) {
    const common = uniqueValues(commonValues).slice(0, 3);
    const rest = uniqueValues(values).filter((value) => !common.includes(value));
    return [...common, ...rest];
  }

  function replaceFilterOptions(select, firstLabel, values) {
    const current = select.value;
    select.innerHTML = "";
    const first = document.createElement("option");
    first.value = "all";
    first.textContent = firstLabel;
    select.append(first);
    for (const value of values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      select.append(option);
    }
    select.value = values.includes(current) ? current : "all";
  }

  function renderFilters(prompts) {
    const selectedProject = filterSelects.project.value === "all" ? "" : filterSelects.project.value;
    const projects = prompts.map((item) => item.project);
    const scenes = prompts.filter((item) => !selectedProject || item.project === selectedProject).map((item) => item.scene);
    replaceFilterOptions(filterSelects.project, "项目", rankedValues(projects, frequentValues(projects)));
    replaceFilterOptions(
      filterSelects.scene,
      "场景",
      rankedValues(scenes, frequentValues(scenes))
    );
    replaceFilterOptions(filterSelects.genre, "类型", uniqueValues(prompts.map((item) => item.genre)));
    replaceFilterOptions(filterSelects.tag, "标签", uniqueValues(prompts.flatMap((item) => item.tags || [])));
  }

  function clampPosition(position) {
    const size = 44;
    return {
      x: Math.min(Math.max(8, Number(position?.x) || window.innerWidth - 116), window.innerWidth - size - 8),
      y: Math.min(Math.max(8, Number(position?.y) || window.innerHeight - 62), window.innerHeight - size - 8)
    };
  }

  function snapFabToViewportEdge(position) {
    const size = 44;
    const inset = 8;
    const threshold = 24;
    const next = clampPosition(position);
    const right = window.innerWidth - size - inset;
    const leftDistance = next.x - inset;
    const rightDistance = right - next.x;

    if (Math.min(leftDistance, rightDistance) > threshold) return next;
    return { ...next, x: leftDistance <= rightDistance ? inset : right };
  }

  function avoidSiblingFloat(position) {
    const sibling = document.querySelector(".aak-fab");
    if (!sibling) return position;

    const siblingRect = sibling.getBoundingClientRect();
    const overlaps =
      position.x < siblingRect.right + 8 &&
      position.x + 44 > siblingRect.left - 8 &&
      position.y < siblingRect.bottom + 8 &&
      position.y + 44 > siblingRect.top - 8;

    if (!overlaps) return position;
    return clampPosition({ x: siblingRect.left - 56, y: position.y });
  }

  function placeFabAt(position) {
    fab.style.left = `${position.x}px`;
    fab.style.top = `${position.y}px`;
    fab.style.right = "auto";
    fab.style.bottom = "auto";
    const inset = 8;
    const right = window.innerWidth - 44 - inset;
    fab.dataset.docked = position.x === inset ? "left" : position.x === right ? "right" : "";
  }

  function getPanelSize() {
    const rect = panel.getBoundingClientRect();
    return {
      width: rect.width || Math.min(360, window.innerWidth - 28),
      height: rect.height || Math.min(590, window.innerHeight - 96)
    };
  }

  function clampPanelPosition(left, top) {
    const { width, height } = getPanelSize();
    return {
      left: Math.min(Math.max(8, left), window.innerWidth - width - 8),
      top: Math.min(Math.max(8, top), window.innerHeight - height - 8),
      width,
      height
    };
  }

  function placePanelAt(left, top, side = panel.dataset.side || "right") {
    const next = clampPanelPosition(left, top);
    panel.style.left = `${next.left}px`;
    panel.style.top = `${next.top}px`;
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    panel.dataset.side = side;
    return null;
  }

  function attachFabToPanel(side = panel.dataset.side || "right") {
    const rect = panel.getBoundingClientRect();
    const next = clampPosition({
      x: side === "right" ? rect.left - 22 : rect.right - 22,
      y: rect.bottom - 22
    });
    currentFabPosition = next;
    placeFabAt(next);
    return next;
  }

  function placeOpenPanelFromFab(fabPosition, side = panel.dataset.side || "right") {
    const { width, height } = getPanelSize();
    const left = side === "right" ? fabPosition.x + 22 : fabPosition.x - width + 22;
    const top = fabPosition.y - height + 22;
    return placePanelAt(left, top, side);
  }

  function placePanel(position) {
    const panelWidth = Math.min(360, window.innerWidth - 28);
    const panelHeight = Math.min(590, window.innerHeight - 96);
    const side = position.x > window.innerWidth / 2 ? "right" : "left";
    const left = side === "right"
      ? Math.max(8, Math.min(position.x - panelWidth + 44, window.innerWidth - panelWidth - 8))
      : Math.min(Math.max(8, position.x), window.innerWidth - panelWidth - 8);
    const top = position.y > window.innerHeight / 2
      ? Math.max(8, position.y - panelHeight - 10)
      : Math.min(window.innerHeight - panelHeight - 8, position.y + 54);
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    panel.dataset.side = side;
  }

  function placePanelNearInput(target, triggerRect) {
    const gap = 10;
    const targetRect = target.getBoundingClientRect();
    const aboveSpace = Math.max(0, targetRect.top - gap - 8);
    const belowSpace = Math.max(0, window.innerHeight - targetRect.bottom - gap - 8);
    const availableHeight = Math.max(aboveSpace, belowSpace);
    panel.style.maxHeight = `${Math.max(180, Math.min(590, availableHeight))}px`;
    const { width, height } = getPanelSize();
    const openAbove = aboveSpace >= belowSpace;
    const left = triggerRect.left;
    const top = openAbove ? targetRect.top - height - gap : targetRect.bottom + gap;
    return placePanelAt(left, top, left < window.innerWidth / 2 ? "left" : "right");
  }

  function placeFab(position) {
    const next = avoidSiblingFloat(clampPosition(position));
    currentFabPosition = next;
    placeFabAt(next);
    if (panel.dataset.open === "true") placePanel(next);
    return next;
  }

  async function restoreFabPosition() {
    const data = await chrome.storage.local.get({ [FAB_POSITION_KEY]: null });
    placeFab(data[FAB_POSITION_KEY]);
  }

  let dragState = null;
  let ignoreNextFabClick = false;
  function isBlockedDragTarget(target) {
    return Boolean(target.closest("button, input, select, textarea, a, [contenteditable='true'], .prompt-vault-detail-card"));
  }

  function shouldKeepPageFocus(target) {
    return Boolean(target.closest('[data-action="insert"], [data-action="insert-image"], [data-action="view"], [data-action="copy"]'));
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";
      textarea.style.top = "0";
      document.body.append(textarea);
      textarea.focus();
      textarea.select();
      const ok = document.execCommand("copy");
      textarea.remove();
      return ok;
    }
  }

  async function copyImageForPaste(src) {
    if (!src) return "";
    try {
      const response = await fetch(src);
      const blob = await response.blob();
      if (!blob.type.startsWith("image/") || !navigator.clipboard?.write || !window.ClipboardItem) throw new Error("Image clipboard is unavailable");
      await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
      return "image";
    } catch {
      return (await copyText(src)) ? "link" : "";
    }
  }

  function hideDetail() {
    detail.hidden = true;
  }

  function showDetail(item, anchor) {
    detailTitle.textContent = item.title || "\u672A\u547D\u540D Prompt";
    detailText.textContent = composePrompt(item);
    detail.hidden = false;
    const card = detail.querySelector(".prompt-vault-detail-card");
    const panelRect = panel.getBoundingClientRect();
    const anchorRect = anchor.getBoundingClientRect();
    const cardRect = card.getBoundingClientRect();
    const left = Math.min(
      Math.max(8, anchorRect.left - panelRect.left),
      Math.max(8, panelRect.width - cardRect.width - 8)
    );
    let top = anchorRect.top - panelRect.top - cardRect.height - 8;
    if (top < 8) top = anchorRect.bottom - panelRect.top + 8;
    top = Math.min(Math.max(8, top), Math.max(8, panelRect.height - cardRect.height - 8));
    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
  }

  fab.addEventListener("pointerdown", (event) => {
    const rect = fab.getBoundingClientRect();
    dragState = {
      kind: panel.dataset.open === "true" ? "open-fab" : "fab",
      startX: event.clientX,
      startY: event.clientY,
      left: rect.left,
      top: rect.top,
      side: panel.dataset.side || "right",
      moved: false
    };
    fab.setPointerCapture(event.pointerId);
  });

  function moveFab(event) {
    if (!dragState || !["fab", "open-fab"].includes(dragState.kind)) return;
    const dx = event.clientX - dragState.startX;
    const dy = event.clientY - dragState.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) dragState.moved = true;
    if (!dragState.moved) return;
    event.preventDefault();
    const proposedFab = { x: dragState.left + dx, y: dragState.top + dy };
    const next = placeFab(proposedFab);
    dragState.current = next;
  }

  async function finishFabDrag(event) {
    if (!dragState || !["fab", "open-fab"].includes(dragState.kind)) return;
    if (fab.hasPointerCapture?.(event.pointerId)) fab.releasePointerCapture(event.pointerId);
    if (dragState.current) {
      dragState.current = placeFab(snapFabToViewportEdge(dragState.current));
      await chrome.storage.local.set({ [FAB_POSITION_KEY]: dragState.current });
    }
    if (dragState.moved) ignoreNextFabClick = true;
    dragState = null;
  }

  function cancelFabDrag() {
    if (["fab", "open-fab"].includes(dragState?.kind)) dragState = null;
  }

  fab.addEventListener("pointermove", moveFab);
  fab.addEventListener("pointerup", finishFabDrag);
  fab.addEventListener("pointercancel", cancelFabDrag);
  document.addEventListener("pointermove", (event) => {
    if (!fab.contains(event.target)) moveFab(event);
  }, true);
  document.addEventListener("pointerup", (event) => {
    if (!fab.contains(event.target)) void finishFabDrag(event);
  }, true);
  document.addEventListener("pointercancel", (event) => {
    if (!fab.contains(event.target)) cancelFabDrag();
  }, true);

  panel.addEventListener("pointerdown", (event) => {
    if (!detail.hidden && !event.target.closest(".prompt-vault-detail-card")) {
      hideDetail();
      event.preventDefault();
      return;
    }
    if (shouldKeepPageFocus(event.target)) {
      rememberPromptVaultSelection(promptVaultTarget);
      event.preventDefault();
      return;
    }
    if (panel.dataset.open !== "true" || isBlockedDragTarget(event.target)) return;
    const rect = panel.getBoundingClientRect();
    dragState = {
      kind: "panel",
      startX: event.clientX,
      startY: event.clientY,
      left: rect.left,
      top: rect.top,
      side: panel.dataset.side || "right",
      moved: false
    };
    panel.setPointerCapture(event.pointerId);
  });

  panel.addEventListener("pointermove", (event) => {
    if (dragState?.kind !== "panel") return;
    const dx = event.clientX - dragState.startX;
    const dy = event.clientY - dragState.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) dragState.moved = true;
    if (!dragState.moved) return;
    event.preventDefault();
    placePanelAt(dragState.left + dx, dragState.top + dy, dragState.side);
    dragState.current = attachFabToPanel(dragState.side);
  });

  panel.addEventListener("pointerup", async (event) => {
    if (dragState?.kind !== "panel") return;
    panel.releasePointerCapture(event.pointerId);
    if (dragState.current) await chrome.storage.local.set({ [FAB_POSITION_KEY]: dragState.current });
    dragState = null;
  });

  panel.addEventListener("pointercancel", () => {
    if (dragState?.kind === "panel") dragState = null;
  });

  document.addEventListener("pointerdown", (event) => {
    if (detail.hidden) return;
    if (event.target.closest(".prompt-vault-detail-card")) return;
    hideDetail();
  }, true);

  async function render() {
    const settings = await getSettings();
    const theme = settings.themeMode === "dark" ? "dark" : "light";
    panel.dataset.theme = theme;
    fab.dataset.theme = theme;
    const categories = settings.categories;
    favoriteFilterButton.setAttribute("aria-pressed", String(favoriteOnly));
    renderCategoryTabs(categories);
    const prompts = await getPrompts();
    renderFilters(prompts);
    const query = input.value.trim();
    const project = filterSelects.project.value;
    const scene = filterSelects.scene.value;
    const genre = filterSelects.genre.value;
    const tag = filterSelects.tag.value;
    const visible = prompts.filter((item) => {
      return (
        (!query || matches(item, query)) &&
        (activeCategory === "all" || item.type === activeCategory) &&
        (!favoriteOnly || item.favorite) &&
        (project === "all" || (item.project || "") === project) &&
        (scene === "all" || (item.scene || "") === scene) &&
        (genre === "all" || (item.genre || "") === genre) &&
        (tag === "all" || (item.tags || []).includes(tag))
      );
    }).sort((a, b) => settings.sortMode === "custom"
      ? Number(a.order || 0) - Number(b.order || 0)
      : (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));

    if (!visible.length) {
      list.innerHTML = `<div class="prompt-vault-empty">还没有匹配的 Prompt。可以在扩展弹窗里新建、导入 JSON，或选中文字后右键保存。</div>`;
      return;
    }

    list.innerHTML = "";
    for (const item of visible) {
      const card = document.createElement("article");
      const hasImage = hasPromptImage(item.image);
      const insertImage = (item.references || []).find(hasPromptImage) || item.image;
      card.className = "prompt-vault-item";
      card.innerHTML = `
        <div class="prompt-vault-card-head${hasImage ? "" : " no-thumb"}">
          <div class="prompt-vault-card-main">
            <div class="prompt-vault-title-row">
              <div class="prompt-vault-item-title"></div>
              <span class="prompt-vault-type"></span>
            </div>
            <div class="prompt-vault-card-meta">
              <span data-project></span>
              <span data-scene></span>
              <span data-genre></span>
            </div>
            <div class="prompt-vault-body"></div>
          </div>
          ${hasImage ? '<img class="prompt-vault-thumb" alt="">' : ""}
        </div>
        <div class="prompt-vault-card-bottom">
          <div class="prompt-vault-tags" data-tags></div>
        </div>
        <div class="prompt-vault-actions">
          <button type="button" data-action="insert">插入</button>
          <button type="button" data-secondary="true" data-action="insert-close">\u63D2\u5165\u5E76\u9000\u51FA</button>
          ${hasPromptImage(insertImage) ? '<button type="button" data-secondary="true" data-action="insert-image">插入图片</button>' : ""}
          <button type="button" data-secondary="true" data-action="copy">\u590D\u5236</button>
          <button type="button" data-secondary="true" data-action="view">\u5B8C\u6574\u67E5\u770B</button>
        </div>
      `;
      card.querySelector(".prompt-vault-item-title").textContent = item.title || "未命名 Prompt";
      card.querySelector(".prompt-vault-type").textContent = categoryLabel(item.type, categories);
      const thumb = card.querySelector(".prompt-vault-thumb");
      if (thumb) thumb.src = item.image;
      const metaValues = [
        [card.querySelector("[data-project]"), item.project],
        [card.querySelector("[data-scene]"), item.scene],
        [card.querySelector("[data-genre]"), item.genre]
      ];
      for (const [element, value] of metaValues) {
        const text = String(value || "").trim();
        if (text) {
          element.textContent = text;
        } else {
          element.remove();
        }
      }
      card.querySelector(".prompt-vault-body").textContent = composePrompt(item);
      const tags = card.querySelector("[data-tags]");
      for (const tag of item.tags || []) {
        const chip = document.createElement("span");
        chip.className = "prompt-vault-tag";
        chip.textContent = tag;
        tags.append(chip);
      }
      card.querySelector('[data-action="insert"]').addEventListener("click", async (event) => {
        event.preventDefault();
        if (insertText(promptVaultTarget || document.activeElement, composePrompt(item))) void recordPromptUsage(item.id);
      });
      card.querySelector('[data-action="insert-close"]').addEventListener("click", async (event) => {
        event.preventDefault();
        const inserted = insertText(promptVaultTarget || document.activeElement, composePrompt(item));
        if (inserted) void recordPromptUsage(item.id);
        hideDetail();
        panel.dataset.open = "false";
        if (currentFabPosition) placeFabAt(currentFabPosition);
      });
      card.querySelector('[data-action="insert-image"]')?.addEventListener("click", async (event) => {
        event.preventDefault();
        const result = await copyImageForPaste(insertImage);
        if (!result) return;
        event.currentTarget.textContent = result === "image" ? "已复制，Ctrl+V 粘贴" : "已复制图片链接";
        void recordPromptUsage(item.id);
      });
      card.querySelector('[data-action="view"]').addEventListener("click", (event) => {
        event.preventDefault();
        showDetail(item, event.currentTarget);
      });
      card.querySelector('[data-action="copy"]').addEventListener("click", async (event) => {
        event.preventDefault();
        if (await copyText(composePrompt(item))) await recordPromptUsage(item.id);
      });
      list.append(card);
    }
  }

  fab.addEventListener("click", async () => {
    if (ignoreNextFabClick) {
      ignoreNextFabClick = false;
      return;
    }
    if (dragState?.moved) {
      dragState = null;
      return;
    }
    dragState = null;
    hideInputTrigger();
    hideFabMenu();
    panel.style.removeProperty("max-height");
    panel.dataset.open = panel.dataset.open === "true" ? "false" : "true";
    if (panel.dataset.open === "true") {
      placePanel(currentFabPosition || fab.getBoundingClientRect());
      await render();
    } else if (currentFabPosition) {
      placeFabAt(currentFabPosition);
    }
  });
  inputTrigger.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    rememberPromptVaultSelection(inputTriggerTarget);
  });
  inputTrigger.addEventListener("click", async (event) => {
    event.preventDefault();
    const target = inputTriggerTarget || currentTextTarget();
    if (!isPromptComposeTarget(target)) {
      hideInputTrigger();
      return;
    }
    rememberPromptVaultSelection(target);
    const triggerRect = inputTrigger.getBoundingClientRect();
    hideInputTrigger();
    panel.dataset.open = "true";
    placePanelNearInput(target, triggerRect);
    await render();
  });
  fabMenuExpand.addEventListener("click", async () => {
    hideFabMenu();
    panel.style.removeProperty("max-height");
    panel.dataset.open = "true";
    placePanel(currentFabPosition || fab.getBoundingClientRect());
    await render();
  });
  fabMenuHide.addEventListener("click", async () => {
    hideFabMenu();
    await setPromptVaultFabHiddenToday(true);
    await applyFabVisibility();
  });
  fabMenuCancel.addEventListener("click", hideFabMenu);
  document.addEventListener("pointerdown", (event) => {
    if (!fabMenu.contains(event.target) && event.target !== fab) hideFabMenu();
  }, true);
  document.addEventListener("focusin", (event) => {
    if (isPromptComposeTarget(event.target)) showInputTrigger(event.target);
  }, true);
  document.addEventListener("focusout", (event) => {
    if (isPromptComposeTarget(event.target)) scheduleInputTriggerHide();
  }, true);
  window.addEventListener("resize", () => placeInputTrigger());
  window.addEventListener("scroll", () => placeInputTrigger(), true);
  input.addEventListener("input", render);
  favoriteFilterButton.addEventListener("click", () => {
    favoriteOnly = !favoriteOnly;
    render();
  });
  refreshButton.addEventListener("click", async () => {
    refreshButton.textContent = "\u5237\u65B0\u4E2D";
    await new Promise((resolve) => setTimeout(resolve, 550));
    await render();
    refreshButton.textContent = "\u5237\u65B0";
  });
  sidepanelButton.addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "prompt-vault-open-sidepanel" });
    hideDetail();
    panel.dataset.open = "false";
    if (currentFabPosition) placeFabAt(currentFabPosition);
  });
  closeButton.addEventListener("click", () => {
    hideDetail();
    panel.dataset.open = "false";
    if (currentFabPosition) placeFabAt(currentFabPosition);
  });
  detailClose.addEventListener("click", hideDetail);
  detail.addEventListener("click", (event) => {
    if (event.target === detail) hideDetail();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "prompt-vault-insert") return false;
    const target = currentTextTarget();
    const inserted = insertText(target, String(message.text || ""));
    if (!inserted) {
      sendResponse({ ok: false, error: "未找到可写入的网页输入框，请先点击目标输入框后再插入。" });
      return false;
    }
    void recordPromptUsage(message.promptId);
    sendResponse({ ok: true });
    return false;
  });
  Object.values(filterSelects).forEach((select) => select.addEventListener("change", render));
  filterSelects.project.addEventListener("change", async () => {
    const prompts = await getPrompts();
    renderFilters(prompts);
    await render();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && Object.prototype.hasOwnProperty.call(changes, FAB_HIDDEN_DATE_KEY)) {
      void applyFabVisibility();
    }
    const localChanged = area === "local" && (changes[LOCAL_KEY] || changes[SETTINGS_KEY]);
    const syncChanged = area === "sync" && changes[SYNC_META_KEY];
    if ((localChanged || syncChanged) && panel.dataset.open === "true") render();
  });

  restoreFabPosition();
  void applyFabVisibility();
}

buildPanel();
