# Prompt Vault Terms of Use

Last updated: 2026-07-06

Prompt Vault is provided by 田田田野里 / 再野文化工作室.

By using this extension, you agree that:

- you are responsible for the prompts, images, links, and other content you save or export;
- you should make regular JSON backups if the prompt library matters to you;
- the extension is provided as is, and may not work perfectly on every website or browser version;
- you may not remove attribution, rebrand the extension, resell it, or redistribute modified copies without written permission;
- you may not use the extension for illegal, infringing, malicious, or abusive activity.

Official terms URL: http://zaiye.art/terms.html
