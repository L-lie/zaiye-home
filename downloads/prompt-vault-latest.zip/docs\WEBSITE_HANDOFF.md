# Prompt Vault 灵感资源库：网站端交接

## 这次要做什么

为浏览器扩展 **Prompt Vault** 提供一个公开、静态、可更新的“灵感资源库”数据文件。

扩展打开“灵感”页面时会读取官方公开 JSON。用户可以搜索、按类别筛选、打开详情、填写变量、复制结果，并把单条资源收藏到自己的本地 Prompt 库。在线读取失败时自动显示扩展内置的同版精选资源。

这不是用户数据同步服务：

- 不接收、不上传、不保存任何用户私有 Prompt。
- 不需要登录、数据库、后端接口或服务器。
- 第一阶段只需要 GitHub Pages 能公开访问一个 JSON 文件。

## 网站端需要完成的最小工作

在现有网站的 GitHub Pages 仓库中，新增并发布这个文件：

    prompt-vault-resources.json

建议把它放在网站的公开根目录。发布后，它应能被浏览器直接打开，且页面只显示 JSON。

示例网址：

    https://<GitHub 用户名>.github.io/<网站仓库名>/prompt-vault-resources.json

如果现有网站是用户主页仓库（网址没有仓库名），则示例为：

    https://<GitHub 用户名>.github.io/prompt-vault-resources.json

请把最终可直接打开的 JSON 网址交给 Prompt Vault 扩展端使用。

## JSON 固定格式

文件必须是有效 JSON，最外层必须有 items 数组：

    {
      "version": 2,
      "updatedAt": "2026-07-29",
      "items": [
        {
          "id": "unique-stable-id",
          "title": "标题",
          "summary": "一句话说明用途",
          "category": "writing",
          "type": "task",
          "model": "通用",
          "prompt": "请围绕@主题完成任务",
          "variables": [
            {
              "name": "主题",
              "label": "主题",
              "placeholder": "填写主题",
              "default": ""
            }
          ],
          "usage": "使用说明",
          "tags": ["标签一", "标签二"],
          "sourceName": "来源名称",
          "sourceUrl": "https://example.com/original-source",
          "license": "允许再发布和使用的许可说明"
        }
      ]
    }

字段说明：

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| id | 是 | 永久唯一 ID；发布后不要随意修改。 |
| title | 是 | 在资源库中展示的标题。 |
| summary | 是 | 卡片上展示的一句话用途说明。 |
| category | 是 | 资源浏览类别：writing、image、video、coding、office。 |
| type | 是 | 可用值：scene、character、video、constraint、task。 |
| model | 否 | 适用模型，例如“通用”“ChatGPT”“Midjourney”。 |
| prompt | 是 | Prompt 正文；变量使用 `@变量名`。 |
| variables | 否 | 变量数组；name 必须唯一，并与 Prompt 中的变量名对应。 |
| usage | 否 | 详情页中的简短使用说明。 |
| tags | 否 | 字符串数组。 |
| sourceName | 是 | 来源或作者名称。 |
| sourceUrl | 强烈建议 | 原始来源页面。 |
| license | 是 | 明确写出可再发布/改写/使用依据。 |

## 内容审核规则

只能发布以下内容：

1. Prompt Vault 自己原创且可以公开发布的通用模板。
2. 有明确开源、Creative Commons、公共领域、官方 API 或书面许可，且**明确允许再发布**的内容。

不能因为“网页上能看到”就转载。以下内容不得进入 JSON：

- 付费、会员、付费墙或限制下载内容。
- 来源没有明确许可、作者要求署名但无法满足，或禁止二次发布的内容。
- 用户上传的 Prompt、项目文件、客户资料、保密项目内容。
- 仅保存链接但实际复制了大段受版权保护内容的条目。

每条资源在发布前必须人工核对来源、许可和内容。

## 更新方式

更新只需修改并提交 prompt-vault-resources.json：

1. 先在本地审核候选内容。
2. 更新 updatedAt。
3. 提交并推送到 GitHub。
4. GitHub Pages 发布后，扩展用户点击“更新”即可读取新数据。

无需改扩展、无需重新发扩展安装包。

## 现有扩展端状态

扩展 v1.1.4 的资源库升级版已完成：

- 默认读取 `https://zaiye.art/prompt-vault-resources.json`。
- 可在高级来源设置中改用其他 HTTPS JSON。
- 会读取并显示 version 2 的 items。
- 支持搜索、类别筛选、详情查看、变量替换、复制和收藏。
- 官方资源版本过旧或远程读取失败时，会回退到扩展内置精选资源，不影响用户已有数据。
- 每次点击“更新”会使用缓存规避参数请求最新 JSON。

网站端不需要设置跨域 CORS；GitHub Pages 的静态 JSON 可由已获站点权限的扩展读取。

## 交付验收

完成后请提供：

1. 可直接在浏览器打开的 JSON 完整网址。
2. 一条真实测试资源，确认 JSON 可解析。
3. 该条资源的来源网址和许可说明。
