const MENU_SAVE_SELECTION = "prompt-vault-save-selection";
const LOCAL_KEY = "prompts";
const SETTINGS_KEY = "promptVaultSettings";
const SYNC_META_KEY = "promptVaultSyncMeta";
const SYNC_CHUNK_PREFIX = "promptVaultChunk";
const PENDING_OPEN_KEY = "promptVaultPendingOpen";
const PENDING_COLLECTION_KEY = "promptVaultPendingCollection";
const SYNC_CHUNK_SIZE = 7000;
const PRODUCT_OWNER = {
  product: "Prompt Vault",
  studio: "再野文化工作室",
  creator: "田田田野里"
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_SAVE_SELECTION,
    title: "保存为 Prompt",
    contexts: ["selection"]
  });
});

function sanitizePrompt(item) {
  return {
    ...item,
    id: item.id || crypto.randomUUID(),
    title: item.title || "未命名 Prompt",
    project: item.project || "",
    scene: item.scene || "",
    genre: item.genre || "",
    type: item.type ?? "scene",
    prompt: item.prompt || "",
    promptEn: item.promptEn || "",
    negative: item.negative || "",
    tags: Array.isArray(item.tags) ? item.tags.map(String) : [],
    image: item.image || "",
    sourceUrl: item.sourceUrl || "",
    rating: Number(item.rating) || 0,
    usageCount: Object.prototype.hasOwnProperty.call(item, "usageCount") ? Number(item.usageCount) || 0 : 0,
    lastUsedAt: Object.prototype.hasOwnProperty.call(item, "lastUsedAt") ? Number(item.lastUsedAt) || 0 : 0,
    createdAt: Number(item.createdAt) || Date.now(),
    updatedAt: Number(item.updatedAt) || Date.now(),
    sourceProduct: item.sourceProduct || PRODUCT_OWNER.product,
    sourceStudio: item.sourceStudio || PRODUCT_OWNER.studio,
    sourceCreator: item.sourceCreator || PRODUCT_OWNER.creator,
    versions: Array.isArray(item.versions) ? item.versions : []
  };
}

function syncSafePrompt(item) {
  const safe = sanitizePrompt(item);
  if (safe.image.startsWith("data:")) safe.image = "";
  return safe;
}

async function getSettings() {
  const data = await chrome.storage.local.get({ [SETTINGS_KEY]: { storageMode: "local" } });
  return data[SETTINGS_KEY];
}

async function readSyncPrompts() {
  const metaData = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const count = metaData[SYNC_META_KEY]?.count || 0;
  if (!count) return [];
  const keys = Array.from({ length: count }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  const chunks = await chrome.storage.sync.get(keys);
  const json = keys.map((key) => chunks[key] || "").join("");
  return json ? JSON.parse(json).map(sanitizePrompt) : [];
}

async function writeSyncPrompts(items) {
  const json = JSON.stringify(items.map(syncSafePrompt));
  const chunks = [];
  for (let index = 0; index < json.length; index += SYNC_CHUNK_SIZE) {
    chunks.push(json.slice(index, index + SYNC_CHUNK_SIZE));
  }

  const oldMeta = await chrome.storage.sync.get({ [SYNC_META_KEY]: { count: 0 } });
  const oldCount = oldMeta[SYNC_META_KEY]?.count || 0;
  const toRemove = Array.from({ length: oldCount }, (_, index) => `${SYNC_CHUNK_PREFIX}${index}`);
  if (toRemove.length) await chrome.storage.sync.remove(toRemove);

  const data = { [SYNC_META_KEY]: { count: chunks.length, updatedAt: Date.now() } };
  chunks.forEach((chunk, index) => {
    data[`${SYNC_CHUNK_PREFIX}${index}`] = chunk;
  });
  await chrome.storage.sync.set(data);
}

async function getPrompts() {
  const settings = await getSettings();
  if (settings.storageMode === "sync") {
    const synced = await readSyncPrompts();
    if (synced.length) return synced;
  }
  const data = await chrome.storage.local.get({ [LOCAL_KEY]: [] });
  return data[LOCAL_KEY].map(sanitizePrompt);
}

async function setPrompts(items) {
  const prompts = items.map(sanitizePrompt);
  await chrome.storage.local.set({ [LOCAL_KEY]: prompts });
  const settings = await getSettings();
  if (settings.storageMode === "sync") await writeSyncPrompts(prompts);
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_SAVE_SELECTION || !info.selectionText) return;
  const text = info.selectionText.trim();
  if (!text) return;

  const prompt = {
    id: crypto.randomUUID(),
    title: "未命名 Prompt",
    project: "",
    scene: "",
    genre: "",
    type: "scene",
    prompt: text,
    promptEn: "",
    negative: "",
    tags: [],
    image: "",
    sourceUrl: info.pageUrl || "",
    rating: 0,
    usageCount: 0,
    lastUsedAt: 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    sourceProduct: PRODUCT_OWNER.product,
    sourceStudio: PRODUCT_OWNER.studio,
    sourceCreator: PRODUCT_OWNER.creator,
    versions: []
  };

  const prompts = await getPrompts();
  await setPrompts([prompt, ...prompts]);
  await chrome.storage.local.set({ [PENDING_OPEN_KEY]: { id: prompt.id, mode: "edit" } });
  try {
    await chrome.action.openPopup();
  } catch {
    await chrome.tabs.create({ url: chrome.runtime.getURL(`popup.html?promptId=${encodeURIComponent(prompt.id)}&edit=1`) });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "prompt-vault-read-prompts") {
    getPrompts().then((prompts) => sendResponse({ ok: true, prompts })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type !== "prompt-vault-open-sidepanel" && message?.type !== "prompt-vault-open-collection") return false;
  (async () => {
    const tabId = Number(message.tabId) || sender.tab?.id;
    if (!tabId) throw new Error("\u672A\u627E\u5230\u5F53\u524D\u7F51\u9875");
    if (message.type === "prompt-vault-open-collection") {
      await chrome.storage.local.set({ [PENDING_COLLECTION_KEY]: { tabId, result: message.result || null, createdAt: Date.now() } });
      await chrome.action.openPopup({ windowId: sender.tab?.windowId });
      sendResponse({ ok: true, openedMain: true });
    } else {
      await chrome.sidePanel.open({ tabId });
      sendResponse({ ok: true, openedMain: false });
    }
  })().catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});
