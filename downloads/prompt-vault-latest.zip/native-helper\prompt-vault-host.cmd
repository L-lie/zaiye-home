@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0prompt-vault-host.ps1"
