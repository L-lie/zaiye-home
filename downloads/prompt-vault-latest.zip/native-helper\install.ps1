param(
  [string[]]$ExtensionId = @("idiemjhonlahnlnalpanhplbgjcfbpnl")
)

$ErrorActionPreference = "Stop"
$extensionId = "idiemjhonlahnlnalpanhplbgjcfbpnl"
$hostName = "com.zaiye.prompt_vault"
$sourceDirectory = $PSScriptRoot
$installDirectory = Join-Path ([Environment]::GetFolderPath("LocalApplicationData")) "ZaiyePromptVault\native-host"
New-Item -ItemType Directory -Force -Path $installDirectory | Out-Null
Copy-Item -LiteralPath (Join-Path $sourceDirectory "prompt-vault-host.ps1") -Destination $installDirectory -Force
Copy-Item -LiteralPath (Join-Path $sourceDirectory "prompt-vault-host.cmd") -Destination $installDirectory -Force
$manifestPath = Join-Path $installDirectory "$hostName.json"
$origins = @($ExtensionId | Where-Object { $_ -match '^[a-z]{32}$' } | Select-Object -Unique | ForEach-Object { "chrome-extension://$_/" })
if (-not $origins.Count) { throw "Provide at least one 32-character extension ID." }
$manifest = @{ name = $hostName; description = "Prompt Vault local shared library"; path = (Join-Path $installDirectory "prompt-vault-host.cmd"); type = "stdio"; allowed_origins = $origins }
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
foreach ($registryPath in @(
  "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$hostName",
  "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$hostName"
)) {
  New-Item -Path $registryPath -Force | Out-Null
  Set-ItemProperty -Path $registryPath -Name "(Default)" -Value $manifestPath
}
Write-Host "Local shared library installed. Reload Prompt Vault in Chrome or Edge."
