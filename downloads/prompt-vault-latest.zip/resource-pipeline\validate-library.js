const fs = require("fs");
const path = require("path");

const allowedCategories = new Set(["writing", "image", "video", "coding", "office"]);
const allowedTypes = new Set(["scene", "character", "video", "constraint", "task"]);
const files = process.argv.slice(2);

if (!files.length) {
  files.push(path.join(__dirname, "..", "resources", "inspiration-library.json"));
}

function fail(file, message) {
  throw new Error(`${file}: ${message}`);
}

function validate(file) {
  const absolute = path.resolve(file);
  const text = fs.readFileSync(absolute, "utf8");
  const data = JSON.parse(text);
  if (data.version !== 2) fail(absolute, "version 必须是 2");
  if (!Array.isArray(data.items) || !data.items.length) fail(absolute, "items 必须是非空数组");

  const ids = new Set();
  for (const [index, item] of data.items.entries()) {
    const label = `items[${index}]`;
    for (const field of ["id", "title", "summary", "category", "type", "prompt", "sourceName", "license"]) {
      if (!String(item[field] || "").trim()) fail(absolute, `${label}.${field} 不能为空`);
    }
    if (ids.has(item.id)) fail(absolute, `重复 id: ${item.id}`);
    ids.add(item.id);
    if (!allowedCategories.has(item.category)) fail(absolute, `${label}.category 非法: ${item.category}`);
    if (!allowedTypes.has(item.type)) fail(absolute, `${label}.type 非法: ${item.type}`);
    if (item.sourceUrl && !String(item.sourceUrl).startsWith("https://")) {
      fail(absolute, `${label}.sourceUrl 必须使用 HTTPS`);
    }
    if (/[A-Za-z]:\\|file:\/\//.test(JSON.stringify(item))) {
      fail(absolute, `${label} 不得包含本地绝对路径`);
    }

    const variables = Array.isArray(item.variables) ? item.variables : [];
    const variableNames = new Set();
    for (const [variableIndex, variable] of variables.entries()) {
      const name = String(variable?.name || "").trim();
      if (!name) fail(absolute, `${label}.variables[${variableIndex}].name 不能为空`);
      if (variableNames.has(name)) fail(absolute, `${label} 存在重复变量: ${name}`);
      variableNames.add(name);
      if (!String(variable.label || "").trim()) fail(absolute, `${label} 的变量 ${name} 缺少 label`);
      if (!item.prompt.includes(`@${name}`)) fail(absolute, `${label} 的变量 @${name} 未出现在 prompt 中`);
    }

    const sampleValues = Object.fromEntries(variables.map((variable) => [variable.name, `示例${variable.name}`]));
    let compiled = item.prompt;
    for (const [name, value] of Object.entries(sampleValues)) {
      compiled = compiled.split(`@${name}`).join(value);
    }
    if (compiled.includes("@")) fail(absolute, `${label} 示例替换后仍有未声明或未处理变量`);
  }

  return { file: absolute, items: data.items.length, ids };
}

const results = files.map(validate);
if (results.length > 1) {
  const expectedIds = [...results[0].ids].sort().join("\n");
  for (const result of results.slice(1)) {
    if ([...result.ids].sort().join("\n") !== expectedIds) {
      fail(result.file, "资源 ID 集合与首个文件不一致");
    }
  }
}

for (const result of results) {
  process.stdout.write(`OK ${result.items} items ${result.file}\n`);
}
