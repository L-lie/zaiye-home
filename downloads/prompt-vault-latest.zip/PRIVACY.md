# Prompt Vault Privacy Policy

Last updated: 2026-07-23

Prompt Vault is a browser prompt management tool created by 田田田野里 / 再野文化工作室.

Current version:

- does not provide a cloud account;
- does not automatically upload saved prompts, images, source links, or feedback to the creator;
- stores prompt library data mainly in the user's browser local storage;
- allows users to export JSON backups manually.

Data that may be stored locally:

- prompt text, English prompt, negative prompt;
- project, scene, type, tags, rating, source URL;
- example image, reference images, image URLs;
- favorites, usage count, timestamps, local settings;
- product, creator, studio, official site, release ID, and provenance metadata.

Permissions are used to save prompts, show a small Prompt Vault entry beside supported focused web text boxes, insert prompts into the user-selected text box only after the user clicks the entry and chooses a prompt, create context menu actions, read clipboard content when the user clicks paste-related controls, and store extension data. The extension does not automatically collect web page text or submit data to third parties.

The current version does not sell, rent, or automatically share user prompt data with third parties.

If future versions add cloud sync, online feedback, account login, AI generation, or paid services, this policy should be updated before those features are released.

Official privacy policy URL: http://zaiye.art/privacy.html
