# Reference Dock 正版识别

Reference Dock 当前为免费直发版。请只从作者官网或作者明确标注的 Adobe Creative Cloud Marketplace 页面获取安装包。

## 校验方法

每次发布都会同时生成：

- `Reference-Dock-v版本号.ccx`
- `Reference-Dock-v版本号.ccx.sha256.txt`

在 Windows PowerShell 中运行：

```powershell
Get-FileHash -Algorithm SHA256 .\Reference-Dock-v1.0.0.ccx
```

输出值必须与官网公布的 SHA-256 完全一致。任何修改都会导致校验值变化。

## 插件身份

- 产品名称：Reference Dock
- 当前版本：1.0.0
- 当前开发 ID：`com.reference-dock.photoshop`
- 版本类型：免费直发版

当前 ID 尚不是 Adobe Developer Distribution 分配的 Marketplace ID。创建正式 Marketplace 条目后，应以 Adobe 分配的唯一 ID 替换当前开发 ID，并同步更新本文件、`manifest.json` 和 `build-info.json`。

## 能力边界

UXP `.ccx` 本质上是插件安装包，基础校验可以识别安装包是否被修改，但无法保证客户端代码绝对不能被反编译或篡改。请勿把 API 私钥、支付密钥或许可证签名私钥写入插件。
