# Reference Dock

一个停靠在 Photoshop 内部的参考图面板。它解决外部参考图窗口遮挡画布、无法直接将参考图颜色设为 Photoshop 前景色的问题。

当前版本为免费直发版。插件内置统一品牌图标、版本身份与产品 ID；发布包通过 SHA-256 文件提供基础完整性校验。详细说明见 `AUTHENTICITY.md`。

## 当前功能

- 导入多张 PNG、JPG、JPEG 或 WebP 参考图
- 无限画布平移和缩放
- 拖动图片进行自由排列
- Ctrl + 滚轮单独缩放鼠标下的图片
- 一键将全部参考图适应面板
- 点击参考图取色，并设置为 Photoshop 前景色
- 将 Photoshop 当前图层渲染为参考图快照
- 将选中的参考图作为智能对象置入当前 Photoshop 文档
- 显示最近颜色的 HEX 和 RGB 数值
- 三种参考板背景
- 保存文件授权、图片位置、缩放比例和背景设置
- Delete 或 Backspace 删除当前选中的图片
- `I` 键切换移动/吸色模式

## 加载插件

要求：Photoshop 25.0 或更高版本，以及 Adobe UXP Developer Tool。

1. 打开 Photoshop。
2. 打开 UXP Developer Tool。
3. 点击 **Add Plugin**。
4. 选择本目录下的 `manifest.json`。
5. 在插件右侧菜单中点击 **Load**。
6. 如果面板没有自动出现，在 Photoshop 的 **增效工具/Plugins** 菜单中打开 **Reference Dock**。
7. 将面板拖到 Photoshop 左侧或右侧停靠栏。

## 使用方法

1. 点击 **导入**，选择一张或多张参考图。
2. 在 **移动** 模式拖动图片；拖动画布空白处平移无限画布，滚轮缩放整个画布。
3. 把鼠标放在图片上按住 Ctrl 滚动滚轮，可单独缩放该图片。
4. 点击 **吸色**，再点击参考图中的任意位置。该颜色会立即成为 Photoshop 前景色。
5. 点击 **图层→参考**，将 Photoshop 当前选中图层送入参考板。
6. 选中参考图后点击 **参考→PS** 或按 Enter，将它置入当前 Photoshop 文档。
7. 点击 **适应** 查看全部图片；按 Delete 或 Backspace 可移除选中的图片。

## 已知边界

- 参考图文件被移动、删除，或系统撤销文件权限后，该图片无法在下次启动时恢复，需要重新导入。
- WebP 是否能够解码取决于当前 Photoshop/UXP 版本；PNG 与 JPEG 是优先支持格式。
- UXP 当前不能可靠地把插件 DOM 元素直接拖过面板边界到 Photoshop 画布，因此首版用 **参考→PS**、Enter 快捷键和 **图层→参考** 实现等价的双向传递。
- 从 Photoshop 图层生成的是最长边不超过 2400 像素的 JPEG 参考快照，不会与原图层保持实时链接。
- 当前版本是轻量参考板，不包含 PureRef 的分组、标注和云同步功能。

## 构建发布包

在 PowerShell 中运行：

```powershell
.\build-release.ps1
```

脚本会在 `release` 目录生成 `.ccx` 安装包和对应的 `.sha256.txt`。官网发布时应同时提供这两个文件。当前 `manifest.json` 使用开发阶段产品 ID；提交 Adobe Marketplace 前必须替换成 Developer Distribution 分配的正式 ID。
