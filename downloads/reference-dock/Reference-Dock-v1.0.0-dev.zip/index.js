const { app, core, action, imaging } = require("photoshop");
const { storage } = require("uxp");

const fs = storage.localFileSystem;
const formats = storage.formats;
const STORAGE_KEY = "reference-dock-board-v1";
const BACKGROUNDS = ["checker", "dark", "light"];
const SUPPORTED_TYPES = ["jpg", "jpeg", "png", "webp"];

const state = {
  items: [],
  selectedId: null,
  tool: "move",
  background: "checker",
  drag: null,
  pan: null,
  camera: { x: 0, y: 0, zoom: 1 },
  sequence: 0
};

const elements = {
  aboutButton: document.getElementById("aboutButton"),
  aboutPanel: document.getElementById("aboutPanel"),
  addButton: document.getElementById("addButton"),
  captureButton: document.getElementById("captureButton"),
  placeButton: document.getElementById("placeButton"),
  moveButton: document.getElementById("moveButton"),
  pickButton: document.getElementById("pickButton"),
  fitButton: document.getElementById("fitButton"),
  backgroundButton: document.getElementById("backgroundButton"),
  clearButton: document.getElementById("clearButton"),
  stage: document.getElementById("stage"),
  board: document.getElementById("board"),
  emptyState: document.getElementById("emptyState"),
  colorSwatch: document.getElementById("colorSwatch"),
  colorValue: document.getElementById("colorValue"),
  statusText: document.getElementById("statusText"),
  sampler: document.getElementById("sampler")
};

function setStatus(message) {
  elements.statusText.textContent = message;
}

function getMimeType(name) {
  const extension = name.split(".").pop().toLowerCase();
  if (extension === "jpg" || extension === "jpeg") return "image/jpeg";
  if (extension === "png") return "image/png";
  if (extension === "webp") return "image/webp";
  return "application/octet-stream";
}

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function getStagePoint(event) {
  const rect = elements.stage.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}

function updateEmptyState() {
  elements.emptyState.hidden = state.items.length > 0;
}

function updateToolUI() {
  const picking = state.tool === "picker";
  elements.moveButton.classList.toggle("active", !picking);
  elements.pickButton.classList.toggle("active", picking);
  elements.stage.classList.toggle("picker", picking);
}

function updateBackgroundUI() {
  BACKGROUNDS.forEach((name) => elements.stage.classList.remove(name));
  elements.stage.classList.add(state.background);
}

function serializeBoard() {
  return {
    background: state.background,
    camera: state.camera,
    items: state.items
      .filter((item) => item.token)
      .map((item) => ({
        token: item.token,
        name: item.name,
        x: item.x,
        y: item.y,
        scale: item.scale
      }))
  };
}

function saveBoard() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serializeBoard()));
  } catch (error) {
    setStatus("无法保存参考板布局");
  }
}

function selectItem(id) {
  state.selectedId = id;
  state.items.forEach((item) => {
    item.element.classList.toggle("selected", item.id === id);
  });
}

function renderTransform(item) {
  const screenX = state.camera.x + item.x * state.camera.zoom;
  const screenY = state.camera.y + item.y * state.camera.zoom;
  const screenScale = item.scale * state.camera.zoom;
  item.element.style.transform = `translate(${screenX}px, ${screenY}px) scale(${screenScale})`;
}

function renderBoard() {
  state.items.forEach(renderTransform);
}

function revokeItemUrl(item) {
  if (item.url) {
    URL.revokeObjectURL(item.url);
  }
}

async function createImageUrl(file) {
  const buffer = await file.read({ format: formats.binary });
  const blob = new ImageBlob(buffer, { type: getMimeType(file.name) });
  return URL.createObjectURL(blob);
}

function nextPlacement() {
  const offset = (state.items.length % 8) * 22;
  const centerX = (elements.stage.clientWidth / 2 - state.camera.x) / state.camera.zoom;
  const centerY = (elements.stage.clientHeight / 2 - state.camera.y) / state.camera.zoom;
  return { x: centerX - 120 + offset, y: centerY - 100 + offset };
}

async function addEntry(file, saved = null) {
  const url = await createImageUrl(file);
  const image = document.createElement("img");
  const wrapper = document.createElement("div");
  const id = `reference-${Date.now()}-${state.sequence++}`;

  wrapper.className = "reference";
  wrapper.dataset.id = id;
  wrapper.title = file.name;
  wrapper.appendChild(image);
  elements.board.appendChild(wrapper);

  const dimensions = await new Promise((resolve, reject) => {
    image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
    image.onerror = () => reject(new Error(`无法解码 ${file.name}`));
    image.src = url;
  });

  let token = saved && saved.token;
  if (!token) {
    try {
      token = await fs.createPersistentToken(file);
    } catch (error) {
      token = null;
    }
  }

  const placement = nextPlacement();
  const initialScale = Math.min(1, 380 / dimensions.width, 320 / dimensions.height);
  const item = {
    id,
    name: saved && saved.name ? saved.name : file.name,
    token,
    file,
    url,
    image,
    element: wrapper,
    width: dimensions.width,
    height: dimensions.height,
    x: saved && Number.isFinite(saved.x) ? saved.x : placement.x,
    y: saved && Number.isFinite(saved.y) ? saved.y : placement.y,
    scale: saved && Number.isFinite(saved.scale) ? clamp(saved.scale, 0.02, 20) : initialScale
  };

  state.items.push(item);
  renderTransform(item);
  selectItem(id);
  updateEmptyState();
  return item;
}

async function importImages() {
  try {
    const selection = await fs.getFileForOpening({
      types: SUPPORTED_TYPES,
      allowMultiple: true
    });
    if (!selection) return;

    const files = Array.isArray(selection) ? selection : [selection];
    let imported = 0;
    for (const file of files) {
      try {
        await addEntry(file);
        imported += 1;
      } catch (error) {
        setStatus(error.message || `无法导入 ${file.name}`);
      }
    }

    if (imported > 0) {
      saveBoard();
      setStatus(`已导入 ${imported} 张参考图`);
    }
  } catch (error) {
    setStatus(`导入失败：${error.message || error}`);
  }
}

function removeItem(id) {
  const index = state.items.findIndex((item) => item.id === id);
  if (index < 0) return;
  const [item] = state.items.splice(index, 1);
  item.element.remove();
  revokeItemUrl(item);
  state.selectedId = null;
  updateEmptyState();
  saveBoard();
  setStatus(`已移除 ${item.name}`);
}

function clearBoard() {
  state.items.forEach((item) => {
    item.element.remove();
    revokeItemUrl(item);
  });
  state.items = [];
  state.selectedId = null;
  updateEmptyState();
  saveBoard();
  setStatus("参考板已清空");
}

function fitBoard() {
  if (state.items.length === 0) return;

  const padding = 20;
  const minX = Math.min(...state.items.map((item) => item.x));
  const minY = Math.min(...state.items.map((item) => item.y));
  const maxX = Math.max(...state.items.map((item) => item.x + item.width * item.scale));
  const maxY = Math.max(...state.items.map((item) => item.y + item.height * item.scale));
  const width = Math.max(1, maxX - minX);
  const height = Math.max(1, maxY - minY);
  const stageWidth = elements.stage.clientWidth;
  const stageHeight = elements.stage.clientHeight;
  const zoom = Math.min((stageWidth - padding * 2) / width, (stageHeight - padding * 2) / height);
  state.camera.zoom = clamp(zoom, 0.02, 20);
  state.camera.x = (stageWidth - width * state.camera.zoom) / 2 - minX * state.camera.zoom;
  state.camera.y = (stageHeight - height * state.camera.zoom) / 2 - minY * state.camera.zoom;
  renderBoard();

  saveBoard();
  setStatus("已显示全部参考图");
}

function findItemFromTarget(target) {
  const wrapper = target.closest ? target.closest(".reference") : null;
  if (!wrapper) return null;
  return state.items.find((item) => item.id === wrapper.dataset.id) || null;
}

function beginDrag(event, item) {
  state.drag = {
    item,
    startMouseX: event.clientX,
    startMouseY: event.clientY,
    startX: item.x,
    startY: item.y
  };
  item.element.style.cursor = "grabbing";
}

function moveDrag(event) {
  if (!state.drag) return;
  const { item, startMouseX, startMouseY, startX, startY } = state.drag;
  item.x = startX + (event.clientX - startMouseX) / state.camera.zoom;
  item.y = startY + (event.clientY - startMouseY) / state.camera.zoom;
  renderTransform(item);
}

function endDrag() {
  if (!state.drag) return;
  state.drag.item.element.style.cursor = "";
  state.drag = null;
  saveBoard();
}

function zoomItem(event, item) {
  const previousScale = item.scale;
  const multiplier = event.deltaY < 0 ? 1.1 : 1 / 1.1;
  const nextScale = clamp(previousScale * multiplier, 0.02, 20);
  const rect = item.element.getBoundingClientRect();
  const localX = (event.clientX - rect.left) / (previousScale * state.camera.zoom);
  const localY = (event.clientY - rect.top) / (previousScale * state.camera.zoom);
  item.x -= localX * (nextScale - previousScale);
  item.y -= localY * (nextScale - previousScale);
  item.scale = nextScale;
  renderTransform(item);
  selectItem(item.id);
  saveBoard();
  setStatus(`${Math.round(item.scale * 100)}%`);
}

function beginPan(event) {
  state.pan = {
    startMouseX: event.clientX,
    startMouseY: event.clientY,
    startX: state.camera.x,
    startY: state.camera.y
  };
  elements.stage.classList.add("panning");
}

function movePan(event) {
  if (!state.pan) return;
  state.camera.x = state.pan.startX + event.clientX - state.pan.startMouseX;
  state.camera.y = state.pan.startY + event.clientY - state.pan.startMouseY;
  renderBoard();
}

function endPan() {
  if (!state.pan) return;
  state.pan = null;
  elements.stage.classList.remove("panning");
  saveBoard();
}

function zoomCanvas(event) {
  const point = getStagePoint(event);
  const previousZoom = state.camera.zoom;
  const multiplier = event.deltaY < 0 ? 1.12 : 1 / 1.12;
  const nextZoom = clamp(previousZoom * multiplier, 0.02, 20);
  const worldX = (point.x - state.camera.x) / previousZoom;
  const worldY = (point.y - state.camera.y) / previousZoom;
  state.camera.x = point.x - worldX * nextZoom;
  state.camera.y = point.y - worldY * nextZoom;
  state.camera.zoom = nextZoom;
  renderBoard();
  saveBoard();
  setStatus(`画布 ${Math.round(nextZoom * 100)}%`);
}

function rgbToHex(red, green, blue) {
  return `#${[red, green, blue]
    .map((channel) => channel.toString(16).padStart(2, "0"))
    .join("")}`.toUpperCase();
}

async function sampleColor(event, item) {
  try {
    const rect = item.element.getBoundingClientRect();
    const pixelX = clamp(
      Math.floor(((event.clientX - rect.left) / rect.width) * item.width),
      0,
      item.width - 1
    );
    const pixelY = clamp(
      Math.floor(((event.clientY - rect.top) / rect.height) * item.height),
      0,
      item.height - 1
    );
    const context = elements.sampler.getContext("2d");
    context.clearRect(0, 0, 1, 1);
    context.drawImage(item.image, pixelX, pixelY, 1, 1, 0, 0, 1, 1);
    const pixel = context.getImageData(0, 0, 1, 1).data;
    const [red, green, blue] = pixel;
    const color = new app.SolidColor();
    color.rgb.red = red;
    color.rgb.green = green;
    color.rgb.blue = blue;

    await core.executeAsModal(
      async () => {
        app.foregroundColor = color;
      },
      { commandName: "Reference Dock 取色" }
    );

    const hex = rgbToHex(red, green, blue);
    elements.colorSwatch.style.background = hex;
    elements.colorValue.textContent = `${hex} · ${red}, ${green}, ${blue}`;
    setStatus("已设置 PS 前景色");
  } catch (error) {
    setStatus(`取色失败：${error.message || error}`);
  }
}

async function placeSelectedInPhotoshop() {
  const item = state.items.find((candidate) => candidate.id === state.selectedId);
  if (!item) {
    setStatus("请先选择一张参考图");
    return;
  }
  if (app.documents.length === 0) {
    setStatus("请先打开一个 Photoshop 文档");
    return;
  }

  try {
    const token = fs.createSessionToken(item.file);
    await core.executeAsModal(
      async () => {
        await action.batchPlay(
          [
            {
              _obj: "placeEvent",
              null: { _path: token, _kind: "local" },
              freeTransformCenterState: {
                _enum: "quadCenterState",
                _value: "QCSAverage"
              },
              _options: { dialogOptions: "dontDisplay" }
            }
          ],
          {}
        );
      },
      { commandName: "置入 Reference Dock 图片" }
    );
    setStatus(`已将 ${item.name} 置入 PS`);
  } catch (error) {
    setStatus(`置入失败：${error.message || error}`);
  }
}

async function captureActiveLayer() {
  if (app.documents.length === 0) {
    setStatus("请先打开一个 Photoshop 文档");
    return;
  }

  const document = app.activeDocument;
  const layer = document.activeLayers[0];
  if (!layer) {
    setStatus("请先选择一个图层");
    return;
  }

  let imageData;
  try {
    const bounds = layer.bounds;
    const left = Number(bounds.left);
    const top = Number(bounds.top);
    const right = Number(bounds.right);
    const bottom = Number(bounds.bottom);
    const width = right - left;
    const height = bottom - top;
    if (width <= 0 || height <= 0) {
      setStatus("当前图层没有可见像素");
      return;
    }

    const maxPreviewSide = 2400;
    const targetSize = width >= height
      ? { width: Math.min(width, maxPreviewSide) }
      : { height: Math.min(height, maxPreviewSide) };
    const result = await imaging.getPixels({
      documentID: document.id,
      layerID: layer.id,
      sourceBounds: { left, top, right, bottom },
      targetSize,
      colorSpace: "RGB",
      componentSize: 8,
      applyAlpha: true
    });
    imageData = result.imageData;
    const jpegBytes = await imaging.encodeImageData({ imageData });
    const dataFolder = await fs.getDataFolder();
    const file = await dataFolder.createFile(`layer-${Date.now()}.jpg`, { overwrite: true });
    await file.write(new Uint8Array(jpegBytes), { format: formats.binary });
    const item = await addEntry(file);
    item.name = layer.name;
    item.element.title = `${layer.name}（来自 Photoshop）`;
    saveBoard();
    setStatus(`已将图层“${layer.name}”加入参考板`);
  } catch (error) {
    setStatus(`图层导入失败：${error.message || error}`);
  } finally {
    if (imageData) imageData.dispose();
  }
}

function setTool(tool) {
  state.tool = tool;
  updateToolUI();
  setStatus(tool === "picker" ? "点击参考图吸色" : "拖动图片，滚轮缩放");
}

function cycleBackground() {
  const index = BACKGROUNDS.indexOf(state.background);
  state.background = BACKGROUNDS[(index + 1) % BACKGROUNDS.length];
  updateBackgroundUI();
  saveBoard();
}

async function restoreBoard() {
  let saved;
  try {
    saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
  } catch (error) {
    localStorage.removeItem(STORAGE_KEY);
    return;
  }

  if (!saved) return;
  if (BACKGROUNDS.includes(saved.background)) {
    state.background = saved.background;
    updateBackgroundUI();
  }
  if (
    saved.camera &&
    Number.isFinite(saved.camera.x) &&
    Number.isFinite(saved.camera.y) &&
    Number.isFinite(saved.camera.zoom)
  ) {
    state.camera = {
      x: saved.camera.x,
      y: saved.camera.y,
      zoom: clamp(saved.camera.zoom, 0.02, 20)
    };
  }

  const savedItems = Array.isArray(saved.items) ? saved.items : [];
  let restored = 0;
  for (const savedItem of savedItems) {
    try {
      const file = await fs.getEntryForPersistentToken(savedItem.token);
      await addEntry(file, savedItem);
      restored += 1;
    } catch (error) {
      // An invalid token means the file moved or its permission was revoked.
    }
  }

  saveBoard();
  if (restored > 0) {
    setStatus(`已恢复 ${restored} 张参考图`);
  }
}

elements.addButton.addEventListener("click", importImages);
elements.aboutButton.addEventListener("click", () => {
  const expanded = elements.aboutButton.getAttribute("aria-expanded") === "true";
  elements.aboutButton.setAttribute("aria-expanded", String(!expanded));
  elements.aboutPanel.hidden = expanded;
});
elements.captureButton.addEventListener("click", captureActiveLayer);
elements.placeButton.addEventListener("click", placeSelectedInPhotoshop);
elements.moveButton.addEventListener("click", () => setTool("move"));
elements.pickButton.addEventListener("click", () => setTool("picker"));
elements.fitButton.addEventListener("click", fitBoard);
elements.backgroundButton.addEventListener("click", cycleBackground);
elements.clearButton.addEventListener("click", clearBoard);

elements.board.addEventListener("mousedown", (event) => {
  const item = findItemFromTarget(event.target);
  if (!item) {
    selectItem(null);
    if (event.button === 0 || event.button === 1) beginPan(event);
    return;
  }
  selectItem(item.id);
  if (state.tool === "picker") {
    sampleColor(event, item);
  } else if (event.button === 0) {
    beginDrag(event, item);
  }
});

elements.board.addEventListener("mousemove", (event) => {
  moveDrag(event);
  movePan(event);
});
elements.board.addEventListener("mouseup", () => {
  endDrag();
  endPan();
});
elements.board.addEventListener("mouseleave", () => {
  endDrag();
  endPan();
});
elements.board.addEventListener("wheel", (event) => {
  const item = findItemFromTarget(event.target);
  event.preventDefault();
  if (item && event.ctrlKey) {
    zoomItem(event, item);
  } else {
    zoomCanvas(event);
  }
});
elements.board.addEventListener("dblclick", (event) => {
  const item = findItemFromTarget(event.target);
  if (!item || state.tool === "picker") return;
  selectItem(item.id);
  placeSelectedInPhotoshop();
});

document.addEventListener("keydown", (event) => {
  if ((event.key === "Delete" || event.key === "Backspace") && state.selectedId) {
    removeItem(state.selectedId);
  }
  if (event.key && event.key.toLowerCase() === "i") {
    setTool(state.tool === "picker" ? "move" : "picker");
  }
  if (event.key === "Enter" && state.selectedId) {
    placeSelectedInPhotoshop();
  }
});

window.addEventListener("beforeunload", () => {
  state.items.forEach(revokeItemUrl);
});

updateToolUI();
updateBackgroundUI();
updateEmptyState();
restoreBoard();
